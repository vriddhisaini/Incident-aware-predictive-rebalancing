# Incident-Aware Predictive Rebalancing

This capstone project explores how a small service can respond to changing demand across three Kubernetes zones. It combines repeatable traffic, service metrics, forecasting, incident signals, and guarded action proposals.

## What is in here

- **`demonstration-frontend/`** — a small visual guide to the system. Its scenario buttons are illustrative; they do not send traffic or control Kubernetes.
- **`kubernetes-project/`** — the service, router, models, agents, Kubernetes manifests, benchmark adapters, and recorded evaluation results.
- **`docs/`** — a short project flow guide and notes for the frontend and packaged files.

## Try the visual guide

Open `demonstration-frontend/index.html` in a browser, or run a local server from that folder:

```sh
python3 -m http.server 8000 --bind 127.0.0.1
```

Then visit http://localhost:8000.

## Run the project

The Kubernetes demo is a separate workflow from the visual guide. Start with [`kubernetes-project/docs/LOCAL_SETUP.md`](kubernetes-project/docs/LOCAL_SETUP.md) and [`kubernetes-project/docs/UNIFIED_LIVE_DEMO.md`](kubernetes-project/docs/UNIFIED_LIVE_DEMO.md). The unified run uses kind, Docker, Helm, Python, and the project’s local model services.

## A note on results

The recorded prototype run handled 3,600 requests over seven minutes. Its detector did not reliably identify the benchmark’s injected CPU fault, so it remains advisory and the operator still requires human approval. CloudSim Plus and AIOpsLab are included as evaluation integrations; they are not the same thing as the live three-zone service.

Workload recipes are hand-written for repeatable experiments. Public AIOps Challenge data is used for the CPU-fault model, while a Google cluster trace is replayed separately in CloudSim for placement-policy comparisons. See the evaluation report and context guide for details and limitations.
