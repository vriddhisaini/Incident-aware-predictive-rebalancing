# Incident-aware rebalancer visual demo

A standalone, dependency-free visual explainer for the capstone project. Scenario buttons only change illustrative UI values; they do not send traffic, call models, or modify Kubernetes.

## Run

From this folder:

```sh
python3 -m http.server 8000 --bind 127.0.0.1
```

Then open http://localhost:8000.

The Grafana and service links on the page require the corresponding Kubernetes port-forwards to be running. The latest-run values are recorded results, while scenario values are illustrative.
