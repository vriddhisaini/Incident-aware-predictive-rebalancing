"""Render a compact SVG comparison chart without third-party dependencies."""

from __future__ import annotations

from html import escape
from pathlib import Path


COLORS = {
    "reactive": "#5470C6",
    "forecast_only": "#91CC75",
    "full_system": "#EE6666",
}


def render_summary_chart(summaries: list[dict[str, float | int | str]], path: Path) -> None:
    if not summaries:
        return
    scenarios = list(dict.fromkeys(str(row["scenario"]) for row in summaries))
    policies = list(dict.fromkeys(str(row["policy"]) for row in summaries))
    width, height = max(1100, len(scenarios) * 150), 800
    left, right = 72, 24
    plot_width = width - left - right
    group_width = plot_width / len(scenarios)
    panel_height, panel_gap = 260, 95
    top1, top2 = 100, 450
    bar_group_width = min(90, group_width * 0.65)
    bar_width = bar_group_width / len(policies)

    def panel(metric: str, title: str, top: int, max_value: float, decimals: int = 0) -> list[str]:
        parts = [f'<text x="{left}" y="{top - 28}" class="panel-title">{escape(title)}</text>']
        chart_bottom = top + panel_height
        for tick in range(5):
            value = max_value * tick / 4
            y = chart_bottom - panel_height * tick / 4
            parts.append(f'<line x1="{left}" y1="{y:.1f}" x2="{width-right}" y2="{y:.1f}" class="grid"/>')
            parts.append(f'<text x="{left-10}" y="{y+4:.1f}" text-anchor="end" class="axis">{value:.{decimals}f}</text>')
        for group_index, scenario in enumerate(scenarios):
            group_center = left + group_width * (group_index + 0.5)
            start_x = group_center - bar_group_width / 2
            for policy_index, policy in enumerate(policies):
                row = next((item for item in summaries
                            if item["scenario"] == scenario and item["policy"] == policy), None)
                value = float(row[metric]) if row else 0.0
                bar_height = panel_height * value / max(1.0, max_value)
                x = start_x + policy_index * bar_width + 2
                y = chart_bottom - bar_height
                color = COLORS.get(policy, "#888888")
                parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{bar_width-4:.1f}" height="{bar_height:.1f}" fill="{color}" rx="2"/>')
                if value > 0:
                    parts.append(f'<text x="{x + (bar_width-4)/2:.1f}" y="{y-5:.1f}" text-anchor="middle" class="value">{value:.{decimals}f}</text>')
            label = scenario.replace("_", " ")
            parts.append(f'<text x="{group_center:.1f}" y="{chart_bottom+18}" text-anchor="middle" class="scenario">{escape(label)}</text>')
        return parts

    max_breaches = max(float(row["minutes_over_either_slo"]) for row in summaries)
    max_replicas = max(float(row["mean_replicas"]) for row in summaries)
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<style>text{font-family:Arial,sans-serif;fill:#222}.title{font-size:23px;font-weight:700}.panel-title{font-size:17px;font-weight:700}.axis{font-size:11px;fill:#555}.scenario{font-size:10px;fill:#444}.value{font-size:10px}.grid{stroke:#ddd;stroke-width:1}.legend{font-size:12px}</style>',
        '<rect width="100%" height="100%" fill="white"/>',
        '<text x="28" y="35" class="title">Three-zone policy sensitivity comparison</text>',
    ]
    legend_x = left
    for policy in policies:
        color = COLORS.get(policy, "#888888")
        parts.append(f'<rect x="{legend_x}" y="53" width="13" height="13" fill="{color}"/>')
        parts.append(f'<text x="{legend_x+19}" y="64" class="legend">{escape(policy.replace("_", " "))}</text>')
        legend_x += 150
    parts.extend(panel("minutes_over_either_slo", "Service impact: minutes over either configured SLO", top1, max(1, max_breaches)))
    parts.extend(panel("mean_replicas", "Resource use: average active replicas", top2, max(1, max_replicas), decimals=1))
    parts.append('</svg>')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(parts), encoding="utf-8")
