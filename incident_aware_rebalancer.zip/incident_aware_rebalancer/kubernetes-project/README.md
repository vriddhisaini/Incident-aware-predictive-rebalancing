# Incident-Aware Rebalancing Simulator

## Unified live demo

The integrated K8s path uses the detector trained on the public AIOps Challenge 2020 release, the same `/incident-risk-cpu` API for its zone sensors and AIOpsLab adapter, and the existing Ollama diagnosis → safety gate → pending approval → Kubernetes operator flow. Run `source scripts/activate_local_toolchain.sh && ./scripts/run_unified_demo.sh` to rebuild the public artifact, refresh the CloudSim batch replay, deploy the local kind stack, and run a workload through the three-zone router. See [the unified flow and measured limitations](docs/UNIFIED_LIVE_DEMO.md). The detector currently performs weakly on its date-held-out test and is advisory; do not use it for automatic action.

The CloudSim trace replay remains an offline placement comparison because the Google scheduler data has no app incident labels. AIOpsLab provides an external fault/workload benchmark and feeds telemetry into the shared detector API; it is not the same application as the project's three-zone demo.

A deterministic Python simulator for comparing reactive, forecast-only, and incident-aware resource policies across three logical zones. It uses only the Python standard library; no cloud account, paid service, or Kubernetes cluster is required.

## Run in VS Code

1. Open this project folder in VS Code.
2. Choose **Terminal → New Terminal**.
3. Run `python3 run.py`.
4. Review `summary.csv` for scenario comparisons and `results.csv` for per-minute data.
5. Open `summary_chart.svg` in VS Code or a browser for a visual comparison of SLO-breach minutes and average replicas.

To save outputs somewhere else, run `python3 run.py --output-dir path/to/output`.

## Policies

- **Reactive:** uses current measured demand and current zone capacity. Decisions take effect one minute later.
- **Forecast-only:** uses a conservative five-minute linear-trend forecast and current measured capacity. It ignores incident risk.
- **Full system:** uses the same forecast and capacity observations, plus an incident-risk signal to route away from a threatened zone.

## Experiments

`experiment_config.json` holds simulator settings, SLO thresholds, and the scenario matrix. The default scenarios cover:

- Normal load.
- Moderate and severe demand bursts.
- Severe Zone B faults with zero, five, or ten minutes of warning.
- A moderate Zone B fault with five minutes of warning.

All policies see the same workload and fault for each scenario. The synthetic warning is provided only to the full-system policy. To explore a new case, add a scenario object to the JSON file and rerun the simulator.

## Outputs and metrics

- `results.csv`: per-minute demand, forecast, traffic shares, replicas, modeled worst-zone latency, errors, utilization, and dropped requests.
- `summary.csv`: latency/error SLO breach minutes, average and p95 modeled worst-zone latency, request-weighted error rate, dropped requests, mean replicas, replica-minutes, and replica changes.
- `summary_chart.svg`: dependency-free visual comparison of service impact and average replica use across scenarios.

Each RPS value is treated as the average rate over a 60-second measurement window when estimating request counts. `p95_worst_zone_latency_ms` is a percentile across simulated minute-level worst-zone estimates, not a measured request-level p95.

## Collect sample-service telemetry

The local sample service and load generator also use only the Python standard library. They produce separate telemetry experiments; they are not part of `run.py`'s simulator output.

1. In a VS Code terminal, start the service: `python3 demo_service.py`.
2. In a second terminal, generate two minutes of local traffic and collect telemetry:

   ```sh
   python3 load_generator.py --rps 10 --duration-seconds 120 --output-dir telemetry/run-1
   ```

3. Inspect `telemetry/run-1/request_log.csv` for client request timings/statuses and `telemetry/run-1/service_metrics.csv` for sampled request rate, rolling p95/error rate, process CPU, and memory high-water mark.
4. Stop the service with `Ctrl+C` in its terminal.

The service binds to `127.0.0.1` by default. It exposes `/health` and Prometheus text metrics at `/metrics`; application requests go to `/work`. The load generator can inject bounded synthetic delay and CPU work. Use `--fail-every N` to return an HTTP 500 for every Nth application request in that run. These controls generate labeled local experiments; they do not represent real incidents.

For multi-phase workloads, use the profiles in `demo_workloads.json`: a five-minute load ramp, a five-minute abrupt fault, and seven-minute fault profiles covering latency, CPU-pressure, and error-rate precursors, an error-only fault, and a severe latency-only fault.

```sh
python3 load_generator.py --profile demo_workloads.json --profile-name latency_precursor_then_fault --output-dir telemetry/precursor-fault
python3 prepare_dataset.py
python3 forecast_baselines.py
```

The workload profiles change request rate and fault settings during a run. The dataset preparation script reads run folders under `telemetry/`, makes one-minute rows, computes lag/trend features from previous windows, and labels a positive only when the current window is healthy and a sustained two-window SLO breach begins within two minutes. It writes `data/processed/telemetry_windows.csv`. The current dataset contains 163 one-minute windows across 31 run groups, with 38 positive labels. It includes three repeated healthy high-CPU negative controls and five repeated healthy calibration runs. This is still a small, scripted prototype dataset.

`forecast_baselines.py` compares one-minute last-value, trailing-mean, and short linear-trend forecasts in a walk-forward diagnostic and writes `data/processed/forecast_baseline_summary.csv`. The current diagnostic contains 114 one-step predictions from the same scripted profiles that generated the data: last-value MAE 1.3596 RPS, trailing-mean MAE 2.1491 RPS, and short-trend MAE 2.2368 RPS. These are not held-out results.

The incident-warning baseline uses latency, error-rate, and CPU signals; request-rate features are excluded so the detector cannot use the scripted low-load lead-in as a shortcut. For a run-level check, run `python3 evaluate_incident_detector.py`. To hold out every run from one entire profile, run `python3 evaluate_incident_detector.py --holdout-profile cpu_pressure_then_fault`. The detector selects one upward threshold using training profiles only, with an F0.5 objective that weights precision more than recall, and compares it with an always-no-warning baseline. The unseen-profile report and predictions are saved under `data/processed/incident_evaluation_profile_cpu_pressure_then_fault/`.

Thresholds are selected on validation runs and measured on held-out runs. Results show the detector is not safe for automatic action: on the healthy high-CPU profile holdout it raised 9 false warnings in 21 healthy windows; on the CPU-fault profile it caught 6 positives but also raised 7 false warnings in 21 windows; and on the error-only fault profile it missed all 6 positive windows. This is evidence of poor generalization, not a reliable incident predictor.

Additional leave-one-profile-out checks show the limits: the severe-latency-only profile catches positives but also produces false alarms. CPU utilization is often selected and appears to be acting as a proxy signal. The profile results and predictions are saved under `data/processed/incident_evaluation_profile_*/`.

To replay held-out detector predictions through the three policy variants, run (replace the prediction path and output folder for another holdout):

```sh
python3 replay_detector_control.py \\
  --predictions data/processed/incident_evaluation_profile_cpu_pressure_then_fault/heldout_predictions.csv \\
  --output data/processed/detector_control_replays/cpu_pressure_then_fault
```

This offline replay scales measured request rate by 24 to produce virtual simulator RPS and maps a positive detector warning to risk 0.9. Both are explicit, uncalibrated assumptions. It also assumes Zone B capacity falls to 35% at measured incident onset. Read `summary.json` for those assumptions and the three-policy comparison; never interpret modeled SLOs as measured service outcomes.

## Local Kubernetes preparation

`Dockerfile`, `k8s/kind-config.yaml`, and `k8s/demo.yaml` define a local kind experiment. The zone names are simulated node labels. With Docker and kind installed and virtualization available, the setup sequence is:

```sh
docker build -t incident-aware-rebalancer:local .
kind create cluster --config k8s/kind-config.yaml
kind load docker-image incident-aware-rebalancer:local --name rebalancer-local
kubectl apply -f k8s/demo.yaml
kubectl -n rebalancer-demo get pods -o wide
curl http://127.0.0.1:8080/health
```

Check that each zone deployment lands on its matching labeled worker and that all pods become Ready before sending traffic. Delete the test cluster with `kind delete cluster --name rebalancer-local`. The adapter is manual by default:

```sh
python3 k8s_rebalance.py example_control_input.json
python3 k8s_rebalance.py example_control_input.json --apply
```

The first command only prints a guarded plan. `--apply` scales the three demo Deployments and updates the traffic weights ConfigMap; use it only after deploying the demo namespace and reviewing the plan. The current detector is not connected to this adapter because its held-out false-alarm and missed-incident results are inadequate. A live cluster was not verified on the current host because local VM startup was denied; see `IMPLEMENTATION_NOTES.md`.

To repeat profiles with a fresh service process for each run, use `python3 experiment_runner.py --profile-name latency_precursor_then_fault --repeats 3`. This runs three seven-minute trials, writes unique batch folders under `telemetry/repeated/`, and rebuilds the combined dataset. It takes about 21 minutes. Run without `--profile-name` to collect all profiles; the batch folder name is timestamped to avoid overwriting earlier runs.

## Limitations

The forecast is a simple hand-built trend baseline; the risk warning is synthetic; and latency, errors, and capacity in the simulator are modeled approximations. The simulator is useful for checking policy wiring and sensitivity to assumptions, not for claiming production performance. The sample service is a local instrumentation workload, not a representative production application. Calibrate the SLO and service model against its telemetry before making research claims. See `IMPLEMENTATION_NOTES.md` for the staged roadmap and progress record.

## Extended architecture implementation

The project now also contains a research-stack implementation: temporal forecast model comparison, grouped incident-model evaluation, a FastAPI model service, per-zone sensing/agents, deterministic Contract-Net negotiation over NATS, local Ollama diagnosis proposals, a pending-approval proposal bridge, a Kubernetes operator with a second safety check, and Prometheus/Grafana plus Chaos Mesh manifests. See [ARCHITECTURE_STATUS.md](ARCHITECTURE_STATUS.md) for what is implemented, exercised, or still blocked, [docs/LOCAL_SETUP.md](docs/LOCAL_SETUP.md) for the multi-service setup, and [cloudsim/README.md](cloudsim/README.md) for the CloudSim trace workflow.

Kubernetes acceptance verified the four-node kind cluster, three-zone platform, NATS, model endpoints, Prometheus targets, Grafana dashboard provisioning, pending-plan inertness, bounded human-approved scale/routing, restoration, and rejection of an invalid plan. In-cluster Ollama inference and a fresh ARM64 Docker image build also passed. The public Google ClusterData shard was converted, then a 5,000-row deterministic sample was replayed in CloudSim Plus under reactive, forecast-only, and full-system placement modes. A full-shard replay is outside the practical local run window. Five healthy calibration runs were added, but the CPU-only AIOpsLab transfer test still missed its single scored injected case; a retry stopped before scoring because of Kafka init-check loops and intermittent Kubernetes API timeouts. The detector remains advisory and automatic actuation stays approval-gated. See the [final evaluation report](data/processed/final_evaluation_report.md) and [architecture status](ARCHITECTURE_STATUS.md) for current evidence and limits.


AIOpsLab integration setup and run instructions are in [integrations/aiopslab/README.md](integrations/aiopslab/README.md).
