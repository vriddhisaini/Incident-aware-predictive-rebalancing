# Final Evaluation Report — Locally Verified Research Prototype

**Generated from recorded artifacts.** Simulator outcomes are model outputs; local SLO calibration uses a small scripted service. AIOpsLab and Kubernetes acceptance have been run locally, with limitations listed below. One public Google ClusterData shard has been replayed through a bounded CloudSim sample.

## Evaluation coverage

- Simulator: 7 scenarios, three policies, refreshed local outputs.
- Incident dataset: 163 minute windows across 31 scripted run groups; held-out metrics use 7 complete run groups.
- Forecast: per-run chronological holdout; 18 evaluated runs. These short traces do not identify daily/weekly seasonality.
- Provisional SLO: p95 latency 300 ms; error rate 1.0%. The collected dataset has 11 known control runs, 19 fault-injected runs, and 1 run without usable labels. Control-run maximum p95 latency median/p95/max was 5.1/80.7/80.7 ms; maximum error-rate median/p95/max was 0.000/0.000/0.000. These scripted runs are descriptive only and do not establish an externally approved SLO.

## Simulator comparison

| Scenario | Policy | Minutes over either modeled SLO | Modeled dropped requests | Mean replicas | Replica changes |
|---|---|---:|---:|---:|---:|
| zone_b_fault_no_early_warning | reactive | 1 | 1965.0 | 10.72 | 6 |
| zone_b_fault_no_early_warning | forecast_only | 1 | 1965.0 | 10.72 | 6 |
| zone_b_fault_no_early_warning | full_system | 1 | 1965.0 | 8.96 | 7 |
| zone_b_fault_5m_warning | reactive | 1 | 1965.0 | 10.72 | 6 |
| zone_b_fault_5m_warning | forecast_only | 1 | 1965.0 | 10.72 | 6 |
| zone_b_fault_5m_warning | full_system | 0 | 0.0 | 8.96 | 7 |
| demand_burst_severe | reactive | 0 | 0.0 | 10.24 | 24 |
| demand_burst_severe | forecast_only | 0 | 0.0 | 11.2 | 42 |
| demand_burst_severe | full_system | 0 | 0.0 | 11.2 | 42 |

A synthetic warning drives the full-system advantage when early enough. This comparison does not validate detector accuracy or live service behavior.

## Incident model held-out results

| Model | Precision | Recall | False-positive rate | TP/FN | FP/TN |
|---|---:|---:|---:|---:|---:|
| lightgbm | 0.625 | 0.833 | 0.130 | 5/1 | 3/20 |
| logistic_regression | 0.833 | 0.833 | 0.043 | 5/1 | 1/22 |
| cusum | 0.207 | 1.000 | 1.000 | 6/0 | 23/0 |

The small grouped test set is too weak to justify automatic actions. Logistic regression detects more positives but raises false alarms; full LightGBM misses more positives.

### CPU-only AIOpsLab transfer model (local grouped holdout)

| Precision | Recall | False-positive rate | Test PR-AUC | Threshold |
|---:|---:|---:|---:|---:|
| 0.462 | 1.000 | 0.304 | 0.462 | 0.611 |

This intentionally uses only CPU and cannot detect faults with no CPU precursor.

### Offline AIOpsLab re-score after adding five healthy calibration runs

| Saved case export | Windows | Max minute-mean CPU (% of one core) | Max counter interval (% of one core) | Mean-feature warnings | Peak-substitution warnings (diagnostic only) |
|---|---:|---:|---:|---:|---:|
| high_cpu | 4 | 10.60 | 33.95 | 2/4 | 3/4 |
| no_fault | 5 | 2.41 | 9.65 | 0/5 | 3/5 |

This applies the refit CPU model and its validation-selected threshold to the previously saved AIOpsLab raw exports; it is not a new cluster trial. The mean-feature path warned in two of four high-CPU windows and zero of five no-fault windows. Peak substitution increased warnings to three of four and three of five, so it remains audit-only and outside the model contract. The single case pair cannot support reliable recall or false-alarm estimates.

### AIOpsLab live transfer checks

| Agent / case | Decision | AIOpsLab score | Max CPU (% of one core) | TTD (s) |
|---|---|---|---:|---:|
| LLM high CPU | Yes | Correct | 6.88 | 12.6 |
| LLM no-fault | No | Correct | 0.00 | 9.1 |
| CPU LightGBM high CPU | No | Incorrect | 10.60 | 10.2 |
| CPU LightGBM no-fault | No | Correct | 2.41 | 4.1 |

The LLM was scored correct on one injected high-CPU case and one no-fault control. The original CPU-only model missed the injected case and correctly returned No on the control. Observed CPU during that injected case peaked at 10.60% one-core minute mean, with a 33.95% peak interval. A later AIOpsLab start initially lacked enough Prometheus counter samples to form a CPU rate; the adapter now retries after a scrape interval. The completed latest pair is recorded below.

The adapter now records both the mean CPU across counter intervals per minute and the peak interval as diagnostic metadata, while the model still consumes only its trained one-minute-mean feature. Peak substitution is outside that feature contract. On the original saved model it produced 1 warning in 4 high-CPU windows and 2 in 5 no-fault windows; after refitting with added controls it produced 3/4 and 3/5 warnings. The increase in no-fault warnings confirms peak substitution is not a safe mapping change.

### Unified live run (2026-11-20, latest run)

The unified runner completed in one invocation: it refreshed the public CPU model, replayed all three CloudSim policies, deployed the three-zone Kubernetes stack, ran the live workload, and evaluated both AIOpsLab cases through the same model API. The AIOpsLab Astronomy Shop benchmark ran after the live workload with the project services paused to fit the local 8 GiB Docker allocation. The project stack was restored after the benchmark. The final two-case artifact is `data/processed/unified_demo/20261120_205258/aiopslab_public_model.json`.

| AIOpsLab case | Decision | Scored result | Mean CPU (% of one core) | Peak interval (% of one core) | TTD (s) |
|---|---|---|---:|---:|---:|
| Injected AdService high CPU | No | Incorrect (miss) | 0.00 | 0.00 | 6.72 |
| No-fault control | No | Correct | 0.00 | 0.00 | 7.08 |

The model emitted no warnings in either case, and AIOpsLab's exported target CPU counters were flat at zero for both cases. The evaluator therefore counted one missed fault and one correct no-fault control, but these measurements do not establish detector transfer quality because the fault case had no measurable target CPU signal. The same run's single 95%-CPU API smoke input scored 0.8548 below the 0.8626 warning threshold, also producing no warning. Treat the CPU model as advisory and keep approval-gated control in place.

The 420-second three-zone live workload scheduled 3,600 requests; 3,600 completed, 60 returned errors (1.67%), observed throughput was 8.57 requests/s, and client p95 latency was 360.45 ms. Against the provisional 300 ms p95 and 1% error limits, this run exceeded both. The run's workload and raw measurements are in `data/processed/unified_demo/20261120_205258/live_workload/`. CloudSim replayed 5,000 trace rows per policy: mean execution time was 288.73 s reactive and 285.57 s for forecast-only and full-system; p95 was 1515.98 s and 1497.73 s respectively. Forecast-only and full-system matched because the modeled risk trigger did not activate.

## Forecast model results

| Model | MAE (RPS) | RMSE (RPS) | sMAPE | 95% interval coverage |
|---|---:|---:|---:|---:|
| holt_winters | 4.442 | 4.723 | 35.636 | 0.333 |
| sarima_1_0_0 | 0.000 | 0.000 | 0.000 | 1.000 |
| seasonal_naive_p3 | 1.667 | 2.887 | 22.222 | 1.000 |

Near-zero SARIMA errors on flat scripted segments indicate unsuitable test traces/overfit behavior, not forecasting success.

## CloudSim Plus policy comparison

| Placement policy | Workload rows | Successful Cloudlets | Mean execution time (s) | p95 execution time (s) | Mean queue wait (s) |
|---|---:|---:|---:|---:|---:|
| reactive | 5000 | 5000 | 288.73 | 1515.98 | 0.00 |
| forecast_only | 5000 | 5000 | 285.57 | 1497.73 | 0.00 |
| full_system | 5000 | 5000 | 285.57 | 1497.73 | 0.00 |

This is a deterministic 5,000-row sample of one Google ClusterData shard, evenly spaced across its 0–93 minute span. `reactive` preserves trace zone assignments; `forecast_only` routes using a five-minute trailing zone-load estimate; `full_system` adds a high-load risk penalty to that forecast. The trace has no application-fault labels, and the risk penalty did not activate when its threshold was not reached; forecast-only and full-system therefore matched. These are CloudSim placement-policy experiments under coarse CPU assumptions, not evidence of incident-detection benefit or production savings.

## Project finalization status

- **Implemented and locally verified:** three-zone simulator, telemetry pipeline, forecast and incident APIs, NATS negotiation, diagnosis/proposal bridge, operator safety gate, public trace conversion, and bounded CloudSim sample.
- **Kubernetes:** all core deployments and NATS reached Ready. Model endpoints returned valid responses, Ollama `qwen3:0.6b` generated `OK` in-cluster, Prometheus had 9/9 active targets up, and Grafana health plus the provisioned dashboard were verified. A pending plan stayed inert; an approved bounded plan scaled zone A from one to two replicas and changed traffic shares; an approved recovery plan restored the baseline; an invalid plan was rejected without mutation. Acceptance exposed and fixed operator RBAC for Kopf discovery and status writes. A fresh no-cache ARM64 Docker build has now completed, and the built image returned a healthy model-service response.
- **AIOpsLab:** the unified run completed both cases: LightGBM missed the injected high-CPU case and returned No for the no-fault control. The latest measurements and raw evidence are in the 20261120_205258 run directory. Exported CPU counters were flat at zero for the target service, so the transfer case did not provide a useful detector signal. The earlier one-off LLM result is separately recorded above.
- **Ollama:** Ollama 0.40.11 and `qwen3:0.6b` are present. Host and Kubernetes inference succeeded; the AIOpsLab adapter uses host inference for faster evaluation.
- **Public trace:** Downloaded and checksum-recorded one official Google ClusterData 2011-2 task-events shard under CC-BY 4.0. Converted 450,146 events to 109,434 machine-minute rows and 64,868 schedulable workload rows. Scheduler failures are not application incident labels.
- **CloudSim Plus:** a clean Maven compile and deterministic 5,000-row replay ran for reactive, forecast-only, and full-system placement policies. The full 64,868-row replay is computationally impractical in this local run window. The adapter uses coarse CPU-request/MIPS assumptions, does not model RAM/bandwidth, and treats Google scheduler records as workloads rather than service incidents.
- **Finalization decision:** the local research prototype and its core architecture, safety controls, Kubernetes acceptance, public-trace sample, and experiment reports are implemented. The latest unified live run refreshed public-data training, CloudSim replay, the three-zone workload, and both AIOpsLab CPU cases. Evaluation remains limited by weak detector results, scripted/local workload evidence, and an incomplete full-shard trace replay. Automatic actuation remains behind the human approval gate; no production-readiness or detector-generalization claim is made. Chaos Mesh is an optional extension, not a required core acceptance item.

## Reproduce the report

```sh
python calibrate_slo.py
python run.py --output-dir data/processed/safety-evaluation
python forecast_models.py --output-dir data/processed/forecast_models
python train_incident_models.py --output-dir data/processed/incident_models
python train_cpu_incident_model.py
python build_final_report.py
```

Source reports: `data/processed/incident_models/report.json`, `data/processed/incident_models/models/cpu_only_report.json`, `data/processed/forecast_models/report.json`, `data/processed/slo_calibration.json`, `data/processed/safety-evaluation/summary.csv`, and `data/processed/google_trace/cloudsim_*_results.csv`.
