"""Kopf operator: apply only explicitly approved, freshly revalidated plans."""
from __future__ import annotations

import json
import kopf
from kubernetes import client, config

from policies import ZonePlan
from safety import guard_plan

ZONES=("zone-a","zone-b","zone-c")
NAMESPACE="rebalancer-demo"


def validate_and_apply(spec: dict, apps: client.AppsV1Api, core: client.CoreV1Api, namespace: str=NAMESPACE) -> dict:
    if spec.get("approved") is not True:
        return {"phase":"AwaitingApproval","reason":"a human must set spec.approved=true"}
    scale=[apps.read_namespaced_deployment_scale(f"demo-{z}",namespace).spec.replicas for z in ZONES]
    cm=core.read_namespaced_config_map("traffic-weights",namespace)
    weights=json.loads(cm.data["weights.json"])
    shares=tuple(float(weights.get(z,0)) for z in ZONES)
    current=ZonePlan(tuple(int(x) for x in scale),shares)
    desired=ZonePlan(tuple(int(x) for x in spec["replicas"]),tuple(float(x) for x in spec["traffic_shares"]))
    decision=guard_plan(current,desired,tuple(float(x) for x in spec["zone_capacity"]),
                        int(spec.get("min_replicas",1)),int(spec.get("max_replicas",10)),
                        int(spec.get("max_replica_step",2)),float(spec.get("max_share_step",.2)),
                        float(spec.get("min_active_share",.02)),tuple(float(x) for x in spec["incident_risk"]))
    if decision.status=="rejected": return {"phase":"Rejected","reasons":list(decision.reasons)}
    desired_replicas=dict(zip(ZONES,decision.plan.replicas))
    # Safer application order: add capacity first, then route, then remove capacity.
    for zone in ZONES:
        if desired_replicas[zone]>current.replicas[ZONES.index(zone)]:
            apps.patch_namespaced_deployment_scale(f"demo-{zone}",namespace,{"spec":{"replicas":desired_replicas[zone]}})
    weights_json=json.dumps(dict(zip(ZONES,decision.plan.traffic_shares)),separators=(",",":"))
    core.patch_namespaced_config_map("traffic-weights",namespace,{"data":{"weights.json":weights_json}})
    for zone in ZONES:
        if desired_replicas[zone]<current.replicas[ZONES.index(zone)]:
            apps.patch_namespaced_deployment_scale(f"demo-{zone}",namespace,{"spec":{"replicas":desired_replicas[zone]}})
    return {"phase":"Applied","replicas":decision.plan.replicas,"traffic_shares":decision.plan.traffic_shares,
            "reasons":list(decision.reasons)}


@kopf.on.startup()
def startup(settings: kopf.OperatorSettings, **_):
    settings.persistence.finalizer = "rebalancer.example.org/finalizer"
    try: config.load_incluster_config()
    except config.ConfigException: config.load_kube_config()


@kopf.on.create("rebalancer.example.org","v1alpha1","rebalanceplans")
@kopf.on.update("rebalancer.example.org","v1alpha1","rebalanceplans")
def reconcile(spec, status, patch, **_):
    if status and status.get("phase") in {"Applied","Rejected"}:
        return status
    if status and status.get("phase")=="AwaitingApproval" and spec.get("approved") is not True:
        return status
    apps=client.AppsV1Api();core=client.CoreV1Api()
    result=validate_and_apply(spec,apps,core)
    patch.status.update(result)
    return result
