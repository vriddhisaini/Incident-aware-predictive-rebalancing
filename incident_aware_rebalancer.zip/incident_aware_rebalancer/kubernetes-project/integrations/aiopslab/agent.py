"""Read-only local Ollama agent adapter for the Microsoft AIOpsLab Orchestrator.

This adapter intentionally exposes only telemetry-read APIs and the task's
final submit API. It rejects shell and infrastructure mutation tools.
"""
from __future__ import annotations

import ast
import json
import os
import re
import socket
import subprocess
import time
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit
from typing import Any
from urllib.request import Request, urlopen

from metrics_adapter import CPU_FILE, add_lags, cpu_minute_series, find_export_dir


class ActionRejected(ValueError):
    pass


_CODE_BLOCK = re.compile(r"```\s*\n(.*?)\n```", re.DOTALL)


def parse_safe_action(response: str, allowed_actions: set[str]) -> str:
    """Validate one AIOpsLab API call using literals only; return normalized call."""
    blocks = _CODE_BLOCK.findall(response or "")
    if len(blocks) != 1:
        raise ActionRejected("expected exactly one fenced API call")
    try:
        expr = ast.parse(blocks[0].strip(), mode="eval").body
    except SyntaxError as exc:
        raise ActionRejected("API call is not valid syntax") from exc
    if not isinstance(expr, ast.Call) or not isinstance(expr.func, ast.Name):
        raise ActionRejected("only a direct API function call is accepted")
    name = expr.func.id
    if name not in allowed_actions or not (name == "submit" or name.startswith("get_") or name.startswith("read_")):
        raise ActionRejected(f"API is not allowed for this task: {name}")
    if any(keyword.arg is None for keyword in expr.keywords):
        raise ActionRejected("argument unpacking is not allowed")
    try:
        args = [ast.literal_eval(node) for node in expr.args]
        kwargs = {kw.arg: ast.literal_eval(kw.value) for kw in expr.keywords}
    except (ValueError, TypeError) as exc:
        raise ActionRejected("API arguments must be literal values") from exc
    if name == "submit":
        if len(args) != 1 or kwargs or not isinstance(args[0], str) or args[0].lower() not in {"yes", "no"}:
            raise ActionRejected("this adapter supports detection tasks: submit(\"Yes\") or submit(\"No\")")
        args = ["Yes" if args[0].lower() == "yes" else "No"]
    if len(json.dumps([args, kwargs], ensure_ascii=False)) > 4000:
        raise ActionRejected("API arguments exceed the size limit")
    call_args = [repr(value) for value in args]
    call_args.extend(f"{key}={value!r}" for key, value in kwargs.items())
    return f"{name}({', '.join(call_args)})"


class LightGBMAIOpsLabAgent:
    """CPU-only LightGBM transfer agent for CPU-fault/no-op detection cases."""
    def __init__(self, namespace: str="astronomy-shop", model_api: str="http://127.0.0.1:8000",
                 pod_pattern: str="ad", timeout_s: int=20):
        self.namespace=namespace
        self.model_api=model_api.rstrip("/")
        self.pod_pattern=pod_pattern
        self.timeout_s=timeout_s
        self._model_port_forward=None
        self.allowed_actions=set()
        self._requested_metrics=False
        self._metric_retries=0
        self.report={"model":"public_aiops2020_cpu_fault_lightgbm","namespace":namespace,"pod_pattern":pod_pattern,
                     "training_dataset":"AIOps Challenge 2020 public release"}

    def init_context(self, problem_desc: str, instructions: str, apis: dict[str,str]):
        safe={n for n in apis if n=="submit" or n.startswith("get_") or n.startswith("read_")}
        if "get_metrics" not in safe or "submit" not in safe:
            raise ActionRejected("CPU transfer benchmark needs get_metrics and submit actions")
        self.allowed_actions=safe
        self._requested_metrics=False
        self._metric_retries=0

    def _ensure_model_api(self) -> None:
        """Reconnect a local model endpoint if its shell-owned port-forward exited."""
        try:
            with urlopen(self.model_api+"/health", timeout=2) as response:
                if response.status == 200:
                    return
        except Exception:
            pass
        parsed=urlsplit(self.model_api)
        if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost"}:
            raise ConnectionError(f"Model API is not reachable: {self.model_api}")
        if self._model_port_forward is not None and self._model_port_forward.poll() is None:
            self._model_port_forward.terminate()
            try:
                self._model_port_forward.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self._model_port_forward.kill()
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            local_port=sock.getsockname()[1]
        self._model_port_forward=subprocess.Popen(
            ["kubectl", "-n", "rebalancer-demo", "port-forward", "svc/ml-service",
             f"{local_port}:8000"],
            stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT,
        )
        self.model_api=urlunsplit((parsed.scheme, f"127.0.0.1:{local_port}", parsed.path.rstrip("/"), "", ""))
        deadline=time.monotonic()+30
        while time.monotonic()<deadline:
            if self._model_port_forward.poll() is not None:
                break
            try:
                with urlopen(self.model_api+"/health", timeout=2) as response:
                    if response.status == 200:
                        return
            except Exception:
                time.sleep(.5)
        self.close()
        raise ConnectionError("Could not restore the local model API port-forward")

    def close(self) -> None:
        if self._model_port_forward is not None and self._model_port_forward.poll() is None:
            self._model_port_forward.terminate()
            try:
                self._model_port_forward.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self._model_port_forward.kill()

    def _score_export(self, state: str) -> bool:
        export=find_export_dir(state)
        series=add_lags(cpu_minute_series(export,self.pod_pattern))
        if not series: raise ActionRejected("AIOpsLab export contained no CPU observations")
        observations=[]
        for r in series:
            observations.append({"process_cpu_percent_1_core_mean":r["process_cpu_percent_1_core_mean"],
                                 "cpu_lag_1":r.get("cpu_lag_1"),"cpu_mean_prev_3":r.get("cpu_mean_prev_3"),
                                 "cpu_delta_from_prev_3":(r["process_cpu_percent_1_core_mean"]-r["cpu_mean_prev_3"])
                                 if r.get("cpu_mean_prev_3") is not None else None})
        body={"zone":"aiopslab-target-service","observations":observations}
        self._ensure_model_api()
        req=Request(self.model_api+"/incident-risk-cpu",data=json.dumps(body).encode(),headers={"Content-Type":"application/json"})
        with urlopen(req,timeout=self.timeout_s) as response: score=json.loads(response.read())
        warnings=score.get("incident_warnings",[])
        if len(warnings)!=len(series): raise ActionRejected("CPU model returned a misaligned prediction series")
        self.report.update({"export_dir":str(export),"cpu_windows":len(series),"max_cpu_percent_one_core":max(r["process_cpu_percent_1_core_mean"] for r in series),
                            "peak_counter_interval_percent_one_core":max(r["process_cpu_percent_1_core_max"] for r in series),
                            "counter_intervals_by_minute":[r["cpu_counter_intervals"] for r in series],
                            "threshold":score.get("threshold"),"risk_scores":score.get("risk_scores"),"warnings":warnings,
                            "decision":"Yes" if any(warnings) else "No"})
        return any(warnings)

    async def get_action(self, state: str) -> str:
        if not self._requested_metrics:
            self._requested_metrics=True
            return f'```\nget_metrics({self.namespace!r}, duration=5)\n```'
        try:
            detected=self._score_export(str(state))
        except ValueError as exc:
            transient=("no CPU KPI points matched", "did not contain two increasing timestamps")
            if not any(message in str(exc) for message in transient) or self._metric_retries >= 3:
                raise
            # A newly installed Prometheus/target pod needs more than one
            # scrape before its cumulative CPU counter can form a rate. Ask
            # AIOpsLab for another real export after one scrape interval.
            self._metric_retries+=1
            time.sleep(16)
            return f'```\nget_metrics({self.namespace!r}, duration=5)\n```'
        return f'```\nsubmit({"Yes" if detected else "No"!r})\n```'


class OllamaAIOpsLabAgent:
    """AIOpsLab get_action agent using local Ollama and task-scoped read APIs."""

    def __init__(self, base_url: str | None = None, model: str | None = None,
                 timeout_s: int = 90, max_validation_retries: int = 2):
        self.base_url = (base_url or os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")).rstrip("/")
        self.model = model or os.getenv("OLLAMA_MODEL", "qwen3:0.6b")
        self.timeout_s = timeout_s
        self.max_validation_retries = max_validation_retries
        self.cpu_incident_threshold_percent = float(os.getenv("AIOPSLAB_LLM_CPU_THRESHOLD_PERCENT", "80"))
        self.messages: list[dict[str, str]] = []
        self.allowed_actions: set[str] = set()
        self.api_docs: dict[str, str] = {}
        self.problem_desc = ""
        self._metrics_requested = False
        self._metrics_read = False
        self._cpu_series: list[dict] | None = None
        self.report = {"model": self.model, "workflow": "get_metrics -> local CPU summary -> LLM decision",
                       "cpu_incident_threshold_percent": self.cpu_incident_threshold_percent}

    def init_context(self, problem_desc: str, instructions: str, apis: dict[str, str]):
        """Set the prompt context supplied by AIOpsLab's Orchestrator."""
        safe_apis = {
            name: description for name, description in apis.items()
            if name == "submit" or name.startswith("get_") or name.startswith("read_")
        }
        if "submit" not in safe_apis:
            raise ActionRejected("AIOpsLab task did not expose submit")
        if not {"get_metrics", "submit"}.issubset(safe_apis):
            raise ActionRejected("AIOpsLab detection task must expose get_metrics and submit")
        self.allowed_actions = set(safe_apis)
        self.api_docs = safe_apis
        self.problem_desc = problem_desc
        self._metrics_requested = False
        self._metrics_read = False
        self._cpu_series = None
        self.report.update({"allowed_read_actions": sorted(n for n in safe_apis if n.startswith(("get_", "read_")))})
        # Do not forward upstream free-form task examples to the model. Some
        # contain shell examples even though this adapter intentionally allows
        # only read-only telemetry and a final detection submission.
        self.messages = []

    def _call_ollama(self, cpu_series: list[dict]) -> dict[str, str]:
        schema = {
            "type": "object",
            "properties": {
                "decision": {"type": "string", "enum": ["Yes", "No"]},
                "rationale": {"type": "string"},
            },
            "required": ["decision", "rationale"],
            "additionalProperties": False,
        }
        evidence = {
            "task": "Detect whether the Astronomy Shop ad service has an active CPU incident.",
            "metric": "CPU usage as percent of one core, aggregated by minute from AIOpsLab Prometheus data.",
            "decision_criterion": f"Yes only when any observation is at least {self.cpu_incident_threshold_percent:.1f}% of one core; otherwise No.",
            "observations": cpu_series[-12:],
        }
        messages = [
            {
                "role": "system",
                "content": (
                    "Classify whether the supplied ad-service CPU time series shows an active high-CPU incident. "
                    f"Use only the observations provided. Say Yes only if at least one one-minute CPU observation is "
                    f"at or above {self.cpu_incident_threshold_percent:.1f}% of one core; otherwise say No. "
                    "Do not infer an incident from a small increase below the threshold. Return only the required JSON object."
                ),
            },
            {"role": "user", "content": json.dumps(evidence, ensure_ascii=False)},
        ]
        body = {"model": self.model, "stream": False, "think": False,
                "format": schema, "options": {"temperature": 0, "num_predict": 128},
                "messages": messages}
        req = Request(self.base_url + "/api/chat", data=json.dumps(body).encode(),
                      headers={"Content-Type": "application/json"})
        with urlopen(req, timeout=self.timeout_s) as response:
            payload = json.loads(response.read())
        raw = str(payload["message"]["content"])
        self.report["raw_model_response"] = raw[:1200]
        try:
            decision = json.loads(raw)
        except json.JSONDecodeError as exc:
            self.report["response_parse_error"] = str(exc)
            raise ActionRejected("local model response was not valid JSON") from exc
        if not isinstance(decision, dict) or decision.get("decision") not in {"Yes", "No"}:
            self.report["response_parse_error"] = "missing decision Yes/No"
            raise ActionRejected("local model JSON did not contain decision Yes or No")
        return {"decision": decision["decision"], "rationale": str(decision.get("rationale", ""))}

    async def get_action(self, state: str) -> str:
        # The initial tool routing is fixed and read-only. This prevents a small
        # local model from wasting steps choosing among API names or copying
        # unsafe examples embedded in upstream task instructions.
        if not self._metrics_requested:
            self._metrics_requested = True
            self.report["metrics_requested"] = True
            return f'```\nget_metrics("astronomy-shop", duration=5)\n```'

        if not self._metrics_read:
            export_dir = find_export_dir(str(state))
            allowed_root = (Path.cwd() / "metrics_output").resolve()
            resolved_export = export_dir.resolve()
            if not resolved_export.is_relative_to(allowed_root):
                raise ActionRejected("AIOpsLab metrics export was outside the local metrics_output directory")
            cpu_file = resolved_export / "container" / CPU_FILE
            if not cpu_file.is_file():
                raise ActionRejected(f"AIOpsLab CPU metrics file was missing: {cpu_file}")
            self._cpu_series = add_lags(cpu_minute_series(resolved_export, pod_pattern="ad"))
            self.report.update({
                "metrics_export": str(resolved_export),
                "cpu_windows": len(self._cpu_series),
                "cpu_usage_percent_1_core": [row["process_cpu_percent_1_core_mean"] for row in self._cpu_series],
                "cpu_max_percent_1_core": max(row["process_cpu_percent_1_core_mean"] for row in self._cpu_series),
                "cpu_peak_counter_interval_percent_1_core": max(row["process_cpu_percent_1_core_max"] for row in self._cpu_series),
                "counter_intervals_by_minute": [row["cpu_counter_intervals"] for row in self._cpu_series],
                "cpu_meets_incident_threshold": any(
                    row["process_cpu_percent_1_core_mean"] >= self.cpu_incident_threshold_percent
                    for row in self._cpu_series
                ),
            })
            self._metrics_read = True

        if not self._cpu_series:
            raise ActionRejected("AIOpsLab did not provide CPU observations for the ad service")
        decision = self._call_ollama(self._cpu_series)
        self.report.update({"decision": decision["decision"], "rationale": decision["rationale"][:800]})
        return f'```\nsubmit({decision["decision"]!r})\n```'
