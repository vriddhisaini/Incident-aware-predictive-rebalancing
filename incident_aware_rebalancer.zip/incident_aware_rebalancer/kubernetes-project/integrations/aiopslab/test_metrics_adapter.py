import csv
from pathlib import Path
import tempfile
import unittest

from metrics_adapter import add_lags, cpu_minute_series, find_export_dir

class AIOpsLabMetricAdapterTests(unittest.TestCase):
    def test_maps_cpu_cores_to_one_core_percent_with_pod_filter(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/"metrics_output"/"metric_20261027_123456"/"container"
            root.mkdir(parents=True)
            path=root/"kpi_container_cpu_usage_seconds_total.csv"
            with path.open("w",newline="") as f:
                w=csv.DictWriter(f,fieldnames=["timestamp","cmdb_id","kpi_name","value"]);w.writeheader()
                w.writerows([
                    {"timestamp":120,"cmdb_id":"i.adservice-1","kpi_name":"container_cpu_usage_seconds_total","value":0.2},
                    {"timestamp":135,"cmdb_id":"i.adservice-1","kpi_name":"container_cpu_usage_seconds_total","value":4.7},
                    {"timestamp":135,"cmdb_id":"i.other-1","kpi_name":"container_cpu_usage_seconds_total","value":0.9},
                    {"timestamp":180,"cmdb_id":"i.adservice-1","kpi_name":"container_cpu_usage_seconds_total","value":27.2},
                ])
            series=cpu_minute_series(root.parent,"adservice")
            self.assertEqual(series,[
                {"minute":2,"process_cpu_percent_1_core_mean":30.0,"process_cpu_percent_1_core_max":30.0,"cpu_counter_intervals":1},
                {"minute":3,"process_cpu_percent_1_core_mean":50.0,"process_cpu_percent_1_core_max":50.0,"cpu_counter_intervals":1},
            ])
            self.assertEqual(add_lags(series)[1]["cpu_lag_1"],30.0)

    def test_preserves_peak_counter_interval_and_sample_count_for_audit(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/"metrics_output"/"metric_20261027_123456"/"container"
            root.mkdir(parents=True)
            with (root/"kpi_container_cpu_usage_seconds_total.csv").open("w",newline="") as f:
                w=csv.DictWriter(f,fieldnames=["timestamp","cmdb_id","kpi_name","value"]);w.writeheader()
                w.writerows([
                    {"timestamp":120,"cmdb_id":"node.ad-1","kpi_name":"container_cpu_usage_seconds_total","value":0.0},
                    {"timestamp":125,"cmdb_id":"node.ad-1","kpi_name":"container_cpu_usage_seconds_total","value":0.5},
                    {"timestamp":130,"cmdb_id":"node.ad-1","kpi_name":"container_cpu_usage_seconds_total","value":1.5},
                    {"timestamp":180,"cmdb_id":"node.ad-1","kpi_name":"container_cpu_usage_seconds_total","value":11.5},
                ])
            series=cpu_minute_series(root.parent,"ad")
            self.assertEqual(series[0]["process_cpu_percent_1_core_mean"],15.0)
            self.assertEqual(series[0]["process_cpu_percent_1_core_max"],20.0)
            self.assertEqual(series[0]["cpu_counter_intervals"],2)

    def test_rejects_absent_app_cpu_series(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/"container").mkdir()
            with (root/"container"/"kpi_container_cpu_usage_seconds_total.csv").open("w") as f:
                f.write("timestamp,cmdb_id,kpi_name,value\n1,i.other,metric,0.5\n")
            with self.assertRaises(ValueError):cpu_minute_series(root,"adservice")

    def test_extracts_existing_export_path_from_action_response(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/"metrics_output"/"metric_20261027_123456";p.mkdir(parents=True)
            found=find_export_dir(f"{p}\nPlease take the next action")
            self.assertEqual(found,p)

if __name__=="__main__":unittest.main()
