"""Run the local Ollama agent on AIOpsLab detection problems.

AIOpsLab is an external checkout because it has its own license, dependencies,
and application submodules. See README.md in this directory.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import subprocess
import sys
import time
from enum import Enum
from pathlib import Path
from urllib.request import urlopen

from agent import LightGBMAIOpsLabAgent, OllamaAIOpsLabAgent

DEFAULT_PROBLEMS = [
    "astronomy_shop_ad_service_high_cpu-detection-1",
    "noop_detection_astronomy_shop-1",
]


def _json_default(value):
    """Serialize framework enums and path-like values in saved run artifacts."""
    if isinstance(value, Enum):
        return value.value
    return str(value)


def _prometheus_ready() -> bool:
    try:
        with urlopen("http://127.0.0.1:32000/-/ready", timeout=2) as response:
            return response.status == 200
    except Exception:
        return False


def _ensure_prometheus_forward() -> subprocess.Popen | None:
    """Expose AIOpsLab's observe NodePort through kind to the host process."""
    if _prometheus_ready():
        return None
    process = subprocess.Popen(
        ["kubectl", "-n", "observe", "port-forward", "svc/prometheus-server", "32000:80"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT,
    )
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError("AIOpsLab Prometheus port-forward exited before becoming ready")
        if _prometheus_ready():
            return process
        time.sleep(1)
    process.terminate()
    raise TimeoutError("AIOpsLab Prometheus did not become reachable at 127.0.0.1:32000")


def _use_cached_busybox_for_init_containers(namespace: str) -> None:
    """Avoid registry pulls for tiny init images already cached on kind nodes."""
    response = subprocess.run(
        ["kubectl", "-n", namespace, "get", "deployments", "-o", "json"],
        capture_output=True, text=True, check=False,
    )
    if response.returncode != 0:
        raise RuntimeError(f"Could not inspect {namespace} deployments: {response.stderr.strip()}")
    deployments = json.loads(response.stdout).get("items", [])
    for deployment in deployments:
        name = deployment["metadata"]["name"]
        init_containers = deployment.get("spec", {}).get("template", {}).get("spec", {}).get("initContainers", [])
        patches = [
            {"op": "replace", "path": f"/spec/template/spec/initContainers/{index}/imagePullPolicy", "value": "IfNotPresent"}
            for index, container in enumerate(init_containers)
            if container.get("image", "").split(":", 1)[0] == "busybox"
            and container.get("imagePullPolicy") == "Always"
        ]
        if patches:
            patched = subprocess.run(
                ["kubectl", "-n", namespace, "patch", "deployment", name,
                 "--type=json", "-p", json.dumps(patches)],
                capture_output=True, text=True, check=False,
            )
            if patched.returncode != 0:
                raise RuntimeError(f"Could not set cached init image policy for {name}: {patched.stderr.strip()}")


async def run_problem(aiopslab_root: Path, problem_id: str, max_steps: int, agent_kind: str, model_api: str, pod_pattern: str,
                      full_observability: bool = False, reuse_existing_astronomy_shop: bool = False,
                      ensure_astronomy_shop: bool = False) -> dict:
    root = str(aiopslab_root.resolve())
    if root not in sys.path:
        sys.path.insert(0, root)
    from aiopslab.orchestrator import Orchestrator
    from aiopslab.service.kubectl import KubeCtl
    from aiopslab.service.helm import Helm

    if reuse_existing_astronomy_shop or ensure_astronomy_shop:
        from aiopslab.service.apps.astronomy_shop import AstronomyShop
        from aiopslab.service.telemetry.prometheus import Prometheus

        original_delete = AstronomyShop.delete
        original_deploy = AstronomyShop.deploy

        def release_is_deployed() -> bool:
            release = subprocess.run(
                ["helm", "status", "astronomy-shop", "-n", "astronomy-shop"],
                capture_output=True, text=True, check=False,
            )
            return release.returncode == 0 and "STATUS: deployed" in release.stdout

        def wait_for_shop_ready(timeout_s: int = 900) -> None:
            deadline = time.monotonic() + timeout_s
            while True:
                pods = subprocess.run(
                    ["kubectl", "-n", "astronomy-shop", "get", "pods", "-o", "json"],
                    capture_output=True, text=True, check=False,
                )
                if pods.returncode != 0:
                    raise RuntimeError(f"Could not inspect Astronomy Shop pods: {pods.stderr.strip()}")
                pod_items = json.loads(pods.stdout).get("items", [])
                active_pods = [item for item in pod_items if not item["metadata"].get("deletionTimestamp")]
                unready = [
                    item["metadata"]["name"] for item in active_pods
                    if not any(c.get("type") == "Ready" and c.get("status") == "True"
                               for c in item.get("status", {}).get("conditions", []))
                ]
                if active_pods and not unready:
                    return
                if time.monotonic() >= deadline:
                    raise RuntimeError(f"Astronomy Shop pods did not become Ready; unready={unready[:8]}")
                time.sleep(2)

        if reuse_existing_astronomy_shop:
            if not release_is_deployed():
                raise RuntimeError("--reuse-existing-astronomy-shop requires a deployed Helm release")
            wait_for_shop_ready(timeout_s=120)

            def delete_shop(self):
                print("Reusing the preflight-verified Astronomy Shop deployment.")

            def deploy_shop(self):
                print("Reusing the preflight-verified Astronomy Shop deployment.")
        else:
            def delete_shop(self):
                if release_is_deployed():
                    wait_for_shop_ready(timeout_s=120)
                    print("Keeping the ready Astronomy Shop deployment for the case pair.")
                else:
                    print("No ready Astronomy Shop release exists yet; skipping initial delete.")

            def deploy_shop(self):
                if release_is_deployed():
                    wait_for_shop_ready(timeout_s=120)
                    print("Reusing the ready Astronomy Shop deployment for the next case.")
                    return
                original_deploy(self)
                wait_for_shop_ready(timeout_s=900)

        AstronomyShop.delete = delete_shop
        AstronomyShop.deploy = deploy_shop
        # AIOpsLab's Orchestrator calls app.cleanup() after every problem.
        # Keep the verified or newly deployed shop in place so the multi-case
        # run executes fault and no-fault cases against one app deployment.
        # The outer unified runner owns teardown after all cases finish.
        AstronomyShop.cleanup = delete_shop
        # Retain the observability stack across the adjacent cases as well.
        # The caller tears it down only after the complete benchmark finishes.
        Prometheus.teardown = lambda self: print("Keeping Prometheus for the next AIOpsLab case.")

    # AIOpsLab's upstream kind setup installs OpenEBS and waits for every
    # OpenEBS pod. Its disk-discovery pods are not reliable in this Docker
    # Desktop kind cluster, while kind already provides a working local-path
    # StorageClass named "standard". Keep the benchmark local and avoid a
    # remote manifest install or a 30-minute wait on unrelated storage pods.
    has_kind_storage = bool(os.getenv("AIOPSLAB_CLUSTER")) and subprocess.run(
        ["kubectl", "get", "storageclass", "standard", "-o", "name"],
        capture_output=True,
        text=True,
        check=False,
    ).returncode == 0
    if has_kind_storage and not getattr(KubeCtl.exec_command, "_incident_aware_kind_storage", False):
        upstream_kubectl_exec = KubeCtl.exec_command
        base_wait_for_ready = KubeCtl.wait_for_ready
        upstream_wait_for_namespace_deletion = KubeCtl.wait_for_namespace_deletion

        def kind_kubectl_exec(self, command, input_data=None):
            if "https://openebs.github.io/charts/openebs-operator.yaml" in command:
                return "Skipped OpenEBS setup/teardown; using kind StorageClass standard."
            if command.strip().startswith("kubectl patch storageclass openebs-hostpath"):
                return "Skipped OpenEBS default-class patch; using kind StorageClass standard."
            if command.strip().startswith("kubectl delete sc openebs-hostpath openebs-device"):
                return "Preserved existing StorageClasses."
            if "prometheus-pvc.yml" in command and "kubectl apply" in command:
                manifest = Path(command.split("-f", 1)[1].strip().split()[0]).read_text(encoding="utf-8")
                manifest = manifest.replace("storageClassName: openebs-hostpath", "storageClassName: standard")
                return upstream_kubectl_exec(self, "kubectl apply -f - -n observe", input_data=manifest)
            return upstream_kubectl_exec(self, command, input_data=input_data)

        def kind_wait_for_ready(self, namespace, sleep=2, max_wait=1800):
            if namespace == "openebs":
                return
            return base_wait_for_ready(self, namespace, sleep=sleep, max_wait=max_wait)

        def kind_wait_for_namespace_deletion(self, namespace, sleep=2, max_wait=300):
            if namespace == "openebs":
                return
            return upstream_wait_for_namespace_deletion(self, namespace, sleep=sleep, max_wait=max_wait)

        kind_kubectl_exec._incident_aware_kind_storage = True
        KubeCtl.exec_command = kind_kubectl_exec
        KubeCtl.wait_for_ready = kind_wait_for_ready
        KubeCtl.wait_for_namespace_deletion = kind_wait_for_namespace_deletion

    # The Astronomy Shop's Grafana and OpenSearch dashboards are optional for
    # this benchmark: metrics come from AIOpsLab Prometheus, logs from kubectl,
    # and traces from the chart's in-memory Jaeger backend. On a 16 GB Mac,
    # omitting these two chart components avoids roughly 1.8 GiB of configured
    # memory limits and lets the workload fit alongside Docker Desktop.
    if not full_observability and not getattr(Helm.install, "_incident_aware_lightweight", False):
        upstream_helm_install = Helm.install

        def lightweight_helm_install(**args):
            release_name = args.get("release_name")
            if release_name == "astronomy-shop":
                args = dict(args)
                extra_args = list(args.get("extra_args") or [])
                extra_args.extend([
                    "--set", "grafana.enabled=false",
                    "--set", "opensearch.enabled=false",
                ])
                args["extra_args"] = extra_args
            elif release_name == "prometheus":
                args = dict(args)
                extra_args = list(args.get("extra_args") or [])
                extra_args.extend([
                    "--set", "server.persistentVolume.storageClass=standard",
                ])
                args["extra_args"] = extra_args
            if (release_name == "prometheus" and not args.get("remote_chart", False)
                    and list((Path(args["chart_path"]) / "charts").glob("*.tgz"))):
                # AIOpsLab's wrapper always runs `helm dependency update` for
                # local charts. The checked-out chart already has all four
                # dependency archives; skip that network refresh so a cached,
                # reproducible kind run does not block on Helm repository DNS.
                command = ["helm", "install", args["release_name"], args["chart_path"],
                           "-n", args["namespace"], "--create-namespace", *extra_args]
                installed = subprocess.run(command, capture_output=True, text=True, check=False)
                if installed.returncode != 0:
                    raise RuntimeError(f"Cached AIOpsLab Prometheus chart install failed: {installed.stderr.strip()}")
                print(installed.stdout)
                result = installed.stdout
            else:
                result = upstream_helm_install(**args)
            if release_name == "astronomy-shop":
                _use_cached_busybox_for_init_containers(args.get("namespace", "astronomy-shop"))
            return result

        lightweight_helm_install._incident_aware_lightweight = True
        Helm.install = staticmethod(lightweight_helm_install)

    # The first kind run has to download the Astronomy Shop images to every
    # node. Five minutes is too short on a cold local cluster; preserve the
    # upstream polling behavior but allow up to 30 minutes for readiness.
    kind_wait_for_ready = KubeCtl.wait_for_ready

    def wait_for_ready_with_local_image_pull_budget(self, namespace, sleep=2, max_wait=1800):
        return kind_wait_for_ready(self, namespace, sleep=sleep, max_wait=max_wait)

    KubeCtl.wait_for_ready = wait_for_ready_with_local_image_pull_budget

    if agent_kind == "llm":
        agent = OllamaAIOpsLabAgent()
    else:
        agent = LightGBMAIOpsLabAgent(model_api=model_api,pod_pattern=pod_pattern)
    session_dir = Path.cwd() / "data" / "processed" / "aiopslab" / "sessions"
    session_dir.mkdir(parents=True, exist_ok=True)
    orchestrator = Orchestrator(results_dir=session_dir)
    orchestrator.register_agent(agent, name="incident-aware-local-ollama")
    description, instructions, actions = orchestrator.init_problem(problem_id)
    agent.init_context(description, instructions, actions)
    port_forward = _ensure_prometheus_forward()
    try:
        try:
            output = await orchestrator.start_problem(max_steps=max_steps)
        except Exception as exc:
            try:
                exc.agent_diagnostics = getattr(agent, "report", {})
            except Exception:
                pass
            raise
    finally:
        if port_forward is not None:
            port_forward.terminate()
            try:
                port_forward.wait(timeout=5)
            except subprocess.TimeoutExpired:
                port_forward.kill()
        close_agent = getattr(agent, "close", None)
        if close_agent is not None:
            close_agent()
    return {"problem_id": problem_id, "agent": agent_kind, "agent_diagnostics": getattr(agent,"report",{}), "results": output.get("results", {}),
            "final_state": output.get("final_state"), "framework_overhead_s": output.get("framework_overhead")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--aiopslab-root", type=Path, required=True,
                        help="Path to a Microsoft/AIOpsLab checkout with submodules initialized")
    parser.add_argument("--problems", nargs="+", default=DEFAULT_PROBLEMS)
    parser.add_argument("--agent", choices=["llm","cpu-detector"], default="llm",
                        help="Evaluate local Ollama or the CPU-only LightGBM transfer model")
    parser.add_argument("--model-api", default=os.getenv("MODEL_API_URL", "http://127.0.0.1:8000"))
    parser.add_argument("--pod-pattern", default="ad", help="AIOpsLab target pod-name prefix, matched after the node/pod separator")
    parser.add_argument("--max-steps", type=int, default=8)
    parser.add_argument("--full-observability", action="store_true",
                        help="Keep the optional Astronomy Shop Grafana and OpenSearch components enabled")
    parser.add_argument("--reuse-existing-astronomy-shop", action="store_true",
                        help="Reuse an already deployed Astronomy Shop only after verifying Helm and all pod readiness")
    parser.add_argument("--ensure-astronomy-shop", action="store_true",
                        help="Deploy Astronomy Shop if absent, then retain it across the fault/control case pair")
    parser.add_argument("--output", type=Path, default=Path("data/processed/aiopslab/results.json"))
    args = parser.parse_args()
    if not (args.aiopslab_root / "aiopslab" / "orchestrator").is_dir():
        parser.error("--aiopslab-root must point to the AIOpsLab repository root")
    results = []
    model_name = os.getenv("OLLAMA_MODEL", "qwen3:0.6b") if args.agent == "llm" else "public_aiops2020_cpu_fault_lightgbm"

    def save_results() -> None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps({"agent": args.agent, "model": model_name,
                                           "observability_profile": "full" if args.full_observability else "lightweight_no_ui",
                                           "results": results}, indent=2, default=_json_default), encoding="utf-8")

    for problem in args.problems:
        try:
            result = asyncio.run(run_problem(args.aiopslab_root, problem, args.max_steps, args.agent, args.model_api,
                                             args.pod_pattern, args.full_observability, args.reuse_existing_astronomy_shop,
                                             args.ensure_astronomy_shop))
        except Exception as exc:
            results.append({"problem_id": problem, "agent": args.agent,
                            "error": f"{type(exc).__name__}: {exc}",
                            "agent_diagnostics": getattr(exc, "agent_diagnostics", {})})
            save_results()
            raise
        results.append(result)
        # Preserve each completed scenario immediately. If the next scenario
        # fails during its cluster rollout, the earlier benchmark evidence stays usable.
        save_results()
    print(json.dumps(results, indent=2, default=_json_default))


if __name__ == "__main__":
    main()
