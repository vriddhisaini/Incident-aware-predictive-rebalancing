import unittest

from agent import ActionRejected, OllamaAIOpsLabAgent, parse_safe_action


class AIOpsLabAgentTests(unittest.TestCase):
    def test_accepts_only_literal_allowed_call_and_normalizes(self):
        self.assertEqual(parse_safe_action('```\nget_metrics("astronomy-shop", duration=5)\n```',
                                           {"get_metrics", "submit"}),
                         "get_metrics('astronomy-shop', duration=5)")

    def test_rejects_shell_and_mutation_api(self):
        for call in ('exec_shell("kubectl delete ns x")', 'scale_deployment("x", 5)'):
            with self.subTest(call=call), self.assertRaises(ActionRejected):
                parse_safe_action(f"```\n{call}\n```", {"exec_shell", "submit"})

    def test_rejects_code_execution_and_invalid_detection_answer(self):
        with self.assertRaises(ActionRejected):
            parse_safe_action('```\nsubmit(__import__("os").system("id"))\n```', {"submit"})
        with self.assertRaises(ActionRejected):
            parse_safe_action('```\nsubmit("maybe")\n```', {"submit"})


    def test_cpu_agent_requests_metrics_then_submits_model_decision(self):
        import asyncio
        from agent import LightGBMAIOpsLabAgent
        agent=LightGBMAIOpsLabAgent()
        agent.init_context("desc","detect",{"get_metrics":"collect metrics","submit":"answer"})
        first=asyncio.run(agent.get_action("Please take the next action"))
        self.assertIn('get_metrics(\'astronomy-shop\'',first)
        agent._score_export=lambda _state: True
        final=asyncio.run(agent.get_action("metrics_output/metric_20261027_123456"))
        self.assertEqual(final,'```\nsubmit(\'Yes\')\n```')

    def test_context_excludes_mutating_and_shell_apis(self):
        agent = OllamaAIOpsLabAgent()
        agent.init_context("service description", "detect fault", {
            "get_metrics": "read metrics", "read_metrics": "read exported metrics",
            "get_logs": "read logs", "exec_shell": "shell",
            "patch_deployment": "mutate", "submit": "submit result"})
        self.assertEqual(agent.allowed_actions, {"get_metrics", "read_metrics", "get_logs", "submit"})


if __name__ == "__main__":
    unittest.main()
