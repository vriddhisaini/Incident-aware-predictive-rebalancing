# AIOpsLab detection benchmark adapter

This adapter registers the project's **local Ollama model** as an AIOpsLab agent using the framework's `get_action(state) -> str` contract. It is configured to run two built-in Astronomy Shop detection cases: a high-CPU fault and a no-op negative control. AIOpsLab supplies the application, workload, fault lifecycle, telemetry APIs, and task evaluator; the adapter supplies the local LLM agent and saves results.

The agent is deliberately limited to task-provided `get_*` / `read_*` telemetry APIs and the detection task's `submit("Yes"|"No")` action. It rejects shell commands, arbitrary code, infrastructure mutation APIs, and malformed responses. It is a benchmark of the local LLM's interactive incident-detection behavior. It does **not** claim that AIOpsLab's telemetry is interchangeable with the project's scripted training dataset or that it validates the LightGBM detector.

## Prerequisites

AIOpsLab's current setup requires Python 3.11+, Helm, and a working Kubernetes environment (their quick start uses kind and therefore Docker). This Mac now has a project-local Python 3.11 toolchain, Docker Desktop, and a four-node kind cluster. Ollama 0.40.11 with `qwen3:0.6b` is installed, and generation has been verified through the desktop server. Keep the Ollama app running for the adapter.

## Setup

Clone the upstream repository with its application submodules and follow its official cluster setup. Do not place the checkout inside this project:

```sh
git clone --recurse-submodules https://github.com/microsoft/AIOpsLab.git ~/AIOpsLab
cd ~/AIOpsLab
python3.11 -m venv .venv
source .venv/bin/activate
pip install -e .
cp aiopslab/config.yml.example aiopslab/config.yml
```

Configure AIOpsLab for the local kind cluster as described in its setup docs. First-time Astronomy Shop image pulls can exceed five minutes, so this adapter extends AIOpsLab's pod-readiness wait to 30 minutes. AIOpsLab's Prometheus NodePort also needs a host port-forward for this kind config:

```sh
kubectl -n observe port-forward svc/prometheus-server 32000:80
```

Run from this project's root, with the project-local toolchain and its kubeconfig active:

```sh
cd /path/to/incident-aware-rebalancer
source scripts/activate_local_toolchain.sh
export PYTHONPATH=~/AIOpsLab
export AIOPSLAB_CLUSTER=rebalancer-local
OLLAMA_URL=http://127.0.0.1:11434 OLLAMA_MODEL=qwen3:0.6b \
  .toolchain/venv/bin/python integrations/aiopslab/run_detection.py \
  --aiopslab-root ~/AIOpsLab \
  --output data/processed/aiopslab/results.json
```

The default cases are `astronomy_shop_ad_service_high_cpu-detection-1` and `noop_detection_astronomy_shop-1`. They run sequentially and may take several minutes each because AIOpsLab deploys the app, starts its workload, injects/recovers faults, and collects telemetry. Results include task metrics and framework overhead. Preserve the full session artifacts alongside the summary.

On this 16 GB development Mac, the runner uses a lightweight Astronomy Shop profile by default: it disables the optional Grafana and OpenSearch dashboard components, while retaining AIOpsLab Prometheus metrics, `kubectl` logs, and the chart's in-memory Jaeger traces. Use `--full-observability` to keep Grafana and OpenSearch enabled. The selected profile is recorded in the results JSON. This changes the supporting visualization stack, not the application services or benchmark fault/control cases.

For a kind cluster that already has the `standard` local-path StorageClass, the adapter skips AIOpsLab's remote OpenEBS install/readiness/teardown steps and preserves that shared class. The local cluster's existing OpenEBS release had non-ready disk-discovery pods, so waiting for it blocked every benchmark before application deployment. AIOpsLab's Prometheus PVC is mapped to `standard`; Prometheus metrics collection and the benchmark itself remain enabled. This compatibility path activates only when `AIOPSLAB_CLUSTER` is set and `standard` exists.

For the **public-data CPU detector transfer check**, start the model service in another terminal from this project's root. It loads `data/processed/public_aiops2020/models/cpu_fault_detector.joblib`, trained on the AIOps Challenge 2020 public release. The zone sensors use this same endpoint and artifact in the live Kubernetes flow.

```sh
python prepare_public_aiops2020.py
python train_public_aiops2020_cpu.py
uvicorn ml_service:app --host 0.0.0.0 --port 8000
```

Then run:

```sh
python integrations/aiopslab/run_detection.py \
  --aiopslab-root ~/AIOpsLab \
  --agent cpu-detector \
  --pod-pattern ad \
  --output data/processed/aiopslab/cpu-detector-results.json
```

The agent calls AIOpsLab's read-only metric export, reads `container_cpu_usage_seconds_total` rows whose pod name starts with the selected service prefix, converts counter rates to percent of one core, aggregates into minute values, creates causal CPU-history features, and calls `/incident-risk-cpu`. The service-prefix match avoids accidentally including `load-generator` when the target prefix is `ad`. The report stores the signal series, model scores, warnings, and final decision. AIOpsLab's export omits request-rate, p95 latency, and errors; those features are not invented. An empty/missing matching CPU series fails the run instead of silently producing a healthy result.

The public model predicts an *active annotated CPU fault*, not an incident in the future. Its date-held-out test is weak (see `data/processed/public_aiops2020/models/report.json`); the transfer result is exploratory and cannot justify automatic control. The main unified command is `scripts/run_unified_demo.sh`; it exercises the cluster, CloudSim batch comparison, live workload, and this AIOpsLab adapter under one timestamped summary directory.

You can select other *detection* problem IDs present in the checked-out AIOpsLab version with `--problems ID [ID ...]`. Keep the no-op control in the run set so false-positive behavior is measured. Do not use this adapter on localization, analysis, or mitigation tasks: its response validator intentionally supports detection submissions only.

## Tests

The adapter's local unit tests need no AIOpsLab checkout, Kubernetes cluster, or Ollama server:

```sh
python -m unittest discover -s integrations/aiopslab -v
```
