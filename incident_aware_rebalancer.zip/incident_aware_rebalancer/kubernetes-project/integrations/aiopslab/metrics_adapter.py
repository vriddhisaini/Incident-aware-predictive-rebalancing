"""Map AIOpsLab's exported container CPU KPI CSVs into explicit one-core CPU features.

AIOpsLab currently exports container CPU counters, not this project's app p95 and
error metrics. This module supports a CPU-only transfer study and rejects absent,
malformed, or too-short series instead of inventing values for the full detector.
"""
from __future__ import annotations
import csv, math, re
from collections import defaultdict
from pathlib import Path

CPU_FILE="kpi_container_cpu_usage_seconds_total.csv"


def find_export_dir(response_text: str) -> Path:
    """Find the metrics_output/metric_* directory named by the AIOpsLab action."""
    candidates=[]
    for line in str(response_text).splitlines():
        for match in re.findall(r"(?:[A-Za-z0-9_./ -]*metrics_output/)?metric_\d{8}_\d{6}",line):
            path=Path(match.strip())
            candidates.extend((path,Path.cwd()/path))
    for path in candidates:
        if path.is_dir(): return path
    raise ValueError("AIOpsLab get_metrics response did not identify an accessible metrics export directory")


def cpu_minute_series(export_dir: Path, pod_pattern: str="ad") -> list[dict]:
    """Read CPU for a service pod-name prefix, then aggregate into minutes.

    AIOpsLab exports raw *_total counter samples. Convert successive samples to
    cores/second before expressing the result as percent of one core.
    Match the pod name after the final dot, rather than an arbitrary substring
    in the full node.pod label (where "ad" would also match "load-generator").
    """
    path=export_dir/"container"/CPU_FILE
    if not path.is_file(): raise ValueError(f"CPU KPI export not found: {path}")
    counters_by_pod=defaultdict(lambda: defaultdict(list))
    with path.open(newline="",encoding="utf-8") as stream:
        reader=csv.DictReader(stream)
        expected={"timestamp","cmdb_id","value"}
        if not expected.issubset(reader.fieldnames or []): raise ValueError("unexpected AIOpsLab CPU KPI CSV schema")
        for row in reader:
            cmdb_id=row["cmdb_id"].lower()
            pod_name=cmdb_id.rsplit(".",1)[-1]
            prefix=pod_pattern.lower().strip().rstrip("-")
            if pod_name != prefix and not pod_name.startswith(prefix+"-"): continue
            try: timestamp=float(row["timestamp"]); cores=float(row["value"])
            except (ValueError,TypeError): continue
            if math.isfinite(timestamp) and math.isfinite(cores) and cores>=0:
                counters_by_pod[cmdb_id][timestamp].append(cores)
    if not counters_by_pod: raise ValueError(f"no CPU KPI points matched pod-name prefix {pod_pattern!r}")
    per_minute=defaultdict(list)
    for samples in counters_by_pod.values():
        previous_time=None
        previous_counter=None
        for timestamp, values in sorted(samples.items()):
            counter=max(values)
            if previous_time is not None and previous_counter is not None:
                elapsed=timestamp-previous_time
                delta=counter-previous_counter
                # A counter reset is a new baseline, not negative CPU usage.
                if elapsed>0 and delta>=0:
                    per_minute[int(timestamp//60)].append((delta/elapsed)*100.0)
            previous_time=timestamp
            previous_counter=counter
    if not per_minute: raise ValueError("matched CPU counters did not contain two increasing timestamps")
    return [{"minute":minute,
             "process_cpu_percent_1_core_mean":sum(values)/len(values),
             "process_cpu_percent_1_core_max":max(values),
             "cpu_counter_intervals":len(values)}
            for minute,values in sorted(per_minute.items())]


def add_lags(series: list[dict]) -> list[dict]:
    """Retain rows and add causal CPU lag features for audit/analysis."""
    result=[]
    for i,row in enumerate(series):
        previous=[float(x["process_cpu_percent_1_core_mean"]) for x in series[max(0,i-3):i]]
        result.append({**row,"cpu_lag_1":previous[-1] if previous else None,
                       "cpu_mean_prev_3":sum(previous)/len(previous) if previous else None})
    return result
