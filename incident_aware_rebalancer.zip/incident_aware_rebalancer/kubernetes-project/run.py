import argparse
from pathlib import Path

from report import render_summary_chart
from simulator import run


if __name__ == "__main__":
    folder = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Run the three-zone rebalancing experiments")
    parser.add_argument("--config", type=Path, default=folder / "experiment_config.json",
                        help="JSON file with simulation settings and scenarios")
    parser.add_argument("--output-dir", type=Path, default=folder,
                        help="folder for results.csv and summary.csv")
    args = parser.parse_args()

    _, summaries = run(args.config, args.output_dir)
    chart_path = args.output_dir / "summary_chart.svg"
    render_summary_chart(summaries, chart_path)
    print("Policy comparison (same scenarios for all policies)")
    for summary in summaries:
        print(
            f"{summary['scenario']:34} {summary['policy']:14} "
            f"latency-SLO min={summary['minutes_over_latency_slo']:2} "
            f"either-SLO min={summary['minutes_over_either_slo']:2} "
            f"drop={summary['total_dropped_requests']:9} "
            f"mean replicas={summary['mean_replicas']:5} "
            f"changes={summary['replica_changes']:3}"
        )
    print(f"\nDetailed time series: {args.output_dir / 'results.csv'}")
    print(f"Scenario/policy summary: {args.output_dir / 'summary.csv'}")
    print(f"Visual comparison: {chart_path}")
