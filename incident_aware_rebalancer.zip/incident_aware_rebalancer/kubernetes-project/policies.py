"""Deterministic allocation policies used by the simulator."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ZonePlan:
    replicas: tuple[int, int, int]
    traffic_shares: tuple[float, float, float]


def _allocate(
    demand_rps: float,
    zone_capacity: tuple[float, float, float],
    incident_risk: tuple[float, float, float],
    min_replicas: int,
    max_replicas: int,
    capacity_per_replica_rps: float,
    use_incident_risk: bool,
) -> ZonePlan:
    """Spread traffic by usable capacity, optionally discounting risky zones."""
    weights = []
    for i in range(3):
        risk_factor = max(0.05, 1.0 - incident_risk[i]) if use_incident_risk else 1.0
        weights.append(max(0.0, zone_capacity[i]) * risk_factor)
    if sum(weights) == 0:
        weights = [1.0, 1.0, 1.0]
    total_weight = sum(weights)
    shares = [weight / total_weight for weight in weights]

    replicas = []
    for i, share in enumerate(shares):
        demand_for_zone = max(0.0, demand_rps) * share
        usable_capacity = capacity_per_replica_rps * zone_capacity[i] * 0.75
        needed = max(1, int((demand_for_zone / max(1.0, usable_capacity)) + 0.999999))
        replicas.append(min(max_replicas, max(min_replicas, needed)))

    return ZonePlan(tuple(replicas), tuple(shares))


def reactive_policy(
    current_demand_rps: float,
    zone_capacity: tuple[float, float, float],
    incident_risk: tuple[float, float, float],
    min_replicas: int,
    max_replicas: int,
    capacity_per_replica_rps: float,
) -> ZonePlan:
    """React to measured demand and current capacity; ignore forecasts and risk."""
    return _allocate(current_demand_rps, zone_capacity, incident_risk, min_replicas,
                     max_replicas, capacity_per_replica_rps, use_incident_risk=False)


def forecast_policy(
    forecast_demand_rps: float,
    zone_capacity: tuple[float, float, float],
    incident_risk: tuple[float, float, float],
    min_replicas: int,
    max_replicas: int,
    capacity_per_replica_rps: float,
) -> ZonePlan:
    """Plan for forecast demand using current capacity; ignore incident risk."""
    return _allocate(forecast_demand_rps, zone_capacity, incident_risk, min_replicas,
                     max_replicas, capacity_per_replica_rps, use_incident_risk=False)


def full_system_policy(
    forecast_demand_rps: float,
    zone_capacity: tuple[float, float, float],
    incident_risk: tuple[float, float, float],
    min_replicas: int,
    max_replicas: int,
    capacity_per_replica_rps: float,
) -> ZonePlan:
    """Plan for forecast demand while routing away from incident-risk zones."""
    return _allocate(forecast_demand_rps, zone_capacity, incident_risk, min_replicas,
                     max_replicas, capacity_per_replica_rps, use_incident_risk=True)
