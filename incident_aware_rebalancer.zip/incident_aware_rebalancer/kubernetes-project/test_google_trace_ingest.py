import csv
from pathlib import Path
import tempfile
import unittest

from google_trace_ingest import convert


class GoogleTraceTests(unittest.TestCase):
    def test_headerless_google_v1_rows_aggregate_and_keep_event_scope(self):
        with tempfile.TemporaryDirectory() as tmp:
            src=Path(tmp)/"events.csv";dst=Path(tmp)/"windows.csv";meta=Path(tmp)/"meta.json"
            rows=[["60000000","0","1","0","m1","1","u","0","0","0.5","0.2","0",""],
                  ["120000000","0","1","0","m1","3","u","0","0","0.5","0.2","0",""]]
            with src.open("w",newline="") as f:csv.writer(f).writerows(rows)
            result=convert(src,dst,meta)
            with dst.open() as output:
                data=list(csv.DictReader(output))
            self.assertEqual(result["rows_read"],2)
            self.assertEqual(data[0]["schedule_events"],"1")
            self.assertEqual(data[1]["fail_events"],"1")
            self.assertIn("not service-incident labels",result["warning"])

    def test_out_of_order_trace_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            src=Path(tmp)/"events.csv";dst=Path(tmp)/"windows.csv"
            rows=[["120000000","0","1","0","m1","1"],["60000000","0","1","0","m1","1"]]
            with src.open("w",newline="") as f:csv.writer(f).writerows(rows)
            with self.assertRaises(ValueError):convert(src,dst)


if __name__=="__main__":unittest.main()
