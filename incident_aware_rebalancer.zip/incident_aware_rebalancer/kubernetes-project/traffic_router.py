"""Tiny weighted router for the local three-zone Kubernetes demo."""

from __future__ import annotations

import argparse
import http.client
import json
import math
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit


ZONES = ("zone-a", "zone-b", "zone-c")


class WeightedRouter:
    def __init__(self, weights_path: Path) -> None:
        self.weights_path = weights_path
        self.lock = threading.Lock()
        self.weights: dict[str, float] = {}
        self.current: dict[str, float] = {}
        self.events: deque[tuple[float, float, int, str]] = deque(maxlen=10000)
        self.requests_total = 0
        self.errors_total = 0

    def _read_weights(self) -> dict[str, float]:
        raw = json.loads(self.weights_path.read_text(encoding="utf-8"))
        weights = {zone: float(raw.get(zone, 0.0)) for zone in ZONES}
        if any(not math.isfinite(v) or v < 0 for v in weights.values()) or sum(weights.values()) <= 0:
            raise ValueError("traffic weights must be finite, non-negative, and have a positive sum")
        total = sum(weights.values())
        return {zone: value / total for zone, value in weights.items()}

    def choose_zone(self) -> str:
        weights = self._read_weights()
        with self.lock:
            if weights != self.weights:
                self.weights = weights
                self.current = {zone: 0.0 for zone in ZONES}
            total = 0.0
            for zone in ZONES:
                total += weights[zone]
                if weights[zone] > 0:
                    self.current[zone] += weights[zone]
            eligible = [zone for zone in ZONES if weights[zone] > 0]
            chosen = max(eligible, key=lambda zone: (self.current[zone], -ZONES.index(zone)))
            self.current[chosen] -= total
            return chosen

    def record(self, started: float, status: int, zone: str) -> None:
        with self.lock:
            self.events.append((time.monotonic(), (time.monotonic() - started) * 1000, status, zone))
            self.requests_total += 1
            self.errors_total += int(status >= 500)

    def metrics(self) -> str:
        now = time.monotonic()
        with self.lock:
            recent = [event for event in self.events if now - event[0] <= 60]
            ordered = sorted(event[1] for event in recent)
            p95 = ordered[max(0, math.ceil(len(ordered) * .95) - 1)] if ordered else 0.0
            lines = [
                "# HELP router_requests_total Requests routed by the local weighted gateway.",
                "# TYPE router_requests_total counter",
                f"router_requests_total {self.requests_total}",
                "# HELP router_errors_total Failed or 5xx upstream requests.",
                "# TYPE router_errors_total counter",
                f"router_errors_total {self.errors_total}",
                "# HELP router_request_rate_rps Requests in the rolling 60-second window.",
                "# TYPE router_request_rate_rps gauge",
                f"router_request_rate_rps {len(recent) / 60.0:.6f}",
                "# HELP router_p95_latency_ms Rolling client-facing p95 latency.",
                "# TYPE router_p95_latency_ms gauge",
                f"router_p95_latency_ms {p95:.6f}",
            ]
            for zone in ZONES:
                count = sum(event[3] == zone for event in recent)
                lines.extend((f'router_zone_requests_total{{zone="{zone}"}} {count}',))
            return "\n".join(lines) + "\n"


def make_handler(router: WeightedRouter):
    class Handler(BaseHTTPRequestHandler):
        server_version = "IncidentAwareRouter/1.0"

        def log_message(self, _format: str, *_args: object) -> None:
            return

        def _send(self, status: int, body: bytes, content_type: str = "application/json") -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
            if self.path == "/health":
                self._send(200, b'{"status":"ok"}')
                return
            if self.path == "/metrics":
                self._send(200, router.metrics().encode(), "text/plain; version=0.0.4")
                return
            started = time.monotonic()
            zone = "unknown"
            status = 502
            try:
                zone = router.choose_zone()
                parsed = urlsplit(self.path)
                target = parsed.path + ("?" + parsed.query if parsed.query else "")
                connection = http.client.HTTPConnection(f"demo-{zone}", 8080, timeout=5)
                connection.request("GET", target, headers={"Connection": "close"})
                response = connection.getresponse()
                body = response.read()
                status = response.status
                content_type = response.getheader("Content-Type", "application/json")
                connection.close()
                self._send(status, body, content_type)
            except (OSError, ValueError, json.JSONDecodeError, http.client.HTTPException) as exc:
                self._send(502, json.dumps({"error": "upstream unavailable", "detail": str(exc)}).encode())
            finally:
                router.record(started, status, zone)

    return Handler


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the local weighted three-zone router")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--weights", type=Path, default=Path("/etc/traffic/weights.json"))
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.host, args.port), make_handler(WeightedRouter(args.weights)))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
