import unittest
import time

from agents.protocol import CapacityRequest, decode_request, encode
from agents.zone_agent import ZoneAgent, ZoneState, award_best
from diagnosis_agent import ProposalRejected, validate_proposal, validate_proposal_safety
from policies import ZonePlan


class AgentTests(unittest.TestCase):
    def request(self):
        now=time.time()
        return CapacityRequest("req-1", "zone-a", 20, 5, "forecast headroom short", now, now+10)

    def test_request_roundtrip(self):
        request=self.request()
        self.assertEqual(decode_request(encode(request)), request)

    def test_risky_zone_cannot_bid(self):
        agent=ZoneAgent(ZoneState("zone-b", 20, 25, 100, .8, True, 2, 1, 10, 45))
        self.assertFalse(agent.bid(self.request()).feasible)

    def test_capacity_need_must_be_fully_met(self):
        agent=ZoneAgent(ZoneState("zone-b", 70, 70, 100, 0, True, 2, 1, 10, 45))
        self.assertFalse(agent.bid(self.request()).feasible)

    def test_best_bid_tie_breaks_by_zone(self):
        request=self.request()
        a=ZoneAgent(ZoneState("zone-c", 10, 10, 100, 0, True, 2, 1, 10, 45)).bid(request)
        b=ZoneAgent(ZoneState("zone-b", 10, 10, 100, 0, True, 2, 1, 10, 45)).bid(request)
        self.assertEqual(award_best(request,[a,b])[1].provider_zone,"zone-b")

    def test_llm_proposal_rejected_without_flag(self):
        proposal={"root_cause_hypothesis":"x","confidence":.5,"evidence_ids":[],"action":"NO_ACTION",
                  "target_zone":None,"target_replicas":None,"target_traffic_share":None,"explanation":"x"}
        with self.assertRaises(ProposalRejected):
            validate_proposal(proposal,set(),False,{"zone-a":2})

    def test_llm_cannot_cite_unknown_evidence_or_scale_out_down(self):
        base={"root_cause_hypothesis":"x","confidence":.5,"evidence_ids":["missing"],"action":"SCALE_OUT",
              "target_zone":"zone-a","target_replicas":3,"target_traffic_share":None,"explanation":"x"}
        with self.assertRaises(ProposalRejected): validate_proposal(base,set(),True,{"zone-a":2})
        base["evidence_ids"]=[]; base["target_replicas"]=1
        with self.assertRaises(ProposalRejected): validate_proposal(base,set(),True,{"zone-a":2})

    def test_llm_proposal_still_passes_deterministic_safety_gate(self):
        raw={"root_cause_hypothesis":"cpu saturation","confidence":.8,"evidence_ids":["metrics"],"action":"SCALE_OUT",
             "target_zone":"zone-a","target_replicas":8,"target_traffic_share":None,"explanation":"high CPU"}
        proposal=validate_proposal(raw,{"metrics"},True,{"zone-a":2})
        decision=validate_proposal_safety(proposal,ZonePlan((2,2,2),(1/3,1/3,1/3)),(1,1,1))
        self.assertEqual(decision.status,"adjusted")
        self.assertEqual(decision.plan.replicas[0],4)


if __name__=="__main__": unittest.main()
