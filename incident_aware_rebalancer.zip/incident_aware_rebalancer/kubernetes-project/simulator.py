"""Deterministic three-zone simulator and scenario sensitivity harness."""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from controller import ControlSignals, RebalancingController
from policies import ZonePlan, forecast_policy, full_system_policy, reactive_policy


@dataclass(frozen=True)
class Config:
    duration_minutes: int = 75
    min_replicas: int = 1
    max_replicas: int = 10
    initial_replicas_per_zone: int = 2
    capacity_per_replica_rps: float = 45.0
    slo_latency_ms: float = 300.0
    slo_error_rate: float = 0.01
    forecast_horizon_minutes: int = 5
    measurement_window_seconds: int = 60
    max_replica_change_per_minute: int = 2
    max_traffic_share_change_per_minute: float = 0.20
    min_active_zone_traffic_share: float = 0.02


@dataclass(frozen=True)
class Scenario:
    name: str
    kind: str
    parameters: dict[str, float | int]
    demand_trace: tuple[float, ...] | None = None

    def demand(self, minute: int) -> float:
        if self.demand_trace is not None:
            return self.demand_trace[min(minute, len(self.demand_trace) - 1)]
        p = self.parameters
        if self.kind == "normal":
            cycle = max(1, int(p.get("cycle_minutes", 20)))
            phase = (minute % cycle) / max(1, cycle - 1)
            return float(p.get("baseline_rps", 165.0)) + float(p.get("variation_rps", 15.0)) * phase
        if self.kind == "burst":
            baseline = float(p.get("baseline_rps", 165.0))
            peak = float(p["peak_rps"])
            start = int(p.get("ramp_start_minute", 20))
            up = max(1, int(p.get("ramp_up_minutes", 10)))
            hold = max(0, int(p.get("hold_minutes", 15)))
            down = max(1, int(p.get("ramp_down_minutes", 10)))
            elapsed = minute - start
            if elapsed < 0:
                return baseline
            if elapsed < up:
                return baseline + (peak - baseline) * ((elapsed + 1) / up)
            if elapsed < up + hold:
                return peak
            if elapsed < up + hold + down:
                progress = (elapsed - up - hold + 1) / down
                return peak + (baseline - peak) * progress
            return baseline
        if self.kind == "fault":
            return float(p.get("demand_rps", 240.0))
        raise ValueError(f"Unknown scenario kind: {self.kind}")

    def capacity(self, minute: int) -> tuple[float, float, float]:
        p = self.parameters
        if self.kind == "fault" and minute >= int(p.get("fault_start_minute", 30)):
            return (1.0, float(p.get("zone_b_capacity_factor", 0.35)), 1.0)
        return (1.0, 1.0, 1.0)

    def risk(self, minute: int) -> tuple[float, float, float]:
        p = self.parameters
        if self.kind != "fault":
            return (0.0, 0.0, 0.0)
        warning_start = int(p.get("fault_start_minute", 30)) - int(p.get("warning_lead_minutes", 0))
        score = float(p.get("risk_score", 0.9)) if minute >= warning_start else 0.0
        return (0.0, score, 0.0)


POLICIES: dict[str, Any] = {
    "reactive": reactive_policy,
    "forecast_only": forecast_policy,
    "full_system": full_system_policy,
}


def load_experiment(path: Path) -> tuple[Config, tuple[Scenario, ...]]:
    """Load simulation settings and scenario definitions from JSON."""
    with path.open(encoding="utf-8") as stream:
        raw: dict[str, Any] = json.load(stream)
    config = Config(**raw.get("simulation", {}))
    if config.duration_minutes < 1 or config.measurement_window_seconds < 1:
        raise ValueError("Simulation duration and measurement window must be positive")
    if not config.min_replicas <= config.initial_replicas_per_zone <= config.max_replicas:
        raise ValueError("Initial replicas per zone must be between min_replicas and max_replicas")
    scenarios = tuple(
        Scenario(name=item["name"], kind=item["kind"],
                 parameters={k: v for k, v in item.items() if k not in {"name", "kind"}})
        for item in raw["scenarios"]
    )
    if not scenarios:
        raise ValueError("Experiment config must define at least one scenario")
    return config, scenarios


def _forecast(history: list[float], current: float, horizon: int) -> float:
    """Conservative linear-trend forecast using past/current observations only."""
    values = (history + [current])[-6:]
    if len(values) < 2:
        return current
    slope = (values[-1] - values[0]) / (len(values) - 1)
    # This simple baseline forecasts increases but will not scale below observed demand.
    return max(current, current + slope * horizon)


def _service_metrics(
    demand_rps: float,
    plan: ZonePlan,
    capacity_factors: tuple[float, float, float],
    config: Config,
) -> tuple[float, float, float, float]:
    zone_demands = [demand_rps * share for share in plan.traffic_shares]
    capacities = [plan.replicas[i] * config.capacity_per_replica_rps * capacity_factors[i]
                  for i in range(3)]
    utilizations = [zone_demands[i] / max(1.0, capacities[i]) for i in range(3)]
    dropped_rps = sum(max(0.0, zone_demands[i] - capacities[i]) for i in range(3))
    # A simplified per-zone queueing approximation; report the worst zone, not a true
    # end-to-end latency percentile from a measured request distribution.
    worst_zone_latency = max(80.0 + 600.0 * max(0.0, u - 0.65) ** 2 for u in utilizations)
    error_rate = min(1.0, dropped_rps / max(1.0, demand_rps))
    return worst_zone_latency, error_rate, dropped_rps, max(utilizations)


def simulate_scenario(
    scenario: Scenario,
    policy_name: str,
    config: Config,
    risk_trace: tuple[float, ...] | None = None,
    risk_source: str = "synthetic_scenario",
) -> list[dict[str, float | int | str]]:
    """Run one policy/scenario pair; each control decision takes effect next minute."""
    initial = config.initial_replicas_per_zone
    plan = ZonePlan((initial, initial, initial), (1 / 3, 1 / 3, 1 / 3))
    history: list[float] = []
    rows: list[dict[str, float | int | str]] = []
    controller = RebalancingController(config)

    for minute in range(config.duration_minutes):
        demand = scenario.demand(minute)
        capacity_now = scenario.capacity(minute)
        risk_now = ((0.0, min(1.0, max(0.0, risk_trace[min(minute, len(risk_trace) - 1)])), 0.0)
                    if risk_trace is not None else scenario.risk(minute))
        latency, error_rate, dropped_rps, max_utilization = _service_metrics(
            demand, plan, capacity_now, config
        )
        dropped_requests = dropped_rps * config.measurement_window_seconds
        request_volume = demand * config.measurement_window_seconds
        forecast = _forecast(history, demand, config.forecast_horizon_minutes)

        safety_status = "not_evaluated"
        safety_reasons = ""
        proposed_plan = plan
        if minute < config.duration_minutes - 1:
            decision = controller.decide(
                policy_name, plan,
                ControlSignals(
                    observed_demand_rps=demand,
                    forecast_demand_rps=forecast,
                    zone_capacity=capacity_now,
                    incident_risk=risk_now,
                    risk_source=risk_source,
                ),
            )
            proposed_plan = decision.proposed_plan
            next_plan = decision.applied_plan
            safety_status = decision.safety.status
            safety_reasons = "; ".join(decision.safety.reasons)
        else:
            next_plan = plan
        replica_changes = sum(abs(next_plan.replicas[i] - plan.replicas[i]) for i in range(3))
        max_share_change = max(abs(next_plan.traffic_shares[i] - plan.traffic_shares[i]) for i in range(3))

        rows.append({
            "scenario": scenario.name,
            "policy": policy_name,
            "minute": minute,
            "demand_rps": round(demand, 2),
            "forecast_horizon_rps": round(forecast, 2),
            "zone_b_capacity_factor": round(capacity_now[1], 2),
            "zone_b_incident_risk": round(risk_now[1], 2),
            "replicas_a": plan.replicas[0],
            "replicas_b": plan.replicas[1],
            "replicas_c": plan.replicas[2],
            "share_a": round(plan.traffic_shares[0], 3),
            "share_b": round(plan.traffic_shares[1], 3),
            "share_c": round(plan.traffic_shares[2], 3),
            "modeled_worst_zone_latency_ms": round(latency, 2),
            "error_rate": round(error_rate, 4),
            "max_zone_utilization": round(max_utilization, 3),
            "dropped_rps": round(dropped_rps, 2),
            "dropped_requests": round(dropped_requests, 2),
            "request_volume": round(request_volume, 2),
            "total_replicas": sum(plan.replicas),
            "replica_changes": replica_changes,
            "safety_status": safety_status,
            "safety_reasons": safety_reasons,
            "forecast_source": "simulator_baseline",
            "risk_source": risk_source,
            "proposed_replicas_a": proposed_plan.replicas[0],
            "proposed_replicas_b": proposed_plan.replicas[1],
            "proposed_replicas_c": proposed_plan.replicas[2],
            "proposed_share_a": round(proposed_plan.traffic_shares[0], 3),
            "proposed_share_b": round(proposed_plan.traffic_shares[1], 3),
            "proposed_share_c": round(proposed_plan.traffic_shares[2], 3),
            "applied_traffic_share_change": round(max_share_change, 3),
        })
        plan = next_plan
        history.append(demand)

    return rows


def run(
    experiment_path: Path,
    output_dir: Path,
) -> tuple[list[dict[str, float | int | str]], list[dict[str, float | int | str]]]:
    """Run every policy against every configured scenario and write CSV outputs."""
    config, scenarios = load_experiment(experiment_path)
    rows = [row for scenario in scenarios for name in POLICIES
            for row in simulate_scenario(scenario, name, config)]
    summaries = summarize(rows, config, scenarios)
    _write_csv(output_dir / "results.csv", rows)
    _write_csv(output_dir / "summary.csv", summaries)
    return rows, summaries


def _write_csv(path: Path, rows: list[dict[str, float | int | str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def _percentile(values: list[float], percentile: float) -> float:
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, int((len(ordered) - 1) * percentile + 0.999999)))
    return ordered[index]


def summarize(
    rows: list[dict[str, float | int | str]],
    config: Config,
    scenarios: tuple[Scenario, ...],
) -> list[dict[str, float | int | str]]:
    """Calculate service, resource, and stability metrics per policy/scenario."""
    summaries: list[dict[str, float | int | str]] = []
    for scenario in scenarios:
        for policy_name in POLICIES:
            subset = [row for row in rows
                      if row["scenario"] == scenario.name and row["policy"] == policy_name]
            if not subset:
                continue
            latency_values = [float(row["modeled_worst_zone_latency_ms"]) for row in subset]
            request_volume = sum(float(row["request_volume"]) for row in subset)
            dropped_requests = sum(float(row["dropped_requests"]) for row in subset)
            latency_breaches = [row for row in subset
                                if float(row["modeled_worst_zone_latency_ms"]) > config.slo_latency_ms]
            error_breaches = [row for row in subset
                              if float(row["error_rate"]) > config.slo_error_rate]
            summaries.append({
                "scenario": scenario.name,
                "policy": policy_name,
                "minutes_over_latency_slo": len(latency_breaches),
                "minutes_over_error_slo": len(error_breaches),
                "minutes_over_either_slo": len({int(r["minute"]) for r in latency_breaches + error_breaches}),
                "mean_worst_zone_latency_ms": round(sum(latency_values) / len(latency_values), 2),
                "p95_worst_zone_latency_ms": round(_percentile(latency_values, 0.95), 2),
                "overall_error_rate": round(dropped_requests / max(1.0, request_volume), 4),
                "total_dropped_requests": round(dropped_requests, 2),
                "mean_replicas": round(sum(int(r["total_replicas"]) for r in subset) / len(subset), 2),
                "replica_minutes": sum(int(r["total_replicas"]) for r in subset),
                "replica_changes": sum(int(r["replica_changes"]) for r in subset),
                "safety_adjusted_decisions": sum(r["safety_status"] == "adjusted" for r in subset),
                "safety_rejected_decisions": sum(r["safety_status"] == "rejected" for r in subset),
                "max_applied_traffic_share_change": round(max(float(r["applied_traffic_share_change"]) for r in subset), 3),
            })
    return summaries
