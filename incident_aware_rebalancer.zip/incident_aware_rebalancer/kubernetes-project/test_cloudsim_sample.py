import csv
import tempfile
import unittest
from pathlib import Path

from cloudsim_sample import sample_workload


class CloudSimSamplingTests(unittest.TestCase):
    def test_sample_is_deterministic_spans_source_and_records_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "workload.csv"
            with source.open("w", newline="", encoding="utf-8") as stream:
                writer = csv.DictWriter(stream, fieldnames=["cloudlet_id", "minute"])
                writer.writeheader()
                writer.writerows({"cloudlet_id": i, "minute": i // 2} for i in range(11))
            output = root / "sample.csv"
            first = sample_workload(source, output, 5)
            with output.open(newline="", encoding="utf-8") as stream:
                values = list(csv.DictReader(stream))
            second = sample_workload(source, output, 5)
            self.assertEqual(first, second)
            self.assertEqual(len(values), 5)
            self.assertEqual(values[0]["cloudlet_id"], "0")
            self.assertEqual(values[-1]["cloudlet_id"], "10")
            self.assertEqual(first["source_rows"], 11)

    def test_rejects_nonpositive_sample_size(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "workload.csv"
            source.write_text("cloudlet_id,minute\n0,0\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                sample_workload(source, Path(tmp) / "sample.csv", 0)


if __name__ == "__main__":
    unittest.main()
