"""Create a reproducible evenly spaced sample of CloudSim workload rows."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def sample_workload(input_path: Path, output_path: Path, sample_rows: int) -> dict[str, object]:
    if sample_rows < 1:
        raise ValueError("sample_rows must be positive")
    with input_path.open(newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        if not reader.fieldnames:
            raise ValueError("input workload CSV has no header")
        header = list(reader.fieldnames)
        rows = list(reader)
    if not rows:
        raise ValueError("input workload CSV has no workload rows")
    size = min(sample_rows, len(rows))
    if size == len(rows):
        selected = rows
    else:
        # Include the first and last rows and distribute all other selections
        # evenly through the source's existing deterministic order.
        indices = [round(i * (len(rows) - 1) / (size - 1)) for i in range(size)] if size > 1 else [0]
        selected = [rows[index] for index in indices]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as target:
        writer = csv.DictWriter(target, fieldnames=header)
        writer.writeheader()
        writer.writerows(selected)
    metadata = {
        "source": str(input_path),
        "output": str(output_path),
        "source_rows": len(rows),
        "sample_rows": len(selected),
        "sampling": "evenly spaced deterministic indices, including endpoints",
        "first_minute": int(float(selected[0]["minute"])),
        "last_minute": int(float(selected[-1]["minute"])),
    }
    output_path.with_suffix(output_path.suffix + ".metadata.json").write_text(
        json.dumps(metadata, indent=2) + "\n", encoding="utf-8"
    )
    return metadata


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--rows", type=int, default=5000)
    args = parser.parse_args()
    print(json.dumps(sample_workload(args.input, args.output, args.rows), indent=2))


if __name__ == "__main__":
    main()
