"""Convert one explicit controller input into a guarded Kubernetes action plan.

Default mode is read-only and prints JSON. --apply is an explicit opt-in that
scales the three demo Deployments and updates router weights with kubectl.
The incident detector is not run here; inputs must be supplied by the operator.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from controller import ControlSignals, RebalancingController
from policies import ZonePlan
from simulator import Config

ZONES = ("zone-a", "zone-b", "zone-c")


def make_plan(data: dict) -> dict:
    current = ZonePlan(tuple(data["current_replicas"]), tuple(data["current_shares"]))
    signals = ControlSignals(float(data["observed_demand_rps"]), float(data["forecast_demand_rps"]),
                             tuple(data["zone_capacity"]), tuple(data["incident_risk"]),
                             "operator_input", "operator_input")
    decision = RebalancingController(Config()).decide(data.get("policy", "full_system"), current, signals)
    return {"status": decision.safety.status, "reasons": decision.safety.reasons,
            "proposed_replicas": decision.proposed_plan.replicas,
            "applied_replicas": decision.applied_plan.replicas,
            "proposed_shares": decision.proposed_plan.traffic_shares,
            "applied_shares": decision.applied_plan.traffic_shares,
            "explicit_operator_apply_required": True}


def apply_plan(plan: dict) -> None:
    if plan["status"] == "rejected":
        raise ValueError("refusing to apply rejected plan")
    namespace = "rebalancer-demo"
    for zone, replicas in zip(ZONES, plan["applied_replicas"]):
        subprocess.run(["kubectl", "-n", namespace, "scale", f"deployment/demo-{zone}", f"--replicas={replicas}"], check=True)
    weights = json.dumps(dict(zip(ZONES, plan["applied_shares"])), separators=(",", ":"))
    manifest = {"apiVersion": "v1", "kind": "ConfigMap", "metadata": {"name": "traffic-weights", "namespace": namespace},
                "data": {"weights.json": weights}}
    subprocess.run(["kubectl", "apply", "-f", "-"], input=json.dumps(manifest), text=True, check=True)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input", type=Path, help="JSON containing current plan and controller signals")
    p.add_argument("--apply", action="store_true", help="apply guarded action to the demo namespace via kubectl")
    args = p.parse_args()
    plan = make_plan(json.loads(args.input.read_text(encoding="utf-8")))
    print(json.dumps(plan, indent=2))
    if args.apply:
        apply_plan(plan)
        print("Applied to namespace rebalancer-demo")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, subprocess.CalledProcessError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(2)
