"""Deterministic controller interface for separately supplied control signals."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import TYPE_CHECKING

from policies import ZonePlan, forecast_policy, full_system_policy, reactive_policy
from safety import SafetyDecision, guard_plan

if TYPE_CHECKING:
    from simulator import Config


@dataclass(frozen=True)
class ControlSignals:
    observed_demand_rps: float
    forecast_demand_rps: float
    zone_capacity: tuple[float, float, float]
    incident_risk: tuple[float, float, float]
    forecast_source: str = "simulator_baseline"
    risk_source: str = "synthetic_scenario"


@dataclass(frozen=True)
class ControllerDecision:
    proposed_plan: ZonePlan
    applied_plan: ZonePlan
    safety: SafetyDecision


class RebalancingController:
    """Choose a policy action, then pass it through the common safety gate."""

    def __init__(self, config: Config) -> None:
        self.config = config

    def decide(self, policy_name: str, current_plan: ZonePlan,
               signals: ControlSignals) -> ControllerDecision:
        config = self.config
        values = (signals.observed_demand_rps, signals.forecast_demand_rps, *signals.zone_capacity,
                  *signals.incident_risk)
        valid = (
            len(signals.zone_capacity) == 3
            and len(signals.incident_risk) == 3
            and all(math.isfinite(float(value)) for value in values)
            and signals.observed_demand_rps >= 0
            and signals.forecast_demand_rps >= 0
            and all(0 <= value for value in signals.zone_capacity)
            and all(0 <= risk <= 1 for risk in signals.incident_risk)
        )
        if not valid:
            safety = SafetyDecision(current_plan, "rejected", ("control signals are invalid or non-finite",))
            return ControllerDecision(current_plan, current_plan, safety)

        if policy_name == "reactive":
            proposal = reactive_policy(
                signals.observed_demand_rps, signals.zone_capacity, (0.0, 0.0, 0.0),
                config.min_replicas, config.max_replicas, config.capacity_per_replica_rps,
            )
            risk_for_gate = (0.0, 0.0, 0.0)
        elif policy_name == "forecast_only":
            proposal = forecast_policy(
                signals.forecast_demand_rps, signals.zone_capacity, (0.0, 0.0, 0.0),
                config.min_replicas, config.max_replicas, config.capacity_per_replica_rps,
            )
            risk_for_gate = (0.0, 0.0, 0.0)
        elif policy_name == "full_system":
            proposal = full_system_policy(
                signals.forecast_demand_rps, signals.zone_capacity, signals.incident_risk,
                config.min_replicas, config.max_replicas, config.capacity_per_replica_rps,
            )
            risk_for_gate = signals.incident_risk
        else:
            safety = SafetyDecision(current_plan, "rejected", (f"unknown policy: {policy_name}",))
            return ControllerDecision(current_plan, current_plan, safety)

        safety = guard_plan(
            current_plan, proposal, signals.zone_capacity, config.min_replicas, config.max_replicas,
            config.max_replica_change_per_minute, config.max_traffic_share_change_per_minute,
            config.min_active_zone_traffic_share, risk_for_gate,
        )
        return ControllerDecision(proposal, safety.plan, safety)
