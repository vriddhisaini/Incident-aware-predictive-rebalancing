"""Grouped-run incident-risk evaluation: LightGBM, logistic regression, CUSUM.

One-row labels are the project's current two-window warning target. Whole runs
are assigned to fit/validation/test; thresholds are tuned on validation only.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import joblib
import numpy as np
from lightgbm import LGBMClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, confusion_matrix, fbeta_score,
                             precision_recall_curve, precision_score, recall_score)
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

FEATURES = ("request_rate_rps", "p95_latency_ms", "error_rate", "process_cpu_percent_1_core_mean",
            "process_max_rss_bytes", "request_rate_lag_1", "request_rate_mean_prev_3",
            "p95_latency_lag_1", "p95_latency_slope_prev_3", "error_rate_lag_1", "error_rate_mean_prev_3")


def read_dataset(path: Path):
    rows = list(csv.DictReader(path.open(newline="", encoding="utf-8")))
    rows = [r for r in rows if r.get("incident_within_2m", "") in {"0", "1"}]
    x = np.array([[float(r[c]) if r.get(c) not in (None, "") else np.nan for c in FEATURES] for r in rows], dtype=float)
    y = np.array([int(r["incident_within_2m"]) for r in rows], dtype=int)
    groups = np.array([r["run_id"] for r in rows])
    return rows, x, y, groups


def split_groups(y, groups, seed):
    # Deterministically search group splits with both classes in each partition.
    for offset in range(400):
        seed_i = seed + offset
        fit_val_idx, test_idx = next(GroupShuffleSplit(n_splits=1, test_size=.22, random_state=seed_i).split(np.zeros(len(y)), y, groups))
        fit_rel, val_rel = next(GroupShuffleSplit(n_splits=1, test_size=.25, random_state=seed_i+1000).split(np.zeros(len(fit_val_idx)), y[fit_val_idx], groups[fit_val_idx]))
        fit_idx, val_idx = fit_val_idx[fit_rel], fit_val_idx[val_rel]
        if all(len(set(y[idx])) == 2 for idx in (fit_idx, val_idx, test_idx)):
            return fit_idx, val_idx, test_idx
    raise ValueError("could not produce run-grouped fit/validation/test partitions with both labels; collect more independent runs")


def threshold_f05(y, score):
    precision, recall, thresholds = precision_recall_curve(y, score)
    if not len(thresholds):
        return .5
    best = (.0, .5)
    for i, threshold in enumerate(thresholds):
        p, r = precision[i], recall[i]
        f = (1.25*p*r/(.25*p+r)) if p+r else 0
        candidate = (f, float(threshold))
        if candidate[0] > best[0] or (candidate[0] == best[0] and candidate[1] > best[1]):
            best = candidate
    return best[1]


def metrics(y, score, threshold):
    pred = (score >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {"threshold": float(threshold), "precision": float(precision_score(y, pred, zero_division=0)),
            "recall": float(recall_score(y, pred, zero_division=0)), "fpr": float(fp/max(1, fp+tn)),
            "pr_auc": float(average_precision_score(y, score)), "f0_5": float(fbeta_score(y, pred, beta=.5, zero_division=0)),
            "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}


def cusum_scores(rows, indices, center, scale):
    values = np.zeros(len(indices), dtype=float)
    by_run = {}
    for loc, idx in enumerate(indices):
        by_run.setdefault(rows[idx]["run_id"], []).append((loc, idx))
    signal_cols = [FEATURES.index("p95_latency_slope_prev_3"), FEATURES.index("error_rate_mean_prev_3"), FEATURES.index("process_cpu_percent_1_core_mean")]
    for samples in by_run.values():
        accum = 0.0
        for loc, idx in sorted(samples, key=lambda z: int(rows[z[1]]["minute"])):
            z = []
            for j in signal_cols:
                raw = rows[idx].get(FEATURES[j], "")
                v = center[j] if raw in (None, "") else float(raw)
                z.append((v-center[j])/scale[j])
            accum = max(0.0, accum + max(z) - .5)
            values[loc] = accum
    return values


def train(data_path: Path, out_dir: Path, seed: int = 27):
    rows, x, y, groups = read_dataset(data_path)
    fit_idx, val_idx, test_idx = split_groups(y, groups, seed)
    candidates = {
        "lightgbm": LGBMClassifier(n_estimators=90, learning_rate=.04, max_depth=3, num_leaves=7,
                                   min_child_samples=3, class_weight="balanced", verbosity=-1, random_state=seed),
        "logistic_regression": make_pipeline(SimpleImputer(strategy="median", add_indicator=True), StandardScaler(),
                                             LogisticRegression(class_weight="balanced", max_iter=2000, random_state=seed)),
    }
    scores = {}
    reports = {}
    fitted = {}
    for name, model in candidates.items():
        model.fit(x[fit_idx], y[fit_idx])
        val_score = model.predict_proba(x[val_idx])[:, 1]
        threshold = threshold_f05(y[val_idx], val_score)
        test_score = model.predict_proba(x[test_idx])[:, 1]
        reports[name] = {"validation": metrics(y[val_idx], val_score, threshold), "test": metrics(y[test_idx], test_score, threshold)}
        scores[name] = (val_score, test_score, threshold)
        fitted[name] = model
    med = np.nanmedian(x[fit_idx], axis=0)
    filled = np.where(np.isfinite(x[fit_idx]), x[fit_idx], med)
    center = np.nanmean(filled[y[fit_idx] == 0], axis=0)
    scale = np.maximum(np.nanstd(filled[y[fit_idx] == 0], axis=0), 1e-6)
    val_cusum = cusum_scores(rows, val_idx, center, scale)
    cusum_threshold = threshold_f05(y[val_idx], val_cusum)
    test_cusum = cusum_scores(rows, test_idx, center, scale)
    reports["cusum"] = {"validation": metrics(y[val_idx], val_cusum, cusum_threshold), "test": metrics(y[test_idx], test_cusum, cusum_threshold)}
    out_dir.mkdir(parents=True, exist_ok=True)
    model_dir = out_dir / "models"; model_dir.mkdir(exist_ok=True)
    for name, model in fitted.items():
        joblib.dump({"model": model, "features": FEATURES, "threshold": scores[name][2], "model_name": name}, model_dir / f"{name}.joblib")
    joblib.dump({"center": center, "scale": scale, "threshold": cusum_threshold, "features": FEATURES}, model_dir / "cusum.joblib")
    predictions = []
    for name in reports:
        sc = test_cusum if name == "cusum" else scores[name][1]
        threshold = cusum_threshold if name == "cusum" else scores[name][2]
        for i, idx in enumerate(test_idx):
            row = rows[idx]
            onset = row.get("measured_incident_start_minute")
            lead = (int(onset) - int(row["minute"])) if onset not in (None, "") else ""
            predictions.append({"run_id": row["run_id"], "profile_name": row["profile_name"], "minute": row["minute"],
                                "model": name, "actual": int(y[idx]), "score": float(sc[i]), "threshold": float(threshold),
                                "predicted_warning": int(sc[i] >= threshold), "lead_to_measured_onset_minutes": lead})
    with (out_dir / "test_predictions.csv").open("w", newline="", encoding="utf-8") as stream:
        w=csv.DictWriter(stream,fieldnames=list(predictions[0])); w.writeheader(); w.writerows(predictions)
    report = {"split": "whole-run GroupShuffleSplit; 70/30 split of fit+validation; thresholds selected by validation F0.5",
              "seed": seed, "counts": {"rows": len(rows), "positive_rows": int(y.sum()), "fit_rows": len(fit_idx), "validation_rows": len(val_idx), "test_rows": len(test_idx),
                                        "fit_runs": len(set(groups[fit_idx])), "validation_runs": len(set(groups[val_idx])), "test_runs": len(set(groups[test_idx]))},
              "features": list(FEATURES), "models": reports,
              "limitations": ["only 26 scripted local runs", "small test set has wide uncertainty", "CUSUM is a simple statistical comparator", "do not enable automatic actuation based on these results"]}
    (out_dir / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def main():
    root=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input",type=Path,default=root/"data/processed/telemetry_windows.csv")
    p.add_argument("--output-dir",type=Path,default=root/"data/processed/incident_models")
    p.add_argument("--seed",type=int,default=27)
    a=p.parse_args(); print(json.dumps(train(a.input,a.output_dir,a.seed),indent=2))

if __name__=="__main__": main()
