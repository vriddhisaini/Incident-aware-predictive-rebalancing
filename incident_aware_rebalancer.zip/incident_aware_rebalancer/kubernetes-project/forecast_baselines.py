"""Walk-forward one-minute request-rate baselines for collected local traces."""

from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path


def _predictions(history: list[float]) -> dict[str, float]:
    recent = history[-3:]
    last = recent[-1]
    average = sum(recent) / len(recent)
    if len(recent) >= 2:
        slope = (recent[-1] - recent[0]) / (len(recent) - 1)
    else:
        slope = 0.0
    return {
        "last_value": last,
        "trailing_mean_3": average,
        "linear_trend_3": max(0.0, last + slope),
    }


def _measure(actual: list[float], predicted: list[float]) -> tuple[float, float, float]:
    errors = [p - y for y, p in zip(actual, predicted)]
    mae = sum(abs(error) for error in errors) / len(errors)
    rmse = math.sqrt(sum(error * error for error in errors) / len(errors))
    smape_terms = [
        0.0 if abs(y) + abs(p) == 0 else 200.0 * abs(p - y) / (abs(y) + abs(p))
        for y, p in zip(actual, predicted)
    ]
    return mae, rmse, sum(smape_terms) / len(smape_terms)


def _read_groups(path: Path) -> dict[str, list[tuple[int, float]]]:
    groups: dict[str, list[tuple[int, float]]] = defaultdict(list)
    with path.open(newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            groups[row["run_id"]].append((int(row["minute"]), float(row["request_rate_rps"])))
    for rows in groups.values():
        rows.sort(key=lambda item: item[0])
    return groups


def evaluate(path: Path) -> list[dict[str, str | int | float]]:
    groups = _read_groups(path)
    models = ("last_value", "trailing_mean_3", "linear_trend_3")
    per_run: dict[tuple[str, str], tuple[list[float], list[float]]] = {}
    for run_id, windows in groups.items():
        actual_by_model = {model: [] for model in models}
        predicted_by_model = {model: [] for model in models}
        rates = [rate for _, rate in windows]
        for target_index in range(1, len(rates)):
            forecasts = _predictions(rates[:target_index])
            for model in models:
                actual_by_model[model].append(rates[target_index])
                predicted_by_model[model].append(forecasts[model])
        for model in models:
            per_run[(run_id, model)] = (actual_by_model[model], predicted_by_model[model])

    rows: list[dict[str, str | int | float]] = []
    for run_id in groups:
        for model in models:
            actual, predicted = per_run[(run_id, model)]
            if not actual:
                continue
            mae, rmse, smape = _measure(actual, predicted)
            rows.append({"scope": "run", "run_id": run_id, "model": model,
                         "n_predictions": len(actual), "mae_rps": round(mae, 4),
                         "rmse_rps": round(rmse, 4), "smape_pct": round(smape, 2)})

    for model in models:
        actual = [y for (run_id, item_model), (ys, _) in per_run.items() if item_model == model for y in ys]
        predicted = [p for (run_id, item_model), (_, ps) in per_run.items() if item_model == model for p in ps]
        if actual:
            mae, rmse, smape = _measure(actual, predicted)
            rows.append({"scope": "all_runs_diagnostic", "run_id": "all", "model": model,
                         "n_predictions": len(actual), "mae_rps": round(mae, 4),
                         "rmse_rps": round(rmse, 4), "smape_pct": round(smape, 2)})
    return rows


def main() -> None:
    project = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Compare simple one-step request-rate forecast baselines")
    parser.add_argument("--input", type=Path, default=project / "data/processed/telemetry_windows.csv")
    parser.add_argument("--output", type=Path, default=project / "data/processed/forecast_baseline_summary.csv")
    args = parser.parse_args()
    rows = evaluate(args.input)
    if not rows:
        parser.error("Need at least one run with two or more minute windows")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    diagnostic = next(row for row in rows if row["scope"] == "all_runs_diagnostic")
    print(f"Evaluated {diagnostic['n_predictions']} one-minute predictions across collected runs.")
    for row in rows:
        if row["scope"] == "all_runs_diagnostic":
            print(f"{row['model']}: MAE={row['mae_rps']} RPS, RMSE={row['rmse_rps']} RPS, sMAPE={row['smape_pct']}%")
    print(f"Summary: {args.output}")
    print("This is a walk-forward diagnostic on collected profiles, not a held-out model evaluation.")


if __name__ == "__main__":
    main()
