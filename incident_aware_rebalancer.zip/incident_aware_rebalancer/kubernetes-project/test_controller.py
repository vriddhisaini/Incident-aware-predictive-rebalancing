"""Checks that the controller keeps policy inputs distinct and fail-closed."""

import math
import unittest

from controller import ControlSignals, RebalancingController
from policies import ZonePlan
from simulator import Config


class ControllerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.config = Config()
        self.controller = RebalancingController(self.config)
        self.current = ZonePlan((2, 2, 2), (1 / 3, 1 / 3, 1 / 3))

    def test_reactive_uses_observed_demand_and_ignores_risk(self) -> None:
        low = ControlSignals(120, 300, (1, 0.35, 1), (0, 0, 0))
        high = ControlSignals(120, 300, (1, 0.35, 1), (0, 1, 0))
        a = self.controller.decide("reactive", self.current, low)
        b = self.controller.decide("reactive", self.current, high)
        self.assertEqual(a.proposed_plan, b.proposed_plan)

    def test_forecast_only_ignores_incident_risk(self) -> None:
        low = ControlSignals(120, 300, (1, 0.35, 1), (0, 0, 0))
        high = ControlSignals(120, 300, (1, 0.35, 1), (0, 1, 0))
        a = self.controller.decide("forecast_only", self.current, low)
        b = self.controller.decide("forecast_only", self.current, high)
        self.assertEqual(a.proposed_plan, b.proposed_plan)

    def test_full_system_uses_risk_and_applies_safety_gate(self) -> None:
        no_risk = ControlSignals(120, 300, (1, 0.35, 1), (0, 0, 0))
        high_risk = ControlSignals(120, 300, (1, 0.35, 1), (0, 0.9, 0))
        a = self.controller.decide("full_system", self.current, no_risk)
        b = self.controller.decide("full_system", self.current, high_risk)
        self.assertLess(b.applied_plan.traffic_shares[1], a.applied_plan.traffic_shares[1])
        self.assertGreaterEqual(b.applied_plan.traffic_shares[1], self.config.min_active_zone_traffic_share)

    def test_non_finite_signals_are_rejected_without_action(self) -> None:
        invalid = ControlSignals(math.nan, 300, (1, 1, 1), (0, 0, 0))
        result = self.controller.decide("full_system", self.current, invalid)
        self.assertEqual(result.safety.status, "rejected")
        self.assertEqual(result.applied_plan, self.current)


if __name__ == "__main__":
    unittest.main()
