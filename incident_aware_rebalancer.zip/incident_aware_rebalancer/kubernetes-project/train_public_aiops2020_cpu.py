"""Train and evaluate the public-data CPU fault detector with date holdouts."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import joblib
import numpy as np
from lightgbm import LGBMClassifier
from sklearn.metrics import average_precision_score, confusion_matrix, fbeta_score, precision_score, recall_score
from sklearn.model_selection import GroupShuffleSplit

ROOT = Path(__file__).resolve().parent
FEATURES = ("process_cpu_percent_1_core_mean", "cpu_lag_1", "cpu_mean_prev_3", "cpu_delta_from_prev_3")


def _metrics(y: np.ndarray, scores: np.ndarray, threshold: float) -> dict:
    pred = (scores >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {"threshold": float(threshold), "precision": float(precision_score(y, pred, zero_division=0)),
            "recall": float(recall_score(y, pred, zero_division=0)), "fpr": float(fp / max(1, fp + tn)),
            "pr_auc": float(average_precision_score(y, scores)), "f0_5": float(fbeta_score(y, pred, beta=.5, zero_division=0)),
            "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}


def _threshold(y: np.ndarray, scores: np.ndarray) -> float:
    best_f, best_t = -1.0, 0.5
    for t in np.unique(scores):
        f = fbeta_score(y, (scores >= t).astype(int), beta=.5, zero_division=0)
        if (f, float(t)) > (best_f, best_t):
            best_f, best_t = float(f), float(t)
    return best_t


def _split(y: np.ndarray, groups: np.ndarray, seed: int):
    for offset in range(500):
        s = seed + offset
        fitval, test = next(GroupShuffleSplit(n_splits=1, test_size=.22, random_state=s).split(np.zeros(len(y)), y, groups))
        fitrel, valrel = next(GroupShuffleSplit(n_splits=1, test_size=.25, random_state=s + 1000).split(np.zeros(len(fitval)), y[fitval], groups[fitval]))
        fit, val = fitval[fitrel], fitval[valrel]
        if all(len(np.unique(y[ix])) == 2 for ix in (fit, val, test)):
            return fit, val, test
    raise ValueError("could not split whole dates with both active and normal CPU windows; more public fault days are needed")


def train(data_path: Path, output_dir: Path, seed: int = 41) -> dict:
    with data_path.open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise ValueError(f"empty public dataset: {data_path}")
    x = np.asarray([[float(r[c]) if r.get(c, "") else np.nan for c in FEATURES] for r in rows], dtype=float)
    y = np.asarray([int(r["cpu_fault_active"]) for r in rows], dtype=int)
    groups = np.asarray([r["date_group"] for r in rows])
    fit, val, test = _split(y, groups, seed)

    def new_model():
        return LGBMClassifier(n_estimators=90, learning_rate=.04, max_depth=2, num_leaves=3,
                              min_child_samples=8, class_weight="balanced", verbosity=-1, random_state=seed)

    eval_model = new_model()
    eval_model.fit(x[fit], y[fit])
    val_score = eval_model.predict_proba(x[val])[:, 1]
    threshold = _threshold(y[val], val_score)
    test_score = eval_model.predict_proba(x[test])[:, 1]
    report = {"model": "public_aiops2020_cpu_fault_lightgbm", "dataset": "AIOps Challenge 2020 public release",
              "target": "active annotated CPU fault on a matching docker resource", "features": list(FEATURES),
              "split": "whole calendar dates; fit/validation/test; threshold selected on validation F0.5",
              "seed": seed, "counts": {"rows": len(rows), "positive_rows": int(y.sum()), "negative_rows": int((1-y).sum()),
                                       "dates": len(set(groups)), "fit_dates": sorted(set(groups[fit])),
                                       "validation_dates": sorted(set(groups[val])), "test_dates": sorted(set(groups[test]))},
              "validation": _metrics(y[val], val_score, threshold), "test": _metrics(y[test], test_score, threshold),
              "limitations": ["detects active annotated CPU faults; does not predict future faults", "uses CPU level and causal CPU-history features only", "date-held-out test is small and represents this public benchmark", "no automatic actuation; control remains approval-gated"]}

    output_dir.mkdir(parents=True, exist_ok=True)
    model = new_model()
    model.fit(x, y)
    joblib.dump({"model": model, "features": list(FEATURES), "threshold": threshold,
                 "model_name": report["model"], "training_dataset": report["dataset"],
                 "target": report["target"], "training_rows": len(rows)}, output_dir / "cpu_fault_detector.joblib")
    (output_dir / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    pred_path = output_dir / "heldout_predictions.csv"
    with pred_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["date_group", "timestamp_utc", "resource_id", "actual", "risk_score", "threshold", "predicted"])
        for i, score in zip(test, test_score):
            r = rows[int(i)]
            w.writerow([r["date_group"], r["timestamp_utc"], r["resource_id"], y[i], float(score), threshold, int(score >= threshold)])
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=ROOT / "data/processed/public_aiops2020/cpu_fault_windows.csv")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "data/processed/public_aiops2020/models")
    parser.add_argument("--seed", type=int, default=41)
    args = parser.parse_args()
    print(json.dumps(train(args.input, args.output_dir, args.seed), indent=2))


if __name__ == "__main__":
    main()
