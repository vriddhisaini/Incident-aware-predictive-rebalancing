"""Stream the Google Cluster Data task_events export into minute/machine rows.

These are scheduler workload/failure-event traces, not application request or
service-SLO incidents. Use as a supplementary CloudSim/load profile only.
"""
from __future__ import annotations

import argparse
import csv
import gzip
from itertools import chain
import json
from pathlib import Path
from collections import defaultdict

EVENTS={0:"SUBMIT",1:"SCHEDULE",2:"EVICT",3:"FAIL",4:"FINISH",5:"KILL",6:"LOST",7:"UPDATE_PENDING",8:"UPDATE_RUNNING"}
DISRUPTIONS={"EVICT","FAIL","KILL","LOST"}


def _source(path: Path):
    return gzip.open(path,"rt",newline="",encoding="utf-8",errors="replace") if path.suffix==".gz" else path.open(newline="",encoding="utf-8",errors="replace")


def _field(row: list[str], names: dict[str,int], key: str, default=""):
    index=names.get(key)
    return row[index] if index is not None and index<len(row) else default


def convert(input_path: Path, output_path: Path, metadata_path: Path | None = None) -> dict:
    with _source(input_path) as stream:
        reader=csv.reader(stream)
        first=next(reader,None)
        if first is None: raise ValueError("trace input is empty")
        header_names={"time":0,"machine_id":4,"event_type":5,"cpu_request":9,"memory_request":10,
                      "job_id":2,"task_index":3}
        try: int(first[0]); has_header=False
        except (ValueError,IndexError): has_header=True
        if has_header:
            header=[name.strip().lower() for name in first]
            aliases={"time":("time","timestamp","timestamp_usec"),"machine_id":("machine_id","machine"),
                     "event_type":("event_type","event"),"cpu_request":("cpu_request","resource_request_cpu","cpu"),
                     "memory_request":("memory_request","resource_request_memory","memory"),
                     "job_id":("job_id","job"),"task_index":("task_index","task")}
            header_names={key:next((header.index(a) for a in choices if a in header),None) for key,choices in aliases.items()}
        else:
            # Google Cluster Data v1 task_events positional CSV schema.
            reader=chain([first],reader)
        output_path.parent.mkdir(parents=True,exist_ok=True)
        out=output_path.open("w",newline="",encoding="utf-8")
        writer=csv.DictWriter(out,fieldnames=["minute","machine_id","schedule_events","scheduled_cpu_cores_sum","scheduled_memory_sum","evict_events","fail_events","kill_events","lost_events","other_events"])
        writer.writeheader()
        current_minute=None; aggregates=defaultdict(lambda:{"schedule_events":0,"scheduled_cpu_cores_sum":0.0,"scheduled_memory_sum":0.0,"evict_events":0,"fail_events":0,"kill_events":0,"lost_events":0,"other_events":0})
        rows_seen=0; rows_skipped=0; last_minute=-1; output_rows=0
        try:
            for row in reader:
                if not row: continue
                try: minute=int(float(_field(row,header_names,"time")))//60_000_000
                except (ValueError,TypeError): rows_skipped+=1;continue
                if minute<last_minute: raise ValueError("task_events rows must be ordered by timestamp for streaming aggregation")
                if current_minute is not None and minute!=current_minute:
                    for machine,values in sorted(aggregates.items()):
                        writer.writerow({"minute":current_minute,"machine_id":machine,**values});output_rows+=1
                    aggregates.clear()
                current_minute=minute;last_minute=minute;rows_seen+=1
                machine=_field(row,header_names,"machine_id") or "unassigned"
                raw_type=_field(row,header_names,"event_type").strip().upper()
                event=EVENTS.get(int(raw_type),"UNKNOWN") if raw_type.isdigit() else raw_type
                values=aggregates[machine]
                if event=="SCHEDULE":
                    values["schedule_events"]+=1
                    try:values["scheduled_cpu_cores_sum"]+=float(_field(row,header_names,"cpu_request") or 0)
                    except ValueError:pass
                    try:values["scheduled_memory_sum"]+=float(_field(row,header_names,"memory_request") or 0)
                    except ValueError:pass
                elif event in DISRUPTIONS:
                    values[event.lower()+"_events"]+=1
                else:values["other_events"]+=1
            if current_minute is not None:
                for machine,values in sorted(aggregates.items()):
                    writer.writerow({"minute":current_minute,"machine_id":machine,**values});output_rows+=1
        finally:out.close()
    metadata={"dataset":"Google Cluster Data task_events export","source_file":input_path.name,"license":"CC-BY-4.0",
              "attribution":"Google Cluster Data; cite the dataset and source paper as required by its terms.",
              "rows_read":rows_seen,"rows_skipped":rows_skipped,"output_rows":output_rows,
              "warning":"EVICT/FAIL/KILL/LOST are scheduler task events, not service-incident labels; do not mix these labels into the app SLO detector."}
    if metadata_path:
        metadata_path.parent.mkdir(parents=True,exist_ok=True);metadata_path.write_text(json.dumps(metadata,indent=2),encoding="utf-8")
    return metadata


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("input",type=Path);p.add_argument("--output",type=Path,required=True);p.add_argument("--metadata",type=Path);a=p.parse_args()
    print(json.dumps(convert(a.input,a.output,a.metadata),indent=2))

if __name__=="__main__":main()
