"""Checks that detector holdouts stay separated by whole experiment runs."""

import csv
import tempfile
import unittest
from pathlib import Path

from evaluate_incident_detector import evaluate


class DetectorSplitTests(unittest.TestCase):
    def test_leave_one_profile_out_keeps_profile_out_of_fit_and_validation(self) -> None:
        fields = ["run_id", "profile_name", "minute", "incident_within_2m",
                  "p95_latency_ms", "p95_latency_lag_1", "p95_latency_slope_prev_3",
                  "error_rate", "error_rate_lag_1", "error_rate_mean_prev_3",
                  "process_cpu_percent_1_core_mean"]
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "windows.csv"
            with path.open("w", newline="", encoding="utf-8") as stream:
                writer = csv.DictWriter(stream, fieldnames=fields)
                writer.writeheader()
                for profile in ("train_profile", "unseen_profile"):
                    for run_number in range(3):
                        run_id = f"{profile}/run-{run_number}"
                        for minute in range(3):
                            positive = int(minute == 1 and profile == "train_profile")
                            writer.writerow({
                                "run_id": run_id, "profile_name": profile,
                                "minute": minute, "incident_within_2m": positive,
                                "p95_latency_ms": 40 + minute * 30 + positive * 50,
                                "p95_latency_lag_1": 40 + minute * 20,
                                "p95_latency_slope_prev_3": minute * 2,
                                "error_rate": 0.0, "error_rate_lag_1": 0.0,
                                "error_rate_mean_prev_3": 0.0,
                                "process_cpu_percent_1_core_mean": 2 + minute + positive * 5,
                            })
            report, predictions = evaluate(path, "unseen_profile")

        self.assertEqual(report["test_run_count"], 3)
        self.assertTrue(all("unseen_profile" in run for run in report["held_out_runs"]))
        self.assertTrue(all("unseen_profile" not in run for run in report["validation_runs"]))
        self.assertFalse(set(report["fit_runs"]) & set(report["validation_runs"]))
        self.assertFalse(set(report["fit_runs"]) & set(report["held_out_runs"]))
        self.assertFalse(set(report["validation_runs"]) & set(report["held_out_runs"]))
        self.assertEqual(set(report["held_out_runs"]), {row["run_id"] for row in predictions})
        self.assertTrue(all(row["profile_name"] == "unseen_profile" for row in predictions))


if __name__ == "__main__":
    unittest.main()
