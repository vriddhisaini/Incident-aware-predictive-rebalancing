import csv
from pathlib import Path
import tempfile
import unittest
from cloudsim_trace_export import export_windows,zone_for

class CloudSimExportTests(unittest.TestCase):
    def test_exports_workload_and_records_assumptions(self):
        with tempfile.TemporaryDirectory() as tmp:
            src=Path(tmp)/"windows.csv";out=Path(tmp)/"workload.csv"
            with src.open("w",newline="") as f:
                w=csv.DictWriter(f,fieldnames=["minute","machine_id","schedule_events","scheduled_cpu_cores_sum","scheduled_memory_sum"]);w.writeheader()
                w.writerow({"minute":2,"machine_id":"machine-1","schedule_events":3,"scheduled_cpu_cores_sum":1.5,"scheduled_memory_sum":.8})
                w.writerow({"minute":3,"machine_id":"machine-2","schedule_events":0,"scheduled_cpu_cores_sum":0,"scheduled_memory_sum":0})
            meta=export_windows(src,out,1000)
            with out.open() as stream:
                row=next(csv.DictReader(stream))
            self.assertEqual(meta["cloudlet_rows"],1)
            self.assertEqual(row["zone"],zone_for("machine-1"))
            self.assertEqual(int(row["cloudlet_length_mi"]),90000)
            self.assertIn("normalized source units",meta["caveats"][1])

    def test_rejects_invalid_mips(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/"source.csv";p.write_text("x\n")
            with self.assertRaises(ValueError):export_windows(p,Path(tmp)/"out.csv",0)

if __name__=="__main__":unittest.main()
