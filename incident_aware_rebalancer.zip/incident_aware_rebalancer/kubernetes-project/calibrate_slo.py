"""Describe provisional SLO thresholds against collected runs; never changes config."""
from __future__ import annotations
import argparse, csv, json, math
from pathlib import Path

def quantile(values, q):
    if not values: return None
    xs=sorted(values); pos=(len(xs)-1)*q; lo=math.floor(pos); hi=math.ceil(pos)
    return xs[lo] if lo==hi else xs[lo]*(hi-pos)+xs[hi]*(pos-lo)

def calibrate(input_path: Path, output_path: Path, latency_slo: float=300.0, error_slo: float=.01):
    with input_path.open(newline="",encoding="utf-8") as f: rows=list(csv.DictReader(f))
    if not rows: raise ValueError("no telemetry windows")
    grouped={}
    for row in rows: grouped.setdefault(row["run_id"],[]).append(row)
    runs=[]
    for run_id, rs in sorted(grouped.items()):
        profile=rs[0]["profile_name"]
        fault_start=min((int(r["injected_fault_start_minute"]) for r in rs if r.get("injected_fault_start_minute") not in (None,"")),default=None)
        known_control=profile in {"healthy-baseline", "healthy_slo_calibration", "load_ramp_recovery", "cpu_pressure_without_incident"}
        classification="fault" if fault_start is not None else ("control" if known_control else "unknown")
        healthy=[r for r in rs if fault_start is None or int(r["minute"])<fault_start]
        affected=[r for r in rs if fault_start is not None and int(r["minute"])>=fault_start]
        vals=lambda key, subset: [float(r[key]) for r in subset if r.get(key) not in (None,"")]
        runs.append({"run_id":run_id,"profile":profile,"classification":classification,
                     "healthy_windows":len(healthy),"fault_windows":len(affected),
                     "healthy_max_p95_ms":max(vals("p95_latency_ms",healthy),default=None),
                     "healthy_max_error_rate":max(vals("error_rate",healthy),default=None),
                     "affected_median_p95_ms":quantile(vals("p95_latency_ms",affected),.5),
                     "affected_median_error_rate":quantile(vals("error_rate",affected),.5),
                     "healthy_windows_over_provisional_slo":sum(float(r.get("p95_latency_ms") or 0)>=latency_slo or float(r.get("error_rate") or 0)>=error_slo for r in healthy),
                     "affected_windows_over_provisional_slo":sum(float(r.get("p95_latency_ms") or 0)>=latency_slo or float(r.get("error_rate") or 0)>=error_slo for r in affected)})
    controls=[r for r in runs if r["classification"]=="control"]
    faults=[r for r in runs if r["classification"]=="fault" and r["fault_windows"]]
    unknown=[r for r in runs if r["classification"]=="unknown"]
    lat=[r["healthy_max_p95_ms"] for r in controls if r["healthy_max_p95_ms"] is not None]
    err=[r["healthy_max_error_rate"] for r in controls if r["healthy_max_error_rate"] is not None]
    report={"source":str(input_path),"runs":len(runs),"no_fault_runs":len(controls),"fault_injected_runs":len(faults),"unknown_status_runs":len(unknown),
            "provisional_thresholds":{"latency_p95_ms":latency_slo,"error_rate":error_slo},
            "no_fault_run_maxima":{"p95_latency_ms":{"median":quantile(lat,.5),"p95":quantile(lat,.95),"max":max(lat,default=None)},
                                   "error_rate":{"median":quantile(err,.5),"p95":quantile(err,.95),"max":max(err,default=None)}},
            "runs":runs,
            "interpretation":"Descriptive only. Thresholds created labels in this dataset, so these counts are not independent estimates of SLO accuracy. Keep thresholds provisional and freeze final values using separate validation runs and domain-approved SLOs.",
            "limitations":["scripted service and faults", "small number of independent no-fault runs", "latency/error thresholds are not externally validated", "no unseen real incidents"]}
    output_path.parent.mkdir(parents=True,exist_ok=True); output_path.write_text(json.dumps(report,indent=2),encoding="utf-8")
    return report

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--input",type=Path,default=Path("data/processed/telemetry_windows.csv"));p.add_argument("--output",type=Path,default=Path("data/processed/slo_calibration.json"));p.add_argument("--latency-slo-ms",type=float,default=300);p.add_argument("--error-slo",type=float,default=.01);a=p.parse_args();print(json.dumps(calibrate(a.input,a.output,a.latency_slo_ms,a.error_slo),indent=2))
if __name__=="__main__":main()
