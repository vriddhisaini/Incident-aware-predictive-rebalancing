import time
import unittest

from agents.proposal_bridge import ProposalBridge
from diagnosis_agent import DiagnosisProposal
from rebalance_operator import validate_and_apply


class FakeApps:
    def __init__(self):self.replicas={"demo-zone-a":2,"demo-zone-b":2,"demo-zone-c":2};self.calls=[]
    def read_namespaced_deployment_scale(self,name,namespace):
        return type("Scale",(),{"spec":type("Spec",(),{"replicas":self.replicas[name]})()})()
    def patch_namespaced_deployment_scale(self,name,namespace,body):
        self.calls.append(("scale",name,body["spec"]["replicas"]));self.replicas[name]=body["spec"]["replicas"]


class FakeCore:
    def __init__(self):self.weights={"zone-a":1/3,"zone-b":1/3,"zone-c":1/3};self.calls=[]
    def read_namespaced_config_map(self,name,namespace):return type("CM",(),{"data":{"weights.json":__import__("json").dumps(self.weights)}})()
    def patch_namespaced_config_map(self,name,namespace,body):
        self.calls.append(("weights",body["data"]["weights.json"]))
        self.weights=__import__("json").loads(body["data"]["weights.json"])


class FakeCustom:
    def __init__(self):self.created=[]
    def create_namespaced_custom_object(self,group,version,namespace,plural,body):self.created.append(body);return body


class OperatorBridgeTests(unittest.TestCase):
    def test_operator_requires_explicit_human_approval(self):
        apps,core=FakeApps(),FakeCore()
        spec={"approved":False,"replicas":[3,2,2],"traffic_shares":[1/3,1/3,1/3],"zone_capacity":[90]*3,"incident_risk":[0]*3}
        result=validate_and_apply(spec,apps,core)
        self.assertEqual(result["phase"],"AwaitingApproval");self.assertEqual(apps.calls,[]);self.assertEqual(core.calls,[])

    def test_operator_revalidates_and_applies_scale_before_route(self):
        apps,core=FakeApps(),FakeCore()
        spec={"approved":True,"replicas":[4,2,2],"traffic_shares":[.45,.275,.275],"zone_capacity":[90]*3,"incident_risk":[0]*3}
        result=validate_and_apply(spec,apps,core)
        self.assertEqual(result["phase"],"Applied")
        self.assertEqual(apps.calls[0][0],"scale")
        self.assertEqual(core.calls[0][0],"weights")

    def test_bridge_creates_pending_not_approved_plan(self):
        apps,core,custom=FakeApps(),FakeCore(),FakeCustom()
        bridge=ProposalBridge(custom,apps,core)
        now=time.time()
        for z in ("zone-a","zone-b","zone-c"):
            bridge.telemetry[z]={"zone":z,"timestamp":now,"current_rps":10,"forecast_rps":10,"safe_capacity_rps":90,"incident_risk":0,"healthy":True}
        proposal=DiagnosisProposal("cpu pressure",.8,("current_window",),"SCALE_OUT","zone-a",3,None,"CPU rose")
        result=bridge.receive_diagnosis({"proposal":proposal.__dict__})
        self.assertFalse(result["spec"]["approved"])
        self.assertEqual(custom.created[0]["spec"]["source"],"local_llm_diagnosis")

    def test_bridge_refuses_stale_or_missing_zone_telemetry(self):
        bridge=ProposalBridge(FakeCustom(),FakeApps(),FakeCore())
        bridge.telemetry["zone-a"]={"timestamp":time.time()-300}
        with self.assertRaises(ValueError):bridge.current()


if __name__=="__main__":unittest.main()
