"""Replay held-out detector outputs through all three policies (offline only).

Measured request rates are scaled to virtual simulator RPS. This is a scenario
bridge, not a calibrated mapping to production load.
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

from simulator import Config, Scenario, simulate_scenario


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def replay(windows_path: Path, predictions_path: Path, output: Path, demand_scale: float = 24.0) -> dict:
    if demand_scale <= 0:
        raise ValueError("demand scale must be positive")
    windows = read_rows(windows_path)
    preds = read_rows(predictions_path)
    by_run: dict[str, list[dict[str, str]]] = defaultdict(list)
    pred_map = {(r["run_id"], int(r["minute"])): int(r["predicted_warning"]) for r in preds}
    for row in windows:
        if (row["run_id"], int(row["minute"])) in pred_map:
            by_run[row["run_id"]].append(row)
    if not by_run:
        raise ValueError("no held-out prediction rows matched telemetry_windows.csv")
    all_results = []
    cfg = Config(duration_minutes=max(int(r["minute"]) for rows in by_run.values() for r in rows) + 1)
    for run_id, samples in sorted(by_run.items()):
        samples.sort(key=lambda x: int(x["minute"]))
        start_values = [int(r["measured_incident_start_minute"]) for r in samples if r["measured_incident_start_minute"]]
        start = min(start_values) if start_values else 10**9
        demand_trace = tuple(max(0.0, float(r["request_rate_rps"]) * demand_scale) for r in samples)
        risks = tuple(float(pred_map[(run_id, int(r["minute"]))]) * 0.9 for r in samples)
        scenario = Scenario(run_id, "fault", {"fault_start_minute": start, "zone_b_capacity_factor": .35}, demand_trace)
        for policy in ("reactive", "forecast_only", "full_system"):
            rows = simulate_scenario(scenario, policy, cfg, risks, "heldout_detector_binary_warning")
            all_results.extend(rows[:len(samples)])
    output.mkdir(parents=True, exist_ok=True)
    with (output / "results.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(all_results[0]))
        writer.writeheader(); writer.writerows(all_results)
    summary = []
    for policy in ("reactive", "forecast_only", "full_system"):
        subset = [r for r in all_results if r["policy"] == policy]
        summary.append({"policy": policy, "runs": len({r["scenario"] for r in subset}),
                       "minutes": len(subset), "latency_slo_breach_minutes": sum(float(r["modeled_worst_zone_latency_ms"]) > cfg.slo_latency_ms for r in subset),
                       "error_slo_breach_minutes": sum(float(r["error_rate"]) > cfg.slo_error_rate for r in subset),
                       "dropped_requests": round(sum(float(r["dropped_requests"]) for r in subset), 2),
                       "mean_replicas": round(sum(float(r["total_replicas"]) for r in subset) / max(1, len(subset)), 3),
                       "replica_changes": sum(int(r["replica_changes"]) for r in subset),
                       "warning_minutes": sum(float(r["zone_b_incident_risk"]) > 0 for r in subset)})
    with (output / "summary.json").open("w", encoding="utf-8") as f:
        json.dump({"demand_scale_virtual_rps_per_measured_rps": demand_scale,
                   "capacity_fault_assumption": "Zone B capacity factor falls to 0.35 at measured incident onset",
                   "warning_assumption": "held-out binary detector warning maps to risk 0.9",
                   "results_are_simulated_not_measured": True, "policies": summary}, f, indent=2)
    return {"runs": len(by_run), "minutes": len(all_results), "summary": summary}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--windows", type=Path, default=Path("data/processed/telemetry_windows.csv"))
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--demand-scale", type=float, default=24.0)
    args = parser.parse_args()
    print(json.dumps(replay(args.windows, args.predictions, args.output, args.demand_scale), indent=2))


if __name__ == "__main__":
    main()
