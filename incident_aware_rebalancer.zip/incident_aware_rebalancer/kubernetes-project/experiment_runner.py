"""Run isolated local workload profiles and rebuild the minute-level dataset."""

from __future__ import annotations

import argparse
import signal
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen


def _wait_until_healthy(process: subprocess.Popen[bytes], url: str, timeout_seconds: float = 15.0) -> None:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError("The sample service exited before becoming healthy; check that the port is free")
        try:
            with urlopen(url, timeout=1) as response:
                if response.status == 200:
                    return
        except (URLError, TimeoutError, OSError):
            time.sleep(0.25)
    raise TimeoutError(f"Sample service did not become healthy at {url}")


def _stop_service(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    process.send_signal(signal.SIGINT)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()


def main() -> None:
    project = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Collect repeated, isolated local telemetry profiles")
    parser.add_argument("--profile-file", type=Path, default=project / "demo_workloads.json")
    parser.add_argument("--profile-name", action="append", dest="profile_names",
                        help="Profile to run; repeat the option to select multiple (default: all)")
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--output-root", type=Path, default=project / "telemetry/repeated")
    parser.add_argument("--batch-name", default="",
                        help="Optional batch folder name; defaults to the current timestamp")
    args = parser.parse_args()
    if args.repeats < 1 or not 1 <= args.port <= 65535:
        parser.error("repeats must be positive and port must be between 1 and 65535")

    import json
    profile_doc = json.loads(args.profile_file.read_text(encoding="utf-8"))
    all_names = [item["name"] for item in profile_doc.get("profiles", [])]
    names = args.profile_names or all_names
    unknown = sorted(set(names) - set(all_names))
    if unknown:
        parser.error(f"Unknown profile(s): {', '.join(unknown)}")

    service_script = project / "demo_service.py"
    load_script = project / "load_generator.py"
    health_url = f"http://127.0.0.1:{args.port}/health"
    work_url = f"http://127.0.0.1:{args.port}/work"
    batch_name = args.batch_name or datetime.now().strftime("batch-%Y%m%d-%H%M%S")
    batch_root = args.output_root / batch_name
    print(f"Run outputs will be saved under {batch_root}")
    for profile_name in names:
        for repeat in range(1, args.repeats + 1):
            output = batch_root / f"{profile_name}_rep_{repeat:02d}"
            print(f"\n=== {profile_name}, repeat {repeat}/{args.repeats} ===", flush=True)
            service = subprocess.Popen(
                [sys.executable, str(service_script), "--host", "127.0.0.1", "--port", str(args.port)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            try:
                _wait_until_healthy(service, health_url)
                subprocess.run(
                    [sys.executable, str(load_script), "--url", work_url,
                     "--profile", str(args.profile_file), "--profile-name", profile_name,
                     "--output-dir", str(output)],
                    cwd=project,
                    check=True,
                )
            finally:
                _stop_service(service)

    print("\n=== Rebuilding minute-level dataset ===", flush=True)
    subprocess.run(
        [sys.executable, str(project / "prepare_dataset.py"),
         "--input-dir", str(project / "telemetry"),
         "--output", str(project / "data/processed/telemetry_windows.csv")],
        cwd=project,
        check=True,
    )


if __name__ == "__main__":
    main()
