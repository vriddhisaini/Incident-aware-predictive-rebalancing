"""FastAPI service for current demand forecasts and trained incident risk."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import joblib
import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from statsmodels.tsa.statespace.sarimax import SARIMAX
from prometheus_client import Counter, make_asgi_app

app = FastAPI(title="Incident-Aware Model Service", version="1.0")
PREDICTIONS = Counter("model_predictions_total", "Model predictions", ["model", "result"])
app.mount("/metrics", make_asgi_app())
ARTIFACT = Path(os.getenv("INCIDENT_MODEL_PATH", "data/processed/incident_models/models/lightgbm.joblib"))
CPU_ARTIFACT = Path(os.getenv("CPU_INCIDENT_MODEL_PATH", "data/processed/public_aiops2020/models/cpu_fault_detector.joblib"))


class ForecastInput(BaseModel):
    zone: str
    history_rps: list[float] = Field(min_length=6, max_length=10000)
    horizon_minutes: int = Field(default=5, ge=1, le=10)


class RiskObservation(BaseModel):
    request_rate_rps: float = 0
    p95_latency_ms: float = 0
    error_rate: float = 0
    process_cpu_percent_1_core_mean: float = 0
    process_max_rss_bytes: float = 0
    request_rate_lag_1: Optional[float] = None
    request_rate_mean_prev_3: Optional[float] = None
    p95_latency_lag_1: Optional[float] = None
    p95_latency_slope_prev_3: Optional[float] = None
    error_rate_lag_1: Optional[float] = None
    error_rate_mean_prev_3: Optional[float] = None


class RiskInput(BaseModel):
    zone: str
    observations: list[RiskObservation] = Field(min_length=1, max_length=100)


class CPUObservation(BaseModel):
    process_cpu_percent_1_core_mean: float = Field(ge=0, le=10000)
    cpu_lag_1: Optional[float] = Field(default=None, ge=0, le=10000)
    cpu_mean_prev_3: Optional[float] = Field(default=None, ge=0, le=10000)
    cpu_delta_from_prev_3: Optional[float] = Field(default=None, ge=-10000, le=10000)


class CPUIncidentInput(BaseModel):
    zone: str
    observations: list[CPUObservation] = Field(min_length=1, max_length=1000)


@app.get("/health")
def health():
    public_cpu_loaded = CPU_ARTIFACT.exists()
    return {"status":"ok", "incident_model_loaded":ARTIFACT.exists(),
            "public_cpu_detector_loaded":public_cpu_loaded,
            "public_cpu_detector": "AIOps Challenge 2020 active CPU-fault classifier" if public_cpu_loaded else None}


@app.post("/forecast")
def forecast(request: ForecastInput):
    try:
        history = np.asarray(request.history_rps, dtype=float)
        if not np.isfinite(history).all() or np.any(history < 0):
            raise ValueError("history must contain finite non-negative RPS")
        model = SARIMAX(history, order=(1,0,0), trend="c", enforce_stationarity=False, enforce_invertibility=False).fit(disp=False, maxiter=100)
        result = model.get_forecast(request.horizon_minutes)
        mean = np.maximum(0, np.asarray(result.predicted_mean, dtype=float))
        interval = np.maximum(0, np.asarray(result.conf_int(), dtype=float))
        PREDICTIONS.labels("sarima_1_0_0", "ok").inc()
        return {"zone":request.zone,"horizon_minutes":request.horizon_minutes,"predicted_rps":mean.tolist(),
                "lower_95_rps":interval[:,0].tolist(),"upper_95_rps":interval[:,1].tolist(),"model":"sarima_1_0_0"}
    except Exception as exc:
        PREDICTIONS.labels("sarima_1_0_0", "error").inc()
        raise HTTPException(status_code=422, detail=str(exc))


@app.post("/incident-risk")
def incident_risk(request: RiskInput):
    if not ARTIFACT.exists():
        raise HTTPException(status_code=503, detail="trained risk artifact not present; run train_incident_models.py")
    try:
        artifact = joblib.load(ARTIFACT)
        model = artifact["model"]
        features = artifact["features"]
        matrix = np.asarray([[getattr(row, name) if getattr(row, name) is not None else np.nan for name in features]
                             for row in request.observations], dtype=float)
        probs = model.predict_proba(matrix)[:,1]
        threshold = float(artifact["threshold"])
        PREDICTIONS.labels("lightgbm", "ok").inc(len(probs))
        return {"zone":request.zone,"model":"lightgbm","threshold":threshold,
                "risk_scores":probs.tolist(),"incident_warnings":(probs >= threshold).astype(int).tolist()}
    except Exception as exc:
        PREDICTIONS.labels("lightgbm", "error").inc()
        raise HTTPException(status_code=422, detail=str(exc))


@app.post("/incident-risk-cpu")
def incident_risk_cpu(request: CPUIncidentInput):
    """Score CPU-only transfer observations for the AIOpsLab CPU-fault case."""
    if not CPU_ARTIFACT.exists():
        raise HTTPException(status_code=503, detail="CPU-only model artifact missing; run train_cpu_incident_model.py")
    try:
        artifact=joblib.load(CPU_ARTIFACT)
        features=artifact.get("features", ["process_cpu_percent_1_core_mean"])
        matrix=np.asarray([[getattr(row,name) if getattr(row,name) is not None else np.nan for name in features]
                           for row in request.observations],dtype=float)
        probs=artifact["model"].predict_proba(matrix)[:,1]
        threshold=float(artifact["threshold"])
        PREDICTIONS.labels("public_aiops2020_cpu_lightgbm","ok").inc(len(probs))
        return {"zone":request.zone,"model":artifact.get("model_name", "public_aiops2020_cpu_fault_lightgbm"),"threshold":threshold,
                "risk_scores":probs.tolist(),"incident_warnings":(probs>=threshold).astype(int).tolist()}
    except Exception as exc:
        PREDICTIONS.labels("public_aiops2020_cpu_lightgbm","error").inc()
        raise HTTPException(status_code=422,detail=str(exc))
