# Unified project flow

The single entry point is `scripts/run_unified_demo.sh`. It builds the public-data detector, refreshes the offline CloudSim comparison, deploys the three-zone kind stack, runs a workload through the live router, and evaluates the same detector API through AIOpsLab when its checkout is present.

```sh
source scripts/activate_local_toolchain.sh
./scripts/run_unified_demo.sh
```

The default workload is `cpu_pressure_then_fault` (seven minutes). Choose another checked-in profile with `DEMO_PROFILE=load_ramp_recovery ./scripts/run_unified_demo.sh`. Results for a run are grouped under `data/processed/unified_demo/<timestamp>/run_summary.json`.

## One live control path

```text
three-zone Kubernetes app + traffic router
             │ Prometheus metrics
             ▼
zone sensor: CPU level + causal CPU history
             ▼
FastAPI /incident-risk-cpu ── public-data LightGBM
             │ incident alert / telemetry on NATS
             ▼
zone agents + Contract-Net ── local Ollama diagnosis/proposal
             ▼
guard_plan + Kubernetes operator
             ▼
pending RebalancePlan → human approval → bounded scale/routing action
```

The per-zone sensor and AIOpsLab's CPU adapter now call the same `/incident-risk-cpu` endpoint and the same public-data artifact. Other app measurements remain available to the LLM and deterministic safety checks, but are not passed off as trained detector features. The operator still requires an explicit approval before any change is applied.

## Low-memory execution order

This local Docker Desktop engine is configured with 8 GiB for kind. The unified command therefore runs the phases in sequence: public-data training and the offline CloudSim replay, the three-zone Kubernetes workload, and then the AIOpsLab cases. During AIOpsLab, it keeps `ml-service` available for the shared detector API, scales down the idle project agents/router/Ollama stack, reuses the already-ready Astronomy Shop release, and enables its built-in load generator only for the benchmark. It turns the generator off and restores the project deployments before writing the final summary. The run directory records this resource profile.

If the command is interrupted during the AIOpsLab phase, its exit cleanup turns off the benchmark generator and attempts to restore the project stack.

The Nov 20, 2026 unified run is recorded in `data/processed/unified_demo/20261120_205258/run_summary.json`. The 420-second live profile completed 3,600 requests with 60 errors (1.67%) and 360.45 ms client p95, exceeding the provisional 1% error and 300 ms p95 limits. LightGBM missed AIOpsLab's injected high-CPU case and returned No for the no-fault control. The exported target CPU counters were flat at zero in both cases, so the transfer result does not validate the detector. The adapter bootstraps Astronomy Shop when absent, waits for pod rollouts, retries exports that lack enough counter samples, restores the model API port-forward if needed, and keeps the shared app and Prometheus deployment up until both cases finish. Failure cleanup removes benchmark namespaces and restores the project deployments.

## Public detector: target and evidence

The training source is the [AIOps Challenge 2020 public dataset](https://github.com/NetManAIOps/AIOps-Challenge-2020-Data). Its fault ledger annotates fault type, target resource, start time, and five-minute duration. The builder reads the public container CPU metric, documented as a percentage, and maps it to the project's one-core CPU signal. It adds only causal lag/mean/delta features from prior CPU windows. The target is an **already active annotated CPU fault on that resource**. This data does not establish an early-warning target.

The current build contains 25,486 one-minute rows across 10 date groups, with 75 positive windows from 19 annotated CPU fault events. Training uses whole dates for fit/validation/test; the held-out dates are not shuffled row-by-row. The current test set has 21 positive and 7,433 negative windows: precision 4.69%, recall 14.29%, false-positive rate 0.82%, and PR-AUC 0.0106. At the frozen threshold it flagged 64 windows, of which 3 were positive, and missed 18 positive windows. This is weak benchmark performance. Treat the model as advisory only; it does not justify automatic control.

The repository says the dataset is for non-commercial research or classroom teaching unless otherwise agreed. Do not use it for a commercial product without separate permission. The 163-row hand-scripted project dataset and its old model artifacts remain available for reproducing earlier experiments, but the unified detector is not trained on them.

## AIOpsLab and CloudSim roles

- **AIOpsLab** supplies its Astronomy Shop workload, fault lifecycle, telemetry export, and evaluator. The adapter maps its container CPU counters into the same CPU feature contract and sends them to the same public model endpoint. Its service remains an external benchmark workload; its app and evaluator are not the three-zone app.
- **CloudSim Plus** replays Google ClusterData scheduler events offline and compares placement policies. The trace has no application incident labels and is not detector training data. It cannot act as the live Kubernetes control plane. The unified command refreshes this batch comparison alongside the live run so its separate result is visible in one run summary.
- **Kubernetes** hosts the live three-zone app, model API, NATS agents, Ollama diagnosis agent, safety bridge/operator, Prometheus, and Grafana.

## Artifacts

- `data/processed/public_aiops2020/cpu_fault_windows.csv`: public training rows with feature/label provenance.
- `data/processed/public_aiops2020/models/report.json`: date-held-out model evaluation.
- `data/processed/public_aiops2020/models/heldout_predictions.csv`: held-out scores and labels.
- `data/processed/unified_demo/<timestamp>/`: build, Kubernetes, live workload, CloudSim, and AIOpsLab run records.

The raw archive and extracted source are excluded from version control by `.gitignore`. The model report and feature/label metadata preserve the dataset terms and mapping.
