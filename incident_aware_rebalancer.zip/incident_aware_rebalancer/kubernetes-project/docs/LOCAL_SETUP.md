# Local architecture setup

This guide runs the research prototype on a local machine. The checked-out Desktop project now includes a project-local Python 3.11 environment, kind, kubectl, Helm 3, and Maven. Activate them from the repository root with `source scripts/activate_local_toolchain.sh`. These local tool binaries and packages are ignored by Git. Docker Desktop still needs to be installed and started before kind can create a cluster. The verified installer is `Docker Desktop.dmg` in the repository root (SHA-256: `94e4ccec4a035b7dcdf67cfff0520d4b46ee873ae04b155abc0d22b333cc90ad`). Open it in Finder and follow Docker's drag-to-Applications flow; this Codex environment cannot mount disk images itself.

## 1. Python environment and model artifacts

From the repository root:

```sh
source scripts/activate_local_toolchain.sh
python --version  # 3.11.x
python run.py --output-dir data/processed/safety-evaluation
python prepare_dataset.py
python forecast_models.py --output-dir data/processed/forecast_models
python train_incident_models.py --output-dir data/processed/incident_models
python train_cpu_incident_model.py
```

Review `data/processed/forecast_models/report.json` and `data/processed/incident_models/report.json`. Do not treat their current small scripted sample as a deployment-quality benchmark. The full-system simulation uses a synthetic risk signal and is an architectural comparison only.

## 2. Build the local image and kind cluster

Docker Desktop 4.97.0 is installed at `/Applications/Docker.app` and the engine is running. The verified installer is retained in the project as `Docker Desktop.dmg`. In a fresh terminal, source the project activation script so Docker, kind, kubectl, Helm, and the project kubeconfig are on `PATH`:

```sh
source scripts/activate_local_toolchain.sh
docker info
```

The local `rebalancer-local` kind cluster has four Ready nodes. To recreate the core project deployment, run:

```sh
docker build -t incident-aware-rebalancer:local .
kind create cluster --name rebalancer-local --config k8s/kind-config.yaml
kind load docker-image incident-aware-rebalancer:local --name rebalancer-local
kubectl apply -f k8s/demo.yaml
kubectl apply -f k8s/rebalance-crd.yaml
kubectl apply -f k8s/platform.yaml
kubectl apply -f k8s/agents.yaml
kubectl apply -f k8s/operator.yaml
kubectl apply -f k8s/monitoring.yaml
kubectl -n rebalancer-demo get pods -o wide
```

Wait for the demo, NATS, ML service, Ollama, diagnosis agent, zone agents, sensor agents, operator, Prometheus, and Grafana pods to become Ready. `platform.yaml` starts a temporary Ollama server in its init container, downloads `qwen3:0.6b` into its model PVC, then starts the serving container. The model cache must fit in the PVC (the configured request is 2 GiB). Verify actual generation through `/api/chat` before the demo; listing a model is not an inference check. On this machine, generation has succeeded both in the Ollama desktop app and through the Kubernetes Ollama service.

## 3. Verify endpoints and metrics

```sh
kubectl -n rebalancer-demo port-forward svc/ml-service 8000:8000
```

In another terminal, check `http://127.0.0.1:8000/health` and `http://127.0.0.1:8000/metrics`. Check sensor metrics by forwarding one sensor service on port 9102. Use the Grafana service port-forward to inspect the provisioned dashboard. A successful port-forward proves connectivity only; inspect pod logs and Prometheus targets too.

## 4. Exercise proposal and approval flow

The detector/LLM can submit proposals, but the bridge writes `approved: false`. Review the generated `RebalancePlan`, its evidence and status, then approve only a reviewed plan:

```sh
kubectl -n rebalancer-demo get rebalanceplans
kubectl -n rebalancer-demo describe rebalanceplan <name>
kubectl -n rebalancer-demo patch rebalanceplan <name> --type merge -p '{"spec":{"approved":true}}'
```

The operator re-reads live replicas and traffic weights and applies the deterministic safety gate before it scales or changes routing. Do not connect the weak prototype detector to unattended actuation.

## 5. Controlled faults

Install a compatible Chaos Mesh release and its CRDs in the kind cluster before applying one fault at a time:

```sh
kubectl apply -f k8s/chaos/pod-kill-zone-b.yaml
kubectl apply -f k8s/chaos/network-delay-router-to-zone-b.yaml
kubectl apply -f k8s/chaos/cpu-stress-zone-b.yaml
```

Measure recovery, warnings, false alarms, error/latency SLOs, resource use, and action churn. Reset the experiment between faults. These manifests have syntax validation only and have not been applied to a cluster in this environment.

## 6. Stop and clean up

```sh
kind delete cluster --name rebalancer-local
```

Keep output artifacts and logs with the project run metadata. For a research submission, add a frozen configuration, trace/data attribution, repeat seeds, and complete held-out results before making performance claims.


## Kubernetes acceptance automation

Once Docker/kind works, train both incident artifacts first, then run `scripts/k8s_acceptance.sh` from the project. It builds the image, creates or reuses `rebalancer-local`, applies manifests in dependency order, and waits for deployments. It does not install Chaos Mesh or perform mutating rebalance approvals; follow the functional acceptance steps printed by the script and the controlled-fault instructions above.

The CloudSim Plus 8.5.7 adapter can be compiled with Maven. Its local Maven repository is kept under `.toolchain/`:

```sh
cd cloudsim
../.toolchain/bin/mvn -q compile
```

Ollama 0.40.11 and `qwen3:0.6b` are installed on this Mac. The desktop app serves `http://127.0.0.1:11434`; verify inference with `curl http://127.0.0.1:11434/api/chat` using a short prompt. A Kubernetes copy is available at `http://ollama.rebalancer-demo.svc.cluster.local:11434`; its PVC is seeded on the current cluster, and the manifest now starts a server before running `ollama pull` so fresh installs do not fail with connection refused.
