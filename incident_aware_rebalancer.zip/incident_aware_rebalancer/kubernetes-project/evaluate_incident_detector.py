"""Evaluate an interpretable one-feature warning rule on held-out runs.

The final run (by run_id) for each profile is held out. All windows from a
run stay together. A one-split result is exploratory, especially for profiles
with only a few repetitions.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path


FEATURES = (
    "p95_latency_ms",
    "p95_latency_lag_1",
    "p95_latency_slope_prev_3",
    "error_rate",
    "error_rate_lag_1",
    "error_rate_mean_prev_3",
    "process_cpu_percent_1_core_mean",
)


def _number(value: str | None) -> float | None:
    if value in (None, ""):
        return None
    try:
        result = float(value)
    except ValueError:
        return None
    return result if math.isfinite(result) else None


def _metrics(actual: list[int], predicted: list[int]) -> dict[str, int | float]:
    tp = sum(y == 1 and p == 1 for y, p in zip(actual, predicted))
    fp = sum(y == 0 and p == 1 for y, p in zip(actual, predicted))
    fn = sum(y == 1 and p == 0 for y, p in zip(actual, predicted))
    tn = sum(y == 0 and p == 0 for y, p in zip(actual, predicted))
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    accuracy = (tp + tn) / len(actual) if actual else 0.0
    return {"n_windows": len(actual), "positive_windows": sum(actual), "tp": tp,
            "fp": fp, "fn": fn, "tn": tn, "precision": round(precision, 4),
            "recall": round(recall, 4), "f1": round(f1, 4), "accuracy": round(accuracy, 4)}


def _f0_5(metrics: dict[str, int | float]) -> float:
    precision, recall = float(metrics["precision"]), float(metrics["recall"])
    return 1.25 * precision * recall / (0.25 * precision + recall) if precision + recall else 0.0


def _fit_stump(
    fit_rows: list[dict[str, str]],
    validation_rows: list[dict[str, str]],
    features: tuple[str, ...] = FEATURES,
) -> dict[str, object]:
    """Build threshold candidates from fit runs and select by validation F0.5."""
    best: tuple[float, float, float, str, str, float] | None = None
    for feature in features:
        observed = sorted({value for row in fit_rows if (value := _number(row.get(feature))) is not None})
        if not observed:
            continue
        thresholds = [observed[0] - 1.0, *[(a + b) / 2 for a, b in zip(observed, observed[1:])], observed[-1] + 1.0]
        # All candidate features are adverse-risk signals: larger latency,
        # error, or CPU values (and steeper positive latency slopes) mean more risk.
        for direction in ("above",):
            for threshold in thresholds:
                rule = {"feature": feature, "direction": direction, "threshold": threshold}
                actual = [int(row["incident_within_2m"]) for row in validation_rows]
                predicted = [_predict(row, rule) for row in validation_rows]
                score = _metrics(actual, predicted)
                candidate = (_f0_5(score), float(score["f1"]), float(score["recall"]), feature, direction, threshold)
                if best is None or candidate[:3] > best[:3]:
                    best = candidate
    if best is None:
        return {"feature": None, "direction": "above", "threshold": 0.0,
                "validation_f0_5": 0.0, "validation_f1": 0.0}
    f0_5, f1, _, feature, direction, threshold = best
    return {"feature": feature, "direction": direction, "threshold": threshold,
            "validation_f0_5": round(f0_5, 4), "validation_f1": f1}


def _predict(row: dict[str, str], model: dict[str, object]) -> int:
    if "rules" in model:
        return int(any(_predict(row, rule) for rule in model["rules"]))  # type: ignore[arg-type]
    feature = model["feature"]
    value = _number(row.get(str(feature))) if feature else None
    if value is None:
        return 0
    threshold = float(model["threshold"])
    return int(value >= threshold if model["direction"] == "above" else value <= threshold)


def evaluate(input_path: Path, holdout_profile: str | None = None) -> tuple[dict[str, object], list[dict[str, object]]]:
    with input_path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    if not rows or "run_id" not in rows[0] or "profile_name" not in rows[0]:
        raise ValueError("Dataset must contain run_id and profile_name columns; rebuild it with prepare_dataset.py")

    profile_runs: dict[str, set[str]] = defaultdict(set)
    for row in rows:
        profile_runs[row["profile_name"]].add(row["run_id"])
    if holdout_profile is not None:
        if holdout_profile not in profile_runs:
            raise ValueError(f"Unknown profile {holdout_profile!r}; available profiles: {', '.join(sorted(profile_runs))}")
        test_runs = profile_runs[holdout_profile]
        train_rows = [row for row in rows if row["profile_name"] != holdout_profile]
        test_rows = [row for row in rows if row["profile_name"] == holdout_profile]
        protocol = "Leave-one-profile-out: all runs for the selected profile are test-only; remaining profiles are split by run into fit and validation groups."
    else:
        test_runs = {sorted(run_ids)[-1] for run_ids in profile_runs.values() if len(run_ids) >= 2}
        train_rows = [row for row in rows if row["run_id"] not in test_runs]
        test_rows = [row for row in rows if row["run_id"] in test_runs]
        protocol = "For each profile with at least two runs, hold out the lexicographically last run_id for test; remaining profiles are split by run into fit and validation groups."
    if not train_rows or not test_rows:
        raise ValueError("Need at least one profile with two distinct runs for a run-level holdout")
    validation_runs: set[str] = set()
    development_profile_runs: dict[str, set[str]] = defaultdict(set)
    for row in train_rows:
        development_profile_runs[row["profile_name"]].add(row["run_id"])
    for run_ids in development_profile_runs.values():
        if len(run_ids) >= 2:
            validation_runs.add(sorted(run_ids)[-1])
    fit_rows = [row for row in train_rows if row["run_id"] not in validation_runs]
    validation_rows = [row for row in train_rows if row["run_id"] in validation_runs]
    if not validation_rows:
        raise ValueError("Need at least two runs in a development profile to make a run-grouped validation set")

    latency_features = ("p95_latency_ms", "p95_latency_lag_1", "p95_latency_slope_prev_3")
    error_features = ("error_rate", "error_rate_lag_1", "error_rate_mean_prev_3")
    cpu_features = ("process_cpu_percent_1_core_mean",)
    single_model = _fit_stump(fit_rows, validation_rows)
    channel_rules = [
        _fit_stump(fit_rows, validation_rows, latency_features),
        _fit_stump(fit_rows, validation_rows, error_features),
        _fit_stump(fit_rows, validation_rows, cpu_features),
    ]
    channel_rules = [rule for rule in channel_rules if rule["feature"] is not None]
    combined_model: dict[str, object] = {"kind": "or", "rules": channel_rules}
    val_actual = [int(row["incident_within_2m"]) for row in validation_rows]
    single_val = _metrics(val_actual, [_predict(row, single_model) for row in validation_rows])
    combined_val = _metrics(val_actual, [_predict(row, combined_model) for row in validation_rows])
    model = combined_model if _f0_5(combined_val) > _f0_5(single_val) else {"kind": "single", **single_model}
    actual = [int(row["incident_within_2m"]) for row in test_rows]
    predicted = [_predict(row, model) for row in test_rows]
    baseline = [0] * len(test_rows)
    single_test = [_predict(row, single_model) for row in test_rows]
    combined_test = [_predict(row, combined_model) for row in test_rows]
    metrics_by_profile: dict[str, object] = {}
    for profile in sorted({row["profile_name"] for row in test_rows}):
        indices = [i for i, row in enumerate(test_rows) if row["profile_name"] == profile]
        profile_actual = [actual[i] for i in indices]
        metrics_by_profile[profile] = {
            "test_runs": sorted({test_rows[i]["run_id"] for i in indices}),
            "always_no_warning": _metrics(profile_actual, [0] * len(indices)),
            "trained_one_feature_threshold": _metrics(profile_actual, [predicted[i] for i in indices]),
        }
    payload: dict[str, object] = {
        "protocol": protocol,
        "held_out_profile": holdout_profile,
        "train_run_count": len({row["run_id"] for row in train_rows}),
        "fit_run_count": len({row["run_id"] for row in fit_rows}),
        "validation_run_count": len(validation_runs),
        "test_run_count": len(test_runs),
        "train_window_count": len(train_rows),
        "fit_window_count": len(fit_rows),
        "validation_window_count": len(validation_rows),
        "test_window_count": len(test_rows),
        "train_positive_count": sum(int(row["incident_within_2m"]) for row in train_rows),
        "validation_positive_count": sum(val_actual),
        "test_positive_count": sum(actual),
        "fit_runs": sorted({row["run_id"] for row in fit_rows}),
        "validation_runs": sorted(validation_runs),
        "held_out_runs": sorted(test_runs),
        "profiles_with_single_run_kept_in_training_only": sorted(profile for profile, runs in profile_runs.items() if len(runs) < 2),
        "detector": model,
        "validation_selection": {
            "objective": "F0.5 (precision weighted more than recall)",
            "single_signal": single_model,
            "single_signal_metrics": single_val,
            "multi_signal_or": combined_model,
            "multi_signal_or_metrics": combined_val,
        },
        "test_metrics": {
            "always_no_warning": _metrics(actual, baseline),
            "selected_detector": _metrics(actual, predicted),
            "single_signal": _metrics(actual, single_test),
            "multi_signal_or": _metrics(actual, combined_test),
        },
        "test_metrics_by_profile": metrics_by_profile,
        "caveat": "Single deterministic holdout on small scripted profiles; results measure repeatability on the same profile shapes, not generalization to new incident types or production traffic.",
    }
    predictions = []
    for row, y, p in zip(test_rows, actual, predicted):
        predictions.append({"run_id": row["run_id"], "profile_name": row["profile_name"],
                            "minute": row["minute"], "actual": y, "predicted_warning": p,
                            "selected_detector": model["kind"],
                            "selected_signals": ";".join(str(rule["feature"]) for rule in model.get("rules", [model]) if rule.get("feature")),
                            "prediction": p})
    return payload, predictions


def main() -> None:
    project = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Run a deterministic grouped holdout for an incident-warning baseline")
    parser.add_argument("--input", type=Path, default=project / "data/processed/telemetry_windows.csv")
    parser.add_argument("--holdout-profile", help="Hold out every run from this profile (leave-one-profile-out evaluation)")
    parser.add_argument("--output-dir", type=Path, help="Output directory (defaults to an evaluation-specific folder)")
    args = parser.parse_args()
    try:
        report, predictions = evaluate(args.input, args.holdout_profile)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    output_dir = args.output_dir or (
        project / "data/processed" / f"incident_evaluation_profile_{args.holdout_profile}"
        if args.holdout_profile else project / "data/processed/incident_evaluation"
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    with (output_dir / "heldout_predictions.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(predictions[0].keys()))
        writer.writeheader()
        writer.writerows(predictions)
    print(f"Grouped holdout: {report['train_run_count']} train runs, {report['test_run_count']} test runs; "
          f"{report['train_positive_count']} train positives, {report['test_positive_count']} test positives.")
    print(f"Selected detector: {report['detector']}")
    print(f"Test metrics: {report['test_metrics']}")
    print(f"Report: {output_dir / 'report.json'}")
    print("Interpret as an exploratory repeated-profile check, not an estimate of production accuracy.")


if __name__ == "__main__":
    main()
