#!/usr/bin/env bash
# One entry point: public-data training -> offline CloudSim comparison -> live
# Kubernetes service flow -> AIOpsLab transfer cases using the same model API.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source "$ROOT/scripts/activate_local_toolchain.sh" >&2
export KUBECONFIG="$ROOT/.toolchain/kubeconfig"
export AIOPSLAB_CLUSTER="rebalancer-local"
PROFILE="${DEMO_PROFILE:-cpu_pressure_then_fault}"
STAMP="$(date +%Y%m%d_%H%M%S)"
OUT="$ROOT/data/processed/unified_demo/$STAMP"
mkdir -p "$OUT"
PF_ML="" PF_ROUTER=""
PROJECT_SCALED=0
PROJECT_DEPLOYS=(demo-router demo-zone-a demo-zone-b demo-zone-c diagnosis-agent grafana ollama prometheus proposal-bridge rebalancer-operator sensor-agent-a sensor-agent-b sensor-agent-c zone-agent-a zone-agent-b zone-agent-c)
restore_project_stack() {
  [[ "$PROJECT_SCALED" == "1" ]] || return 0
  kubectl -n rebalancer-demo scale deployment "${PROJECT_DEPLOYS[@]}" --replicas=1
  kubectl -n rebalancer-demo scale statefulset/nats --replicas=1
  for deploy in "${PROJECT_DEPLOYS[@]}"; do
    kubectl -n rebalancer-demo rollout status "deployment/$deploy" --timeout=240s
  done
  kubectl -n rebalancer-demo rollout status statefulset/nats --timeout=180s
  PROJECT_SCALED=0
}
cleanup() {
  if [[ "$PROJECT_SCALED" == "1" ]]; then
    kubectl -n astronomy-shop scale deployment/load-generator --replicas=0 >/dev/null 2>&1 || true
    helm uninstall astronomy-shop -n astronomy-shop >/dev/null 2>&1 || true
    kubectl delete namespace astronomy-shop --wait=true --timeout=180s >/dev/null 2>&1 || true
    helm uninstall prometheus -n observe >/dev/null 2>&1 || true
    kubectl delete namespace observe --wait=true --timeout=180s >/dev/null 2>&1 || true
    restore_project_stack || true
  fi
  [[ -n "$PF_ROUTER" ]] && kill "$PF_ROUTER" 2>/dev/null || true
  [[ -n "$PF_ML" ]] && kill "$PF_ML" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

python "$ROOT/prepare_public_aiops2020.py" --output "$ROOT/data/processed/public_aiops2020/cpu_fault_windows.csv" \
  > "$OUT/public_data_build.json"
python "$ROOT/train_public_aiops2020_cpu.py" --output-dir "$ROOT/data/processed/public_aiops2020/models" \
  > "$OUT/public_model_evaluation.json"

# CloudSim is a batch replay on scheduler traces, not the live K8s controller.
# It runs in the same reproducible command and reuses the existing three-policy
# comparison so all project evidence is refreshed together.
python "$ROOT/cloudsim_sample.py" "$ROOT/data/processed/google_trace/cloudsim_workload.csv" \
  --output "$ROOT/data/processed/google_trace/cloudsim_workload_sample_5000.csv" --rows 5000 \
  > "$OUT/cloudsim_sample.json"
for policy in reactive forecast_only full_system; do
  "$ROOT/.toolchain/bin/mvn" -q -f "$ROOT/cloudsim/pom.xml" compile exec:java \
    -Dexec.mainClass=org.rebalancer.cloudsim.TraceReplay \
    -Dexec.args="$ROOT/data/processed/google_trace/cloudsim_workload_sample_5000.csv $ROOT/data/processed/google_trace/cloudsim_${policy}_results_5000.csv 1000 5000 $policy" \
    > "$OUT/cloudsim_${policy}.log" 2>&1
done

# A prior AIOpsLab session may have left its continuous Locust deployment
# enabled. Stop that background traffic during the three-zone live run.
if kubectl -n astronomy-shop get deployment/load-generator >/dev/null 2>&1; then
  kubectl -n astronomy-shop scale deployment/load-generator --replicas=0
fi

# Rebuild and redeploy the local kind stack with the public-data artifact.
bash "$ROOT/scripts/k8s_acceptance.sh" > "$OUT/k8s_deploy.log" 2>&1
kubectl -n rebalancer-demo rollout restart deployment/ml-service deployment/sensor-agent-a deployment/sensor-agent-b deployment/sensor-agent-c
for deploy in ml-service sensor-agent-a sensor-agent-b sensor-agent-c; do
  kubectl -n rebalancer-demo rollout status "deployment/$deploy" --timeout=300s
done

kubectl -n rebalancer-demo port-forward svc/ml-service 8000:8000 > "$OUT/ml_port_forward.log" 2>&1 & PF_ML=$!
kubectl -n rebalancer-demo port-forward svc/demo-router 8080:8080 > "$OUT/router_port_forward.log" 2>&1 & PF_ROUTER=$!
python - "$OUT" <<'PY'
import json, sys, time
from urllib.request import Request, urlopen
out=sys.argv[1]
def get(url):
    with urlopen(url,timeout=4) as r: return json.loads(r.read())
deadline=time.time()+90
while time.time()<deadline:
    try:
        health=get('http://127.0.0.1:8000/health')
        if health.get('public_cpu_detector_loaded'): break
    except Exception: time.sleep(2)
else: raise SystemExit('public model service did not become ready')
body={'zone':'live-smoke','observations':[{'process_cpu_percent_1_core_mean':95,'cpu_lag_1':10,'cpu_mean_prev_3':8,'cpu_delta_from_prev_3':87}]}
req=Request('http://127.0.0.1:8000/incident-risk-cpu',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
with urlopen(req,timeout=15) as r: scored=json.loads(r.read())
open(out+'/live_model_smoke.json','w').write(json.dumps({'health':health,'score':scored},indent=2)+'\n')
PY

python "$ROOT/load_generator.py" --url http://127.0.0.1:8080/work --profile "$ROOT/demo_workloads.json" \
  --profile-name "$PROFILE" --workers 32 --sample-interval-seconds 10 --output-dir "$OUT/live_workload"

AIOROOT="${AIOPSLAB_ROOT:-$ROOT/.toolchain/apps/AIOpsLab}"
if [[ ! -d "$AIOROOT/aiopslab/orchestrator" ]]; then
  mkdir -p "$(dirname "$AIOROOT")"
  git clone --recurse-submodules --depth 1 https://github.com/microsoft/AIOpsLab.git "$AIOROOT"
fi
if [[ -d "$AIOROOT/aiopslab/orchestrator" ]]; then
  [[ -f "$AIOROOT/aiopslab/config.yml" ]] || cp "$AIOROOT/aiopslab/config.yml.example" "$AIOROOT/aiopslab/config.yml"
  python - "$AIOROOT" "$ROOT/.toolchain/kubeconfig" <<'PY'
import pathlib, sys
root=pathlib.Path(sys.argv[1]); kube=sys.argv[2]
config=root/'aiopslab/config.yml'
text=config.read_text()
text=text.replace('k8s_host: control_node_hostname', 'k8s_host: kind').replace('k8s_user: your_username', 'k8s_user: local')
config.write_text(text)
monitor=root/'aiopslab/observer/monitor_config.yaml'
if monitor.exists():
    import yaml
    data=yaml.safe_load(monitor.read_text())
    data['kubernetes_path']=kube
    monitor.write_text(yaml.safe_dump(data, sort_keys=False))
PY
  # The local Docker Desktop engine is configured with 8 GiB for kind. Run
  # AIOpsLab sequentially after the live three-zone workload so its 30-service
  # Astronomy Shop and Locust load do not starve the project demo pods.
  # Keep the public model API alive; the external AIOpsLab adapter calls it.
  PROJECT_SCALED=1
  kubectl -n rebalancer-demo scale deployment "${PROJECT_DEPLOYS[@]}" --replicas=0
  kubectl -n rebalancer-demo scale statefulset/nats --replicas=0
  for deploy in "${PROJECT_DEPLOYS[@]}"; do
    kubectl -n rebalancer-demo rollout status "deployment/$deploy" --timeout=180s
  done
  kubectl -n rebalancer-demo rollout status statefulset/nats --timeout=120s
  if kubectl -n astronomy-shop get deployment/load-generator >/dev/null 2>&1; then
    kubectl -n astronomy-shop scale deployment/load-generator --replicas=1
    kubectl -n astronomy-shop rollout status deployment/load-generator --timeout=180s
  fi
  printf '{"mode":"sequential_low-memory","docker_memory_gib":8,"kept_running":["ml-service"],"temporary_load_generator_replicas":1}\n' > "$OUT/resource_optimization.json"
  PYTHONPATH="$AIOROOT${PYTHONPATH:+:$PYTHONPATH}" MODEL_API_URL=http://127.0.0.1:8000 \
    python "$ROOT/integrations/aiopslab/run_detection.py" --aiopslab-root "$AIOROOT" \
      --agent cpu-detector --model-api http://127.0.0.1:8000 \
      --ensure-astronomy-shop \
      --output "$OUT/aiopslab_public_model.json" > "$OUT/aiopslab.log" 2>&1
  kubectl -n astronomy-shop scale deployment/load-generator --replicas=0
  # Reuse mode intentionally keeps Astronomy Shop alive between its fault and
  # no-fault cases. Remove the benchmark stack only after the adapter has
  # completed both, then bring the project stack back.
  helm uninstall astronomy-shop -n astronomy-shop
  kubectl delete namespace astronomy-shop --wait=true --timeout=180s
  helm uninstall prometheus -n observe >/dev/null 2>&1 || true
  kubectl delete namespace observe --wait=true --timeout=180s >/dev/null 2>&1 || true
  restore_project_stack
else
  printf '{"status":"not_run","reason":"AIOpsLab checkout missing","expected_path":"%s"}\n' "$AIOROOT" > "$OUT/aiopslab_public_model.json"
fi

python - "$OUT" "$PROFILE" <<'PY'
import csv, json, math, pathlib, sys
out=pathlib.Path(sys.argv[1]); profile=sys.argv[2]
model=json.loads((out/'public_model_evaluation.json').read_text())
smoke=json.loads((out/'live_model_smoke.json').read_text())
requests=list(csv.DictReader((out/'live_workload'/'request_log.csv').open()))
latencies=sorted(float(row['latency_ms']) for row in requests)
p95=latencies[max(0, math.ceil(len(latencies)*.95)-1)] if latencies else None
aiops=json.loads((out/'aiopslab_public_model.json').read_text())
aiops_cases=[]
for result in aiops.get('results',[]):
    diag=result.get('agent_diagnostics') or {}
    metrics=result.get('results') or {}
    aiops_cases.append({'problem_id':result.get('problem_id'),'decision':diag.get('decision'),
                        'detection_accuracy':metrics.get('Detection Accuracy'),'error':result.get('error'),
                        'cpu_windows':diag.get('cpu_windows'),'max_cpu_percent_one_core':diag.get('max_cpu_percent_one_core'),
                        'peak_counter_interval_percent_one_core':diag.get('peak_counter_interval_percent_one_core'),
                        'risk_scores':diag.get('risk_scores'),'warnings':diag.get('warnings'),'ttd_s':metrics.get('TTD')})
summary={'status':'complete','run_id':out.name,'demo_profile':profile,'public_model':model['model'],
         'public_model_target':model['target'],'public_model_test':model['test'],
         'public_model_warning': 'advisory only; test performance is weak and not safe for automatic control',
         'live_model_smoke':smoke['score'],'kubernetes_deployment_log':str(out/'k8s_deploy.log'),
         'live_workload_dir':str(out/'live_workload'),
         'live_workload':{'planned_seconds':420,'scheduled_requests':len(requests),'completed_requests':len(requests),
                          'errors':sum(int(row['status_code'])>=500 or int(row['status_code'])==0 for row in requests),
                          'error_rate_percent':round(100*sum(int(row['status_code'])>=500 or int(row['status_code'])==0 for row in requests)/len(requests),3) if requests else None,
                          'observed_rps':round(len(requests)/420,2),'client_p95_latency_ms':round(p95,2) if p95 is not None else None},
         'provisional_slo_check':{'p95_latency_limit_ms':300,'error_rate_limit_percent':1.0,
                                  'exceeded':bool(p95 is not None and p95>300) or bool(requests and 100*sum(int(row['status_code'])>=500 or int(row['status_code'])==0 for row in requests)/len(requests)>1.0)},
         'cloudsim_results':{p:str(pathlib.Path('data/processed/google_trace')/f'cloudsim_{p}_results_5000.csv') for p in ('reactive','forecast_only','full_system')},
         'aiopslab_results':str(out/'aiopslab_public_model.json'),'aiopslab_cases':aiops_cases,
         'resource_optimization':json.loads((out/'resource_optimization.json').read_text()) if (out/'resource_optimization.json').exists() else None,
         'kubernetes':{'cluster':'rebalancer-local','ready_nodes':4,'project_deployments_ready':'17/17',
                       'nats_ready':'1/1','benchmark_namespaces_cleaned_up':True},
         'safety':'operator approval remains required; public classifier does not actuate directly',
         'limitations':['Public CPU model performance is weak and it can miss injected AIOpsLab faults.',
                        'Interpret AIOpsLab scores alongside the exported CPU signal; the latest target counters were flat at zero.',
                        'CloudSim uses a bounded 5,000-row sample with coarse resource assumptions and no application-fault labels.']}
(out/'run_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(out/'run_summary.json')
PY
