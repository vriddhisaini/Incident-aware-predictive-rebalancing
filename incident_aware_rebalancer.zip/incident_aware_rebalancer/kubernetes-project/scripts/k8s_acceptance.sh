#!/usr/bin/env bash
set -euo pipefail
CLUSTER_NAME="rebalancer-local"
NAMESPACE="rebalancer-demo"
IMAGE="incident-aware-rebalancer:local"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="$ROOT/.toolchain/venv/bin:$ROOT/.toolchain/bin:/Applications/Docker.app/Contents/Resources/bin:$PATH"
export KUBECONFIG="${KUBECONFIG:-$ROOT/.toolchain/kubeconfig}"
export BUILDX_CONFIG="${BUILDX_CONFIG:-$ROOT/.toolchain/buildx}"
export HELM_CACHE_HOME="${HELM_CACHE_HOME:-$ROOT/.toolchain/helm-cache}"
export HELM_CONFIG_HOME="${HELM_CONFIG_HOME:-$ROOT/.toolchain/helm-config}"
export HELM_DATA_HOME="${HELM_DATA_HOME:-$ROOT/.toolchain/helm-data}"
mkdir -p "$HELM_CACHE_HOME" "$HELM_CONFIG_HOME" "$HELM_DATA_HOME" "$BUILDX_CONFIG"
for bin in docker kind kubectl; do command -v "$bin" >/dev/null 2>&1 || { echo "Missing required command: $bin" >&2; exit 2; }; done
docker info >/dev/null
if [[ ! -f "$ROOT/data/processed/incident_models/models/lightgbm.joblib" ]]; then python3 "$ROOT/train_incident_models.py"; fi
if [[ ! -f "$ROOT/data/processed/incident_models/models/cpu_only_lightgbm.joblib" ]]; then python3 "$ROOT/train_cpu_incident_model.py"; fi
if ! kind get clusters | grep -qx "$CLUSTER_NAME"; then kind create cluster --name "$CLUSTER_NAME" --config "$ROOT/k8s/kind-config.yaml"; fi
if [[ "${SKIP_DOCKER_BUILD:-0}" == "1" ]]; then
  docker image inspect "$IMAGE" >/dev/null
  echo "Using the existing local image $IMAGE (Dockerfile rebuild skipped by request)."
else
  docker build -t "$IMAGE" "$ROOT"
fi
kind load docker-image "$IMAGE" --name "$CLUSTER_NAME"
kubectl apply -f "$ROOT/k8s/demo.yaml"
kubectl apply -f "$ROOT/k8s/rebalance-crd.yaml"
kubectl wait --for=condition=Established --timeout=90s crd/rebalanceplans.rebalancer.example.org
kubectl apply -f "$ROOT/k8s/platform.yaml"
kubectl apply -f "$ROOT/k8s/agents.yaml"
kubectl apply -f "$ROOT/k8s/operator.yaml"
kubectl apply -f "$ROOT/k8s/monitoring.yaml"
for deployment in demo-zone-a demo-zone-b demo-zone-c demo-router ml-service ollama diagnosis-agent zone-agent-a zone-agent-b zone-agent-c sensor-agent-a sensor-agent-b sensor-agent-c rebalancer-operator proposal-bridge prometheus grafana; do
  echo "Waiting for deployment/$deployment"
  kubectl -n "$NAMESPACE" rollout status "deployment/$deployment" --timeout=300s
done
kubectl -n "$NAMESPACE" rollout status statefulset/nats --timeout=180s
kubectl -n "$NAMESPACE" get pods -o wide
kubectl -n "$NAMESPACE" get svc
cat <<'EOF'
Core deployment readiness completed. Still perform functional acceptance:
- verify ML /health, /forecast, /incident-risk-cpu (public AIOps 2020 model), Prometheus targets, and Grafana;
- verify a pending RebalancePlan remains inert until explicitly approved;
- approve a bounded plan and verify status, replicas, and traffic weights;
- install compatible Chaos Mesh CRDs and run one controlled fault at a time.
EOF
