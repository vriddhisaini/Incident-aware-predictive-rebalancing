#!/usr/bin/env bash
# Source this from the repository root to use the project-local runtime.
if [[ ! -x .toolchain/venv/bin/python || ! -x .toolchain/bin/kind ]]; then
  echo "Project-local toolchain is incomplete; see docs/LOCAL_SETUP.md" >&2
  return 1 2>/dev/null || exit 1
fi
export PATH="$PWD/.toolchain/venv/bin:$PWD/.toolchain/bin:$PATH"
if [[ -x /Applications/Docker.app/Contents/Resources/bin/docker ]]; then
  export PATH="/Applications/Docker.app/Contents/Resources/bin:$PATH"
fi
export KUBECONFIG="${KUBECONFIG:-$PWD/.toolchain/kubeconfig}"
export BUILDX_CONFIG="${BUILDX_CONFIG:-$PWD/.toolchain/buildx}"
export HELM_CACHE_HOME="${HELM_CACHE_HOME:-$PWD/.toolchain/helm-cache}"
export HELM_CONFIG_HOME="${HELM_CONFIG_HOME:-$PWD/.toolchain/helm-config}"
export HELM_DATA_HOME="${HELM_DATA_HOME:-$PWD/.toolchain/helm-data}"
mkdir -p "$HELM_CACHE_HOME" "$HELM_CONFIG_HOME" "$HELM_DATA_HOME" "$BUILDX_CONFIG"
export OLLAMA_HOST="${OLLAMA_HOST:-http://127.0.0.1:11434}"
echo "Activated project-local toolchain: $(python --version); kind $(kind version)"
