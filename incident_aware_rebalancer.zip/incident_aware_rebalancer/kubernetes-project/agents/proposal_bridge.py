"""Turn zone/LLM/NATS awards into pending (never pre-approved) RebalancePlans."""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import time

from kubernetes import client, config
from kubernetes.client.exceptions import ApiException
from nats.aio.client import Client as NATS

from diagnosis_agent import DiagnosisProposal, validate_proposal_safety
from policies import ZonePlan
from safety import guard_plan

ZONES=("zone-a","zone-b","zone-c")
GROUP="rebalancer.example.org";VERSION="v1alpha1";PLURAL="rebalanceplans";NAMESPACE="rebalancer-demo"


class ProposalBridge:
    def __init__(self, custom, apps, core):
        self.custom=custom;self.apps=apps;self.core=core;self.telemetry={}

    def current(self):
        now=time.time()
        if any(z not in self.telemetry or now-float(self.telemetry[z].get("timestamp",0))>120 for z in ZONES):
            raise ValueError("fresh telemetry from all three zones is required before proposing infrastructure changes")
        replicas=tuple(int(self.apps.read_namespaced_deployment_scale(f"demo-{z}",NAMESPACE).spec.replicas) for z in ZONES)
        weights=json.loads(self.core.read_namespaced_config_map("traffic-weights",NAMESPACE).data["weights.json"])
        shares=tuple(float(weights.get(z,0)) for z in ZONES)
        capacity=tuple(float(self.telemetry[z].get("safe_capacity_rps",0)) if self.telemetry[z].get("healthy") else 0.0 for z in ZONES)
        risk=tuple(float(self.telemetry[z].get("incident_risk",1)) for z in ZONES)
        return ZonePlan(replicas,shares),capacity,risk

    def save_pending(self, desired: ZonePlan, capacity, risk, source: str, rationale: str) -> dict:
        body={"apiVersion":f"{GROUP}/{VERSION}","kind":"RebalancePlan","metadata":{"name":f"proposal-{int(time.time()*1000)}","namespace":NAMESPACE},
              "spec":{"approved":False,"replicas":list(desired.replicas),"traffic_shares":list(desired.traffic_shares),
                      "zone_capacity":list(capacity),"incident_risk":list(risk),"source":source,"rationale":rationale[:1000]}}
        self.custom.create_namespaced_custom_object(GROUP,VERSION,NAMESPACE,PLURAL,body)
        return body

    def receive_action(self, data: dict):
        current,capacity,risk=self.current();replicas=list(current.replicas);shares=list(current.traffic_shares)
        action=data.get("action");zone=data.get("zone")
        if zone not in ZONES:return None
        idx=ZONES.index(zone)
        if action=="SCALE_OUT":replicas[idx]=int(data["target_replicas"])
        elif action=="SCALE_IN":replicas[idx]=int(data["target_replicas"])
        else:return None
        decision=guard_plan(current,ZonePlan(tuple(replicas),tuple(shares)),capacity,1,10,2,.2,.02,risk)
        if decision.status=="rejected":return None
        return self.save_pending(decision.plan,capacity,risk,"zone_agent",data.get("reason","zone agent request"))

    def receive_diagnosis(self, data: dict):
        raw=data.get("proposal",{});current,capacity,risk=self.current()
        proposal=DiagnosisProposal(**raw)
        if proposal.action=="NO_ACTION":return None
        decision=validate_proposal_safety(proposal,current,capacity,risk)
        if decision.status=="rejected":return None
        return self.save_pending(decision.plan,capacity,risk,"local_llm_diagnosis",proposal.explanation)

    def receive_award(self, result: dict):
        if result.get("status")!="awarded" or not result.get("award"):return None
        request=result.get("request",{});provider=result["award"]["provider_zone"];requester=request.get("requester_zone")
        if requester not in ZONES or provider not in ZONES:return None
        current,capacity,risk=self.current();shares=list(current.traffic_shares)
        demand=sum(float(s.get("current_rps",0)) for s in self.telemetry.values())
        delta=min(.2,float(result["award"]["capacity_rps"])/max(1.0,demand))
        src,dst=ZONES.index(requester),ZONES.index(provider)
        delta=min(delta,max(0.0,shares[src]-.02))
        if delta<=0:return None
        shares[src]-=delta;shares[dst]+=delta
        rationale=f"Contract-Net award: {provider} offered {result['award']['capacity_rps']} RPS to {requester}; pending operator review"
        decision=guard_plan(current,ZonePlan(current.replicas,tuple(shares)),capacity,1,10,2,.2,.02,risk)
        if decision.status=="rejected":return None
        return self.save_pending(decision.plan,capacity,risk,"contract_net",rationale)


async def run(nats_url: str):
    try:config.load_incluster_config()
    except config.ConfigException:config.load_kube_config()
    bridge=ProposalBridge(client.CustomObjectsApi(),client.AppsV1Api(),client.CoreV1Api())
    nc=NATS();await nc.connect(nats_url)
    async def process(msg):
        data=json.loads(msg.data);subject=msg.subject
        try:
            if subject.startswith("rebalance.telemetry."):bridge.telemetry[data["zone"]]=data;return
            if ".action.proposal." in subject: result=bridge.receive_action(data)
            elif ".diagnosis.proposal." in subject: result=bridge.receive_diagnosis(data)
            elif subject.startswith("rebalance.cnet.result."): result=bridge.receive_award(data)
            else:return
            if result:print(json.dumps({"proposal_created":result["metadata"]["name"],"approved":False}))
        except ApiException as exc:print(json.dumps({"error":"kubernetes_api","status":exc.status,"detail":str(exc)}))
        except Exception as exc:print(json.dumps({"error":str(exc),"subject":subject}))
    await nc.subscribe("rebalance.telemetry.*",cb=process)
    await nc.subscribe("rebalance.action.proposal.*",cb=process)
    await nc.subscribe("rebalance.diagnosis.proposal.*",cb=process)
    await nc.subscribe("rebalance.cnet.result.*",cb=process)
    print(json.dumps({"status":"ready","agent":"proposal_bridge","auto_approval":False}))
    try:
        while True:await asyncio.sleep(3600)
    finally:await nc.drain()


def main():
    p=argparse.ArgumentParser();p.add_argument("--nats",default=os.getenv("NATS_URL","nats://nats:4222"));a=p.parse_args();asyncio.run(run(a.nats))

if __name__=="__main__":main()
