"""Minute-level sensor agent: scrape one zone, score, alert, publish state."""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import time
from urllib.request import urlopen, Request

from nats.aio.client import Client as NATS
from prometheus_client import Counter, Gauge, start_http_server

RISK=Gauge("rebalancer_incident_risk_score","Modelled incident risk by zone",["zone"])
FORECAST=Gauge("rebalancer_demand_forecast_rps","Forecast RPS by zone and horizon",["zone"])
WARNING=Gauge("rebalancer_incident_warning","Whether current LightGBM score crosses the frozen threshold",["zone"])
HEALTHY=Gauge("rebalancer_zone_healthy","Current zone SLO health indicator",["zone"])
REPLICAS=Gauge("rebalancer_zone_replicas","Application replicas assigned to zone",["zone"])
HEADROOM=Gauge("rebalancer_safe_headroom_rps","Safe forecast headroom by zone",["zone"])
ERRORS=Counter("rebalancer_sensor_errors_total","Sensor/model API errors",["zone"])


def scrape_metrics(url: str) -> dict[str, float]:
    with urlopen(url, timeout=5) as response: text=response.read().decode()
    values={}
    for line in text.splitlines():
        if not line or line.startswith("#"): continue
        name, _, value=line.partition(" ")
        try: values[name]=float(value)
        except ValueError: pass
    names={"request_rate_rps":"demo_request_rate_rps","p95_latency_ms":"demo_p95_latency_ms",
           "error_rate":"demo_error_rate","process_cpu_percent_1_core":"process_cpu_percent_1_core",
           "process_max_rss_bytes":"process_max_rss_bytes"}
    missing=[key for key,name in names.items() if name not in values]
    if missing: raise ValueError("missing Prometheus metrics: "+", ".join(missing))
    return {key:values[name] for key,name in names.items()}


def post_json(url: str, body: dict) -> dict:
    req=Request(url,data=json.dumps(body).encode(),headers={"Content-Type":"application/json"})
    with urlopen(req,timeout=15) as response:return json.loads(response.read())


async def run(zone: str, service_metrics: str, model_api: str, nats_url: str, interval: int):
    start_http_server(int(os.getenv("METRICS_PORT","9102")))
    nc=NATS(); await nc.connect(nats_url)
    history=[]; rates=[]; latency=[]; errors=[]; cpu=[]; mem=[]
    alert_active=False
    print(json.dumps({"status":"ready","agent":"sensor","zone":zone}))
    while True:
        try:
            m=scrape_metrics(service_metrics)
            rates.append(m["request_rate_rps"]); latency.append(m["p95_latency_ms"]); errors.append(m["error_rate"]); cpu.append(m["process_cpu_percent_1_core"]); mem.append(m["process_max_rss_bytes"])
            rates=rates[-4:];latency=latency[-4:];errors=errors[-4:];cpu=cpu[-4:];mem=mem[-4:]
            rate=m["request_rate_rps"]
            history=(history+[rate])[-30:]
            fc=post_json(model_api+"/forecast",{"zone":zone,"history_rps":history,"horizon_minutes":5}) if len(history)>=6 else {"predicted_rps":[rate]}
            forecast=float(fc["predicted_rps"][-1])
            def slope(values):return (values[-1]-values[0])/max(1,len(values)-1) if len(values)>1 else 0.0
            features={"request_rate_rps":rate,"p95_latency_ms":m["p95_latency_ms"],"error_rate":m["error_rate"],
                      "process_cpu_percent_1_core_mean":m["process_cpu_percent_1_core"],"process_max_rss_bytes":m["process_max_rss_bytes"],
                      "request_rate_lag_1":rates[-2] if len(rates)>1 else None,"request_rate_mean_prev_3":sum(rates[:-1])/len(rates[:-1]) if len(rates)>1 else None,
                      "p95_latency_lag_1":latency[-2] if len(latency)>1 else None,"p95_latency_slope_prev_3":slope(latency[:-1]),
                      "error_rate_lag_1":errors[-2] if len(errors)>1 else None,"error_rate_mean_prev_3":sum(errors[:-1])/len(errors[:-1]) if len(errors)>1 else None}
            # This is the same CPU-only detector trained on the public AIOps
            # Challenge 2020 fault ledger that the AIOpsLab adapter uses.
            # Other measured signals remain available to diagnosis and SLO
            # safety checks; they are not misrepresented as model features.
            prior_cpu=cpu[:-1]
            risk_response=post_json(model_api+"/incident-risk-cpu",{"zone":zone,"observations":[{
                "process_cpu_percent_1_core_mean":m["process_cpu_percent_1_core"],
                "cpu_lag_1":prior_cpu[-1] if prior_cpu else None,
                "cpu_mean_prev_3":sum(prior_cpu[-3:])/len(prior_cpu[-3:]) if prior_cpu else None,
                "cpu_delta_from_prev_3":m["process_cpu_percent_1_core"]-(sum(prior_cpu[-3:])/len(prior_cpu[-3:])) if prior_cpu else None
            }]})
            risk=float(risk_response["risk_scores"][-1]); threshold=float(risk_response["threshold"])
            healthy=m["p95_latency_ms"]<=300 and m["error_rate"]<=.01
            RISK.labels(zone).set(risk);FORECAST.labels(zone).set(forecast);WARNING.labels(zone).set(int(risk>=threshold));HEALTHY.labels(zone).set(int(healthy))
            replicas=int(os.getenv("ZONE_REPLICAS","2")); safe_capacity=replicas*float(os.getenv("CAPACITY_PER_REPLICA_RPS","45"))
            REPLICAS.labels(zone).set(replicas);HEADROOM.labels(zone).set(max(0,safe_capacity*.8-max(rate,forecast)))
            state={"zone":zone,"timestamp":time.time(),"current_rps":rate,"forecast_rps":forecast,"safe_capacity_rps":safe_capacity,
                   "incident_risk":risk,"healthy":healthy,"replicas":replicas,"metrics":m,"model_threshold":threshold}
            await nc.publish(f"rebalance.telemetry.{zone}",json.dumps(state).encode())
            if risk>=threshold and not alert_active:
                alert={"type":"IncidentAlert","zone":zone,"timestamp":time.time(),"requires_diagnosis":True,
                       "model":risk_response.get("model","public_aiops2020_cpu_fault_lightgbm"),"risk_score":risk,"threshold":threshold,"evidence":{"current_window":m,"forecast":fc,"features":features}}
                await nc.publish(f"rebalance.incident.alert.{zone}",json.dumps(alert).encode())
                alert_active=True
            elif risk < threshold*.7:
                alert_active=False
        except Exception as exc:
            ERRORS.labels(zone).inc()
            await nc.publish(f"rebalance.sensor.error.{zone}",json.dumps({"zone":zone,"timestamp":time.time(),"error":str(exc)}).encode())
        await asyncio.sleep(interval)


def main():
    p=argparse.ArgumentParser();p.add_argument("--zone",required=True,choices=["zone-a","zone-b","zone-c"]);p.add_argument("--metrics-url",required=True);p.add_argument("--model-api",default=os.getenv("MODEL_API_URL","http://ml-service:8000"));p.add_argument("--nats",default=os.getenv("NATS_URL","nats://nats:4222"));p.add_argument("--interval",type=int,default=60);a=p.parse_args();asyncio.run(run(a.zone,a.metrics_url,a.model_api,a.nats,a.interval))

if __name__=="__main__":main()
