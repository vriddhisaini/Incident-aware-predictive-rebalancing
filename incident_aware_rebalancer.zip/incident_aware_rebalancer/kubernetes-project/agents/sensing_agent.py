"""Local service sensing and fast deterministic incident alert producer."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import time


@dataclass(frozen=True)
class SensedWindow:
    zone: str
    timestamp: float
    request_rate_rps: float
    p95_latency_ms: float
    error_rate: float
    cpu_percent_one_core: float
    memory_bytes: int
    healthy: bool


class SensingAgent:
    def __init__(self, latency_slo_ms: float = 300, error_slo: float = .01):
        self.latency_slo_ms = latency_slo_ms
        self.error_slo = error_slo
        self._latencies: dict[str, float] = {}

    def observe(self, zone: str, metrics: dict[str, float]) -> tuple[SensedWindow, dict | None]:
        required = ("request_rate_rps", "p95_latency_ms", "error_rate", "cpu_percent_one_core", "memory_bytes")
        if any(k not in metrics for k in required):
            raise ValueError("missing required sensing metrics")
        window = SensedWindow(zone, time.time(), *(float(metrics[k]) for k in required[:4]), int(metrics[required[4]]),
                              float(metrics["p95_latency_ms"]) <= self.latency_slo_ms and float(metrics["error_rate"]) <= self.error_slo)
        prior = self._latencies.get(zone)
        self._latencies[zone] = window.p95_latency_ms
        risk_signals = []
        if window.p95_latency_ms > self.latency_slo_ms: risk_signals.append("latency_slo_breach")
        if window.error_rate > self.error_slo: risk_signals.append("error_slo_breach")
        if prior is not None and window.p95_latency_ms > prior * 1.5: risk_signals.append("latency_jump")
        alert = None if not risk_signals else {"type": "IncidentAlert", "zone": zone, "timestamp": window.timestamp,
                                               "signals": risk_signals, "window": asdict(window), "requires_diagnosis": True}
        return window, alert

    @staticmethod
    def encode(value: dict) -> bytes:
        return json.dumps(value, separators=(",", ":")).encode()
