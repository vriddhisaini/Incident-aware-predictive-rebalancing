"""NATS Core runtime for one deterministic zone agent and Contract-Net bids."""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import time

from nats.aio.client import Client as NATS

from agents.protocol import CapacityAward, CapacityBid, CapacityConfirm, CapacityRequest, decode_request, encode, make_request
from agents.zone_agent import ZoneAgent, ZoneState, award_best


def _state_from_env(zone: str) -> ZoneState:
    prefix=zone.upper().replace("-", "_")
    return ZoneState(zone, float(os.getenv(prefix+"_CURRENT_RPS", "0")), float(os.getenv(prefix+"_FORECAST_RPS", "0")),
                     float(os.getenv(prefix+"_CAPACITY_RPS", "180")), float(os.getenv(prefix+"_INCIDENT_RISK", "0")),
                     os.getenv(prefix+"_HEALTHY", "true").lower()=="true", int(os.getenv(prefix+"_REPLICAS", "2")),
                     int(os.getenv("MIN_REPLICAS", "1")), int(os.getenv("MAX_REPLICAS", "10")), float(os.getenv("CAPACITY_PER_REPLICA_RPS", "45")))


async def zone_service(zone: str, server: str) -> None:
    nc=NATS(); await nc.connect(server)
    state=_state_from_env(zone)
    last_telemetry=0.0
    last_action_at=0.0
    pending_replicas=None
    pending_requests={}
    async def telemetry(msg):
        nonlocal state,last_action_at,pending_replicas,last_telemetry
        data=json.loads(msg.data)
        if data.get("zone") != zone: return
        state=ZoneState(zone, float(data["current_rps"]), float(data["forecast_rps"]), float(data["safe_capacity_rps"]),
                        float(data["incident_risk"]), bool(data["healthy"]), int(data["replicas"]), state.min_replicas,
                        state.max_replicas, state.capacity_per_replica_rps)
        last_telemetry=float(data.get("timestamp",time.time()))
        if pending_replicas is not None and state.replicas>=pending_replicas: pending_replicas=None
        if time.time()-last_action_at<30: return
        agent=ZoneAgent(state)
        local_target=agent.local_scale_target()
        if local_target is not None and local_target!=pending_replicas:
            proposal={"type":"RebalanceProposal","zone":zone,"action":"SCALE_OUT","target_replicas":local_target,
                     "reason":"local forecast headroom is insufficient; bounded local scale-out first","requires_safety_validation":True,"auto_execute":False}
            await nc.publish(f"rebalance.action.proposal.{zone}",json.dumps(proposal).encode())
            pending_replicas=local_target;last_action_at=time.time();return
        max_local_capacity=state.max_replicas*state.capacity_per_replica_rps*.8
        if state.forecast_rps>max_local_capacity:
            gap=state.forecast_rps-max_local_capacity
            req=make_request(zone,gap,5,"forecast demand exceeds local maximum safe capacity")
            asyncio.create_task(_negotiate_publish(req,server,zone))
            last_action_at=time.time()
    async def request(msg):
        req=decode_request(msg.data)
        if req.requester_zone == zone or time.time() > req.deadline_at: return
        pending_requests[req.request_id]=req
        if time.time()-last_telemetry>120:
            bid=CapacityBid(req.request_id,zone,0,1,state.incident_risk,.05,1e9,False,"provider telemetry is stale",time.time())
        else:
            bid=ZoneAgent(state).bid(req)
        await nc.publish(f"rebalance.cnet.bid.{req.request_id}", encode(bid))
    async def award(msg):
        raw=json.loads(msg.data);raw.pop("type",None);offer=CapacityAward(**raw)
        if offer.provider_zone!=zone:return
        request_obj=pending_requests.pop(offer.request_id,None)
        if request_obj is None:
            confirm=CapacityConfirm(offer.request_id,zone,False,"no matching live request",time.time())
        else:
            bid=ZoneAgent(state).bid(request_obj)
            accepted=time.time()<=request_obj.deadline_at and bid.feasible and bid.capacity_rps>=offer.awarded_rps
            confirm=CapacityConfirm(offer.request_id,zone,accepted,"capacity rechecked and reserved" if accepted else "capacity is no longer feasible",time.time())
        await nc.publish(f"rebalance.cnet.confirm.{offer.request_id}",encode(confirm))
    await nc.subscribe(f"rebalance.telemetry.{zone}", cb=telemetry)
    await nc.subscribe("rebalance.cnet.request", cb=request)
    await nc.subscribe("rebalance.cnet.award.*", cb=award)
    print(json.dumps({"status":"ready","agent":"zone","zone":zone,"nats":server}))
    try:
        while True: await asyncio.sleep(3600)
    finally:
        await nc.drain()


async def _negotiate_publish(request,server,requester):
    result=await negotiate(request,server)
    nc=NATS();await nc.connect(server)
    await nc.publish(f"rebalance.cnet.result.{requester}",json.dumps(result).encode())
    await nc.drain()


async def negotiate(request: CapacityRequest, server: str, collection_s: float = .5) -> dict:
    request.validate()
    nc=NATS(); await nc.connect(server)
    bids=[]
    async def receive(msg):
        d=json.loads(msg.data); d.pop("type",None); bids.append(CapacityBid(**d))
    sub=await nc.subscribe(f"rebalance.cnet.bid.{request.request_id}",cb=receive)
    await nc.publish("rebalance.cnet.request",encode(request)); await nc.flush()
    await asyncio.sleep(min(collection_s,max(.01,request.deadline_at-time.time())))
    await sub.unsubscribe()
    status,best=award_best(request,bids)
    confirmation=None
    if best is not None:
        event=asyncio.Event()
        async def receive_confirm(msg):
            nonlocal confirmation
            confirmation=json.loads(msg.data);event.set()
        confirm_sub=await nc.subscribe(f"rebalance.cnet.confirm.{request.request_id}",cb=receive_confirm)
        offer=CapacityAward(request.request_id,request.requester_zone,best.provider_zone,best.capacity_rps,best.cost,time.time())
        await nc.publish(f"rebalance.cnet.award.{request.request_id}",encode(offer));await nc.flush()
        try:await asyncio.wait_for(event.wait(),timeout=max(.05,min(.75,request.deadline_at-time.time())))
        except asyncio.TimeoutError:pass
        await confirm_sub.unsubscribe()
        if not confirmation or not confirmation.get("accepted"):status="award_unconfirmed"
    result={"status":status,"request":json.loads(encode(request)),"bids":[json.loads(encode(b)) for b in bids],
            "award":None if best is None or status!="awarded" else {"provider_zone":best.provider_zone,"capacity_rps":best.capacity_rps,"bid_cost":best.cost},
            "confirmation":confirmation}
    await nc.drain()
    return result


def main():
    p=argparse.ArgumentParser(); p.add_argument("mode",choices=["zone","request"]); p.add_argument("--zone",choices=["zone-a","zone-b","zone-c"]); p.add_argument("--nats",default=os.getenv("NATS_URL","nats://127.0.0.1:4222")); p.add_argument("--requester",choices=["zone-a","zone-b","zone-c"]); p.add_argument("--required-rps",type=float); p.add_argument("--horizon",type=int,default=5); p.add_argument("--reason",default="insufficient local forecast headroom"); p.add_argument("--timeout",type=float,default=2.0); args=p.parse_args()
    if args.mode=="zone":
        if not args.zone: p.error("--zone is required in zone mode")
        asyncio.run(zone_service(args.zone,args.nats))
    else:
        if not args.requester or not args.required_rps: p.error("request mode requires --requester and --required-rps")
        from agents.protocol import make_request
        request=make_request(args.requester,args.required_rps,args.horizon,args.reason,args.timeout)
        print(json.dumps(asyncio.run(negotiate(request,args.nats)),indent=2))

if __name__=="__main__": main()
