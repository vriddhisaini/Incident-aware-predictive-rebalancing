"""Versioned typed messages for the zone-agent Contract-Net protocol."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import math
import time
from typing import Any


@dataclass(frozen=True)
class CapacityRequest:
    request_id: str
    requester_zone: str
    required_rps: float
    horizon_minutes: int
    reason: str
    created_at: float
    deadline_at: float
    version: int = 1

    def validate(self) -> None:
        if not self.request_id or self.requester_zone not in {"zone-a", "zone-b", "zone-c"}:
            raise ValueError("request ID and known requester zone are required")
        if not math.isfinite(self.required_rps) or self.required_rps <= 0 or self.horizon_minutes < 1:
            raise ValueError("request demand and horizon must be positive finite values")
        if self.deadline_at <= self.created_at or self.version != 1:
            raise ValueError("invalid request deadline or protocol version")


@dataclass(frozen=True)
class CapacityBid:
    request_id: str
    provider_zone: str
    capacity_rps: float
    projected_utilization: float
    incident_risk: float
    transfer_penalty: float
    cost: float
    feasible: bool
    reason: str
    created_at: float
    version: int = 1


@dataclass(frozen=True)
class CapacityAward:
    request_id: str
    requester_zone: str
    provider_zone: str
    awarded_rps: float
    bid_cost: float
    created_at: float
    version: int = 1


@dataclass(frozen=True)
class CapacityConfirm:
    request_id: str
    provider_zone: str
    accepted: bool
    reason: str
    created_at: float
    version: int = 1


def encode(message: Any) -> bytes:
    return json.dumps({"type": type(message).__name__, **asdict(message)}, separators=(",", ":")).encode()


def decode_request(payload: bytes) -> CapacityRequest:
    raw = json.loads(payload)
    if raw.pop("type", None) != "CapacityRequest":
        raise ValueError("expected CapacityRequest")
    req = CapacityRequest(**raw)
    req.validate()
    return req


def make_request(requester: str, required_rps: float, horizon: int, reason: str, timeout_s: float = 2.0) -> CapacityRequest:
    now = time.time()
    req = CapacityRequest(f"{requester}-{int(now*1000)}", requester, required_rps, horizon, reason,
                          now, now+timeout_s)
    req.validate()
    return req
