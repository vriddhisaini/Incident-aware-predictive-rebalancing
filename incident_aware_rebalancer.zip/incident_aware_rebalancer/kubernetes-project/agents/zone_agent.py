"""Deterministic zone agent and Contract-Net bid scoring."""
from __future__ import annotations

from dataclasses import dataclass
import math
import time

from agents.protocol import CapacityBid, CapacityRequest


@dataclass(frozen=True)
class ZoneState:
    zone: str
    current_rps: float
    forecast_rps: float
    safe_capacity_rps: float
    incident_risk: float
    healthy: bool
    replicas: int
    min_replicas: int
    max_replicas: int
    capacity_per_replica_rps: float

    @property
    def headroom_rps(self) -> float:
        return max(0.0, self.safe_capacity_rps * .80 - max(self.current_rps, self.forecast_rps))


class ZoneAgent:
    def __init__(self, state: ZoneState, risk_limit: float = .70, safe_utilization: float = .80):
        self.state = state
        self.risk_limit = risk_limit
        self.safe_utilization = safe_utilization

    def local_scale_target(self, max_step: int = 2) -> int | None:
        """Prefer bounded local scaling before asking peers for capacity."""
        s=self.state
        if not s.healthy or s.incident_risk >= self.risk_limit or s.capacity_per_replica_rps <= 0:
            return None
        need=max(s.min_replicas, int(math.ceil(s.forecast_rps/(s.capacity_per_replica_rps*self.safe_utilization))))
        need=min(s.max_replicas,need)
        return min(need,s.replicas+max_step) if s.replicas < need else None

    def bid(self, request: CapacityRequest, transfer_penalty: float = .05) -> CapacityBid:
        request.validate()
        now = time.time()
        s = self.state
        if s.zone == request.requester_zone:
            return CapacityBid(request.request_id, s.zone, 0, 1, s.incident_risk, transfer_penalty, 1e9, False, "requester cannot bid for itself", now)
        capacity = request.required_rps if s.headroom_rps >= request.required_rps else 0.0
        projected = (max(s.current_rps, s.forecast_rps) + capacity) / max(1.0, s.safe_capacity_rps)
        feasible = s.healthy and s.incident_risk < self.risk_limit and capacity >= request.required_rps and projected <= self.safe_utilization
        reason = "feasible" if feasible else "unhealthy, risky, or insufficient safe headroom"
        # Lower cost wins; infeasible offers are reported for audit but cannot be awarded.
        cost = projected + 2.0*s.incident_risk + transfer_penalty
        return CapacityBid(request.request_id, s.zone, capacity, projected, s.incident_risk,
                           transfer_penalty, cost, feasible, reason, now)


def award_best(request: CapacityRequest, bids: list[CapacityBid]) -> tuple[str, CapacityBid | None]:
    valid = [b for b in bids if b.request_id == request.request_id and b.feasible and
             b.provider_zone != request.requester_zone and b.capacity_rps > 0]
    if time.time() > request.deadline_at:
        return "timeout", None
    if not valid:
        return "no_feasible_bid", None
    best = min(valid, key=lambda b: (b.cost, b.provider_zone))
    return "awarded", best
