"""Local sensing, zone rebalancing and Contract-Net agent primitives."""
