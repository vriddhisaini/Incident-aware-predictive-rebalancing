"""Open-loop local HTTP load generator and telemetry scraper (stdlib only)."""

from __future__ import annotations

import argparse
import csv
import json
import math
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from urllib.request import urlopen


METRIC_KEYS = {
    "demo_request_rate_rps": "request_rate_rps",
    "demo_error_rate": "rolling_error_rate",
    "demo_p95_latency_ms": "rolling_p95_latency_ms",
    "demo_requests_total": "requests_total",
    "demo_errors_total": "errors_total",
    "process_cpu_seconds_total": "process_cpu_seconds_total",
    "process_cpu_percent_1_core": "process_cpu_percent_1_core",
    "process_max_rss_bytes": "process_max_rss_bytes",
}


def _build_url(base_url: str, parameters: dict[str, float | int]) -> str:
    parts = urlsplit(base_url)
    query = dict(parse_qsl(parts.query))
    query.update({key: str(value) for key, value in parameters.items()})
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))


def _request(url: str, scheduled_epoch: float, scheduled_offset: float) -> dict[str, float | int]:
    start = time.monotonic()
    status = 0
    try:
        with urlopen(url, timeout=15) as response:
            status = response.status
            response.read()
    except HTTPError as error:
        status = error.code
        error.read()
    except (URLError, TimeoutError, OSError):
        status = 0
    finished = time.monotonic()
    return {
        "scheduled_epoch": scheduled_epoch,
        "scheduled_offset_s": scheduled_offset,
        "completed_epoch": time.time(),
        "latency_ms": (finished - start) * 1000.0,
        "status_code": status,
    }


def _parse_metrics(text: str) -> dict[str, float | int]:
    values: dict[str, float | int] = {}
    for line in text.splitlines():
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) != 2 or parts[0] not in METRIC_KEYS:
            continue
        try:
            value = float(parts[1])
        except ValueError:
            continue
        target = METRIC_KEYS[parts[0]]
        values[target] = int(value) if target.endswith("_total") or target.endswith("_bytes") else value
    return values


def _scrape_metrics(base_url: str, stop: threading.Event, interval: float,
                    samples: list[dict[str, float | int]]) -> None:
    parts = urlsplit(base_url)
    metrics_url = urlunsplit((parts.scheme, parts.netloc, "/metrics", "", ""))
    while not stop.is_set():
        try:
            with urlopen(metrics_url, timeout=5) as response:
                sample = _parse_metrics(response.read().decode("utf-8", "replace"))
            sample["sample_epoch"] = time.time()
            samples.append(sample)
        except (HTTPError, URLError, TimeoutError, OSError):
            samples.append({"sample_epoch": time.time(), "scrape_failed": 1})
        stop.wait(interval)


def _write_csv(path: Path, rows: list[dict[str, float | int]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _load_phases(profile_path: Path | None, args: argparse.Namespace) -> tuple[str, list[dict[str, float | int | str | bool]]]:
    if profile_path is None:
        return "single_phase", [{
            "name": "single_phase", "duration_seconds": args.duration_seconds,
            "rps": args.rps, "cpu_ms": args.cpu_ms, "delay_ms": args.delay_ms,
            "fail_every": args.fail_every, "incident": args.fail_every > 0 or args.delay_ms >= 300,
        }]
    with profile_path.open(encoding="utf-8") as stream:
        document = json.load(stream)
    selected = next((item for item in document["profiles"] if item["name"] == args.profile_name), None)
    if selected is None:
        known = ", ".join(item["name"] for item in document.get("profiles", []))
        raise ValueError(f"Unknown profile {args.profile_name!r}; available profiles: {known}")
    phases = selected["phases"]
    if not phases:
        raise ValueError("A workload profile must contain at least one phase")
    for phase in phases:
        if float(phase["duration_seconds"]) <= 0 or float(phase["rps"]) <= 0:
            raise ValueError("Each profile phase needs positive duration_seconds and rps")
    return selected["name"], phases


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate local traffic and collect telemetry")
    parser.add_argument("--url", default="http://127.0.0.1:8000/work")
    parser.add_argument("--rps", type=float, default=10.0, help="Target request starts per second")
    parser.add_argument("--duration-seconds", type=float, default=120.0)
    parser.add_argument("--profile", type=Path, help="JSON file containing named phase-based workloads")
    parser.add_argument("--profile-name", default="", help="Profile name to run from --profile")
    parser.add_argument("--workers", type=int, default=32)
    parser.add_argument("--cpu-ms", type=float, default=2.0, help="Synthetic CPU work per request")
    parser.add_argument("--delay-ms", type=float, default=0.0, help="Synthetic service delay per request")
    parser.add_argument("--fail-every", type=int, default=0, help="Return HTTP 500 every Nth app request; 0 disables")
    parser.add_argument("--sample-interval-seconds", type=float, default=10.0)
    parser.add_argument("--output-dir", type=Path, default=Path("telemetry/run-1"))
    args = parser.parse_args()
    if args.rps <= 0 or args.duration_seconds <= 0 or args.workers < 1 or args.sample_interval_seconds <= 0:
        parser.error("RPS, duration, workers, and sample interval must be positive")
    if args.profile and not args.profile_name:
        parser.error("--profile-name is required when using --profile")
    try:
        profile_name, phases = _load_phases(args.profile, args)
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as error:
        parser.error(str(error))

    start_mono, start_epoch = time.monotonic(), time.time()
    total_duration = sum(float(phase["duration_seconds"]) for phase in phases)
    count = sum(math.ceil(float(phase["rps"]) * float(phase["duration_seconds"])) for phase in phases)
    stop_scraper = threading.Event()
    samples: list[dict[str, float | int]] = []
    scraper = threading.Thread(target=_scrape_metrics,
                               args=(args.url, stop_scraper, args.sample_interval_seconds, samples),
                               daemon=True)
    scraper.start()
    requests: list[dict[str, float | int]] = []

    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = []
        phase_start = 0.0
        for phase in phases:
            duration = float(phase["duration_seconds"])
            phase_rps = float(phase["rps"])
            phase_count = math.ceil(phase_rps * duration)
            query = {
                "cpu_ms": max(0.0, float(phase.get("cpu_ms", args.cpu_ms))),
                "delay_ms": max(0.0, float(phase.get("delay_ms", args.delay_ms))),
                "fail_every": max(0, int(phase.get("fail_every", args.fail_every))),
            }
            url = _build_url(args.url, query)
            for index in range(phase_count):
                offset = phase_start + index / phase_rps
                scheduled = start_mono + offset
                delay = scheduled - time.monotonic()
                if delay > 0:
                    time.sleep(delay)
                futures.append(executor.submit(_request, url, start_epoch + offset, offset))
            phase_start += duration
        for future in as_completed(futures):
            requests.append(future.result())

    stop_scraper.set()
    scraper.join(timeout=args.sample_interval_seconds + 1.0)
    requests.sort(key=lambda item: float(item["scheduled_epoch"]))
    for row in requests:
        status = int(row["status_code"])
        row["status_class"] = status // 100 if status else 0
    _write_csv(args.output_dir / "request_log.csv", requests)
    _write_csv(args.output_dir / "service_metrics.csv", samples)
    phase_metadata: list[dict[str, float | int | str | bool]] = []
    phase_start = 0.0
    fault_start = None
    for phase in phases:
        item = dict(phase)
        item["start_offset_seconds"] = phase_start
        phase_metadata.append(item)
        if fault_start is None and bool(phase.get("incident", False)):
            fault_start = phase_start
        phase_start += float(phase["duration_seconds"])
    metadata = {
        "profile_name": profile_name,
        "source_profile_file": str(args.profile) if args.profile else None,
        "start_epoch": start_epoch,
        "planned_duration_seconds": total_duration,
        "target_request_count": count,
        "fault_start_offset_seconds": fault_start,
        "phases": phase_metadata,
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "run_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")

    errors = sum(int(row["status_code"]) >= 500 or int(row["status_code"]) == 0 for row in requests)
    latencies = sorted(float(row["latency_ms"]) for row in requests)
    p95 = latencies[max(0, math.ceil(len(latencies) * 0.95) - 1)] if latencies else 0.0
    wall_seconds = max(0.001, time.monotonic() - start_mono)
    print(f"Profile {profile_name}: scheduled {count} requests over {total_duration:.1f}s")
    print(f"Completed {len(requests)} in {wall_seconds:.1f}s ({len(requests)/wall_seconds:.2f} RPS); "
          f"observed errors: {errors}; client p95 latency: {p95:.2f} ms")
    print(f"Request log: {args.output_dir / 'request_log.csv'}")
    print(f"Service metric samples: {args.output_dir / 'service_metrics.csv'}")


if __name__ == "__main__":
    main()
