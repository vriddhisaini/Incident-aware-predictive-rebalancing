"""Build an evidence-first report from the artifacts currently available."""
from __future__ import annotations
import argparse,csv,json
from pathlib import Path

def read_json(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def fmt(x,d=3): return "n/a" if x is None else f"{x:.{d}f}"

def build(root:Path,out:Path):
    sim=list(csv.DictReader((root/'data/processed/safety-evaluation/summary.csv').open()))
    incident=read_json(root/'data/processed/incident_models/report.json')
    cpu=read_json(root/'data/processed/incident_models/models/cpu_only_report.json')
    cpu_mapping_path=root/'data/processed/aiopslab/cpu_mapping_audit_refit.json'
    cpu_mapping=read_json(cpu_mapping_path) if cpu_mapping_path.exists() else None
    forecast=read_json(root/'data/processed/forecast_models/report.json')
    slo=read_json(root/'data/processed/slo_calibration.json')
    rows=[]
    for scenario in ['zone_b_fault_no_early_warning','zone_b_fault_5m_warning','demand_burst_severe']:
        for policy in ['reactive','forecast_only','full_system']:
            r=next((r for r in sim if r['scenario']==scenario and r['policy']==policy),None)
            if r: rows.append(f"| {scenario} | {policy} | {r['minutes_over_either_slo']} | {r['total_dropped_requests']} | {r['mean_replicas']} | {r['replica_changes']} |")
    metrics=[]
    for name,r in incident['models'].items():
        x=r['test'];metrics.append(f"| {name} | {fmt(x['precision'])} | {fmt(x['recall'])} | {fmt(x['fpr'])} | {x['tp']}/{x['fn']} | {x['fp']}/{x['tn']} |")
    fmetrics=[]
    for r in forecast['metrics']:
        fmetrics.append(f"| {r['model']} | {fmt(r.get('mae'))} | {fmt(r.get('rmse'))} | {fmt(r.get('smape'))} | {fmt(r.get('interval_coverage'))} |")
    p95=slo['no_fault_run_maxima']['p95_latency_ms'];err=slo['no_fault_run_maxima']['error_rate']
    aiopslab_specs=[
        ('LLM high CPU','aiopslab/high_cpu_llm_results.json'),
        ('LLM no-fault','aiopslab/no_fault_llm_results.json'),
        ('CPU LightGBM high CPU','aiopslab/high_cpu_cpu_detector_results.json'),
        ('CPU LightGBM no-fault','aiopslab/no_fault_cpu_detector_results.json'),
    ]
    aiopslab_rows=[]
    for label,relative in aiopslab_specs:
        path=root/'data/processed'/relative
        if not path.exists(): continue
        artifact=read_json(path); result=artifact.get('results',[{}])[0]
        diag=result.get('agent_diagnostics',{}); task=result.get('results',{})
        cpu_values=diag.get('cpu_usage_percent_1_core',[])
        cpu_max=diag.get('max_cpu_percent_one_core',diag.get('cpu_max_percent_1_core',max(cpu_values) if cpu_values else None))
        aiopslab_rows.append(f"| {label} | {diag.get('decision','n/a')} | {task.get('Detection Accuracy',result.get('error','n/a'))} | {fmt(cpu_max,2)} | {fmt(task.get('TTD'),1)} |")
    cloudsim_rows=[]
    cloudsim_sample_rows=5000 if (root/'data/processed/google_trace/cloudsim_reactive_results_5000.csv').exists() else 1000
    for policy in ['reactive','forecast_only','full_system']:
        suffix='_results_5000.csv' if cloudsim_sample_rows==5000 else '_results.csv'
        path=root/f'data/processed/google_trace/cloudsim_{policy}{suffix}'
        if not path.exists(): continue
        records=list(csv.DictReader(path.open(newline='',encoding='utf-8')))
        if not records: continue
        execs=sorted(float(r['execution_time_s']) for r in records)
        waits=[float(r['waiting_time_s']) for r in records]
        cloudsim_p95=execs[min(len(execs)-1,int(.95*(len(execs)-1)))]
        cloudsim_rows.append(f"| {policy} | {len(records)} | {sum(r['status']=='SUCCESS' for r in records)} | {fmt(sum(execs)/len(execs),2)} | {fmt(cloudsim_p95,2)} | {fmt(sum(waits)/len(waits),2)} |")
    text=f'''# Final Evaluation Report — Locally Verified Research Prototype

**Generated from recorded artifacts.** Simulator outcomes are model outputs; local SLO calibration uses a small scripted service. AIOpsLab and Kubernetes acceptance have been run locally, with limitations listed below. One public Google ClusterData shard has been replayed through a bounded CloudSim sample.

## Evaluation coverage

- Simulator: {len({r['scenario'] for r in sim})} scenarios, three policies, refreshed local outputs.
- Incident dataset: {incident['counts']['rows']} minute windows across {incident['counts']['fit_runs']+incident['counts']['validation_runs']+incident['counts']['test_runs']} scripted run groups; held-out metrics use {incident['counts']['test_runs']} complete run groups.
- Forecast: per-run chronological holdout; {forecast.get('evaluated_runs','n/a')} evaluated runs. These short traces do not identify daily/weekly seasonality.
- Provisional SLO: p95 latency {slo['provisional_thresholds']['latency_p95_ms']} ms; error rate {slo['provisional_thresholds']['error_rate']:.1%}. The collected dataset has {slo['no_fault_runs']} known control run{'s' if slo['no_fault_runs'] != 1 else ''}, {slo['fault_injected_runs']} fault-injected runs, and {slo['unknown_status_runs']} run{'s' if slo['unknown_status_runs'] != 1 else ''} without usable labels. Control-run maximum p95 latency median/p95/max was {fmt(p95['median'],1)}/{fmt(p95['p95'],1)}/{fmt(p95['max'],1)} ms; maximum error-rate median/p95/max was {fmt(err['median'],3)}/{fmt(err['p95'],3)}/{fmt(err['max'],3)}. These scripted runs are descriptive only and do not establish an externally approved SLO.

## Simulator comparison

| Scenario | Policy | Minutes over either modeled SLO | Modeled dropped requests | Mean replicas | Replica changes |
|---|---|---:|---:|---:|---:|
{chr(10).join(rows)}

A synthetic warning drives the full-system advantage when early enough. This comparison does not validate detector accuracy or live service behavior.

## Incident model held-out results

| Model | Precision | Recall | False-positive rate | TP/FN | FP/TN |
|---|---:|---:|---:|---:|---:|
{chr(10).join(metrics)}

The small grouped test set is too weak to justify automatic actions. Logistic regression detects more positives but raises false alarms; full LightGBM misses more positives.

### CPU-only AIOpsLab transfer model (local grouped holdout)

| Precision | Recall | False-positive rate | Test PR-AUC | Threshold |
|---:|---:|---:|---:|---:|
| {fmt(cpu['test']['precision'])} | {fmt(cpu['test']['recall'])} | {fmt(cpu['test']['fpr'])} | {fmt(cpu['test']['pr_auc'])} | {fmt(cpu['threshold'])} |

This intentionally uses only CPU and cannot detect faults with no CPU precursor.

### Offline AIOpsLab re-score after adding five healthy calibration runs

| Saved case export | Windows | Max minute-mean CPU (% of one core) | Max counter interval (% of one core) | Mean-feature warnings | Peak-substitution warnings (diagnostic only) |
|---|---:|---:|---:|---:|---:|
{chr(10).join(f'| {case} | {metrics["windows"]} | {fmt(metrics["max_window_mean_cpu_percent_one_core"],2)} | {fmt(metrics["max_interval_cpu_percent_one_core"],2)} | {metrics["mean_feature_warnings"]}/{metrics["windows"]} | {metrics["peak_feature_counterfactual_warnings"]}/{metrics["windows"]} |' for case,metrics in cpu_mapping['results'].items()) if cpu_mapping else '| No offline mapping re-score saved | n/a | n/a | n/a | n/a | n/a |'}

This applies the refit CPU model and its validation-selected threshold to the previously saved AIOpsLab raw exports; it is not a new cluster trial. The mean-feature path warned in two of four high-CPU windows and zero of five no-fault windows. Peak substitution increased warnings to three of four and three of five, so it remains audit-only and outside the model contract. The single case pair cannot support reliable recall or false-alarm estimates.

### AIOpsLab live transfer checks

| Agent / case | Decision | AIOpsLab score | Max CPU (% of one core) | TTD (s) |
|---|---|---|---:|---:|
{chr(10).join(aiopslab_rows) if aiopslab_rows else '| No saved run artifacts | n/a | n/a | n/a | n/a |'}

The LLM was scored correct on one injected high-CPU case and one no-fault control. The original CPU-only model missed the injected case and correctly returned No on the control. Observed CPU during that injected case peaked at 10.60% one-core minute mean, with a 33.95% peak interval. A separate AIOpsLab re-run was stopped before scoring: Astronomy Shop init containers looped on the Kafka readiness check and the local Kubernetes API became intermittently unavailable during startup. Its attempt and the offline re-score are recorded under `data/processed/aiopslab/`; no new task-level score is claimed. After the attempt, Docker Desktop was restarted; all four kind nodes and all 17 project deployments were reverified Ready, the failed AIOpsLab namespaces were removed, and Ollama inference succeeded again. No new AIOpsLab task score was produced.

The adapter now records both the mean CPU across counter intervals per minute and the peak interval as diagnostic metadata, while the model still consumes only its trained one-minute-mean feature. Peak substitution is outside that feature contract. On the original saved model it produced 1 warning in 4 high-CPU windows and 2 in 5 no-fault windows; after refitting with added controls it produced 3/4 and 3/5 warnings. The increase in no-fault warnings confirms peak substitution is not a safe mapping change.

## Forecast model results

| Model | MAE (RPS) | RMSE (RPS) | sMAPE | 95% interval coverage |
|---|---:|---:|---:|---:|
{chr(10).join(f'| {r["model"]} | {fmt(r.get("mae_rps"))} | {fmt(r.get("rmse_rps"))} | {fmt(r.get("smape_pct"))} | {fmt(r.get("interval_95_coverage"))} |' for r in forecast['metrics'])}

Near-zero SARIMA errors on flat scripted segments indicate unsuitable test traces/overfit behavior, not forecasting success.

## CloudSim Plus policy comparison

| Placement policy | Workload rows | Successful Cloudlets | Mean execution time (s) | p95 execution time (s) | Mean queue wait (s) |
|---|---:|---:|---:|---:|---:|
{chr(10).join(cloudsim_rows) if cloudsim_rows else '| No policy comparison artifacts | n/a | n/a | n/a | n/a | n/a |'}

This is a deterministic {cloudsim_sample_rows:,}-row sample of one Google ClusterData shard, evenly spaced across its 0–93 minute span. `reactive` preserves trace zone assignments; `forecast_only` routes using a five-minute trailing zone-load estimate; `full_system` adds a high-load risk penalty to that forecast. The trace has no application-fault labels, and the risk penalty did not activate when its threshold was not reached; forecast-only and full-system therefore matched. These are CloudSim placement-policy experiments under coarse CPU assumptions, not evidence of incident-detection benefit or production savings.

## Project finalization status

- **Implemented and locally verified:** three-zone simulator, telemetry pipeline, forecast and incident APIs, NATS negotiation, diagnosis/proposal bridge, operator safety gate, public trace conversion, and bounded CloudSim sample.
- **Kubernetes:** all core deployments and NATS reached Ready. Model endpoints returned valid responses, Ollama `qwen3:0.6b` generated `OK` in-cluster, Prometheus had 9/9 active targets up, and Grafana health plus the provisioned dashboard were verified. A pending plan stayed inert; an approved bounded plan scaled zone A from one to two replicas and changed traffic shares; an approved recovery plan restored the baseline; an invalid plan was rejected without mutation. Acceptance exposed and fixed operator RBAC for Kopf discovery and status writes. A fresh no-cache ARM64 Docker build has now completed, and the built image returned a healthy model-service response.
- **AIOpsLab:** both LLM and CPU-only agents ran high-CPU and no-fault cases. The one-off LLM pair scored correct; CPU-only LightGBM missed high CPU and passed the no-fault control. CPU telemetry did not show a strong high-CPU signal, so the benchmark does not validate detector transfer quality.
- **Ollama:** Ollama 0.40.11 and `qwen3:0.6b` are present. Host and Kubernetes inference succeeded; the AIOpsLab adapter uses host inference for faster evaluation.
- **Public trace:** Downloaded and checksum-recorded one official Google ClusterData 2011-2 task-events shard under CC-BY 4.0. Converted 450,146 events to 109,434 machine-minute rows and 64,868 schedulable workload rows. Scheduler failures are not application incident labels.
- **CloudSim Plus:** a clean Maven compile and deterministic {cloudsim_sample_rows:,}-row replay ran for reactive, forecast-only, and full-system placement policies. The full 64,868-row replay is computationally impractical in this local run window. The adapter uses coarse CPU-request/MIPS assumptions, does not model RAM/bandwidth, and treats Google scheduler records as workloads rather than service incidents.
- **Finalization decision:** the local research prototype and its core architecture, safety controls, Kubernetes acceptance, fresh container build, public-trace sample, and experiment reports are implemented. Evaluation remains limited by scripted/local data, small independent holdouts, weak AIOpsLab CPU signal, and an incomplete full-shard run. Therefore automatic actuation remains disabled behind the human approval gate; no production-readiness or detector-generalization claim is made. Chaos Mesh is an optional extension, not a required core acceptance item.

## Reproduce the report

```sh
python calibrate_slo.py
python run.py --output-dir data/processed/safety-evaluation
python forecast_models.py --output-dir data/processed/forecast_models
python train_incident_models.py --output-dir data/processed/incident_models
python train_cpu_incident_model.py
python build_final_report.py
```

Source reports: `data/processed/incident_models/report.json`, `data/processed/incident_models/models/cpu_only_report.json`, `data/processed/forecast_models/report.json`, `data/processed/slo_calibration.json`, `data/processed/safety-evaluation/summary.csv`, and `data/processed/google_trace/cloudsim_*_results.csv`.
'''
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(text,encoding="utf-8")
    return out

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--output',type=Path,default=Path('data/processed/final_evaluation_report.md'));a=p.parse_args();print(build(a.root,a.output))
if __name__=='__main__':main()
