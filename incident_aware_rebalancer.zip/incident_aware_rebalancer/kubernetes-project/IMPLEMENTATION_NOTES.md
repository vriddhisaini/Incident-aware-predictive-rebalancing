# Implementation Notes

**Project:** Incident-Aware Predictive Rebalancing of Cloud Computing Resources  
**Updated:** 2026-10-27  
**Purpose:** Living record of implementation stages, decisions, results, and next steps.

Update this document as project work is completed. Record what changed, why, how it was evaluated, and any limitations. The simulator results below are illustrative software-model outputs; they are not measurements from a production cloud or a live service.

## Project goal and constraints

Build a reproducible, software-only prototype that compares resource-rebalancing policies using two distinct signals:

1. A demand forecast for expected workload.
2. An incident-risk estimate for abnormal service degradation.

The final system should show how those signals affect traffic allocation and replica counts across three logical zones. Keep the core project open source and runnable locally, with no paid subscriptions, cloud accounts, or paid APIs required. Any selected dataset and local language model must have separately checked use and redistribution terms.

The current control scope is intentionally limited to changing replica counts and traffic shares. Live VM migration, production deployment, and automated restart or rollback actions are outside the initial prototype.

## Stage roadmap

### Stage 0 — Scope and experimental definitions — In progress

- [x] Define the project as incident-aware predictive resource rebalancing.
- [x] Separate routine demand forecasting from incident-risk detection.
- [x] Set a local, open-source, no-paid-subscription constraint.
- [x] Choose three logical zones for the first simulator.
- [x] Set provisional demonstration SLO thresholds of p95 latency under 300 ms and 5xx error rate under 1%, supported by an initial healthy-versus-degraded local run.
- [ ] Confirm those thresholds across repeated healthy runs and representative fault scenarios before freezing final evaluation rules.
- [ ] Define the primary incident labels, prediction horizon, and workload scenarios before final model evaluation.

### Stage 1 — Deterministic three-zone simulator — Prototype complete

- [x] Create a repeatable simulator for three zones.
- [x] Compare reactive, forecast-only, and full-system policies on matching scenarios.
- [x] Model replica limits, traffic shares, a one-minute action delay, simplified latency, errors, dropped requests, and replica changes.
- [x] Add normal-load, demand-burst, and Zone B fault scenarios.
- [x] Add a synthetic incident-risk warning five minutes before the Zone B fault.
- [x] Write per-minute data to `results.csv` and policy/scenario aggregates to `summary.csv`.

**Current prototype assumptions:** Each replica handles 45 RPS before capacity modifiers; each zone is limited to 10 replicas; all policies start with two replicas per zone; actions take effect one minute after a decision; the forecast is a five-minute linear trend estimate with a floor at current demand; and the risk warning is a synthetic configured input. Latency and error formulas are simplified approximations. The active SLO thresholds are configuration placeholders, not calibrated against a sample service.

**Initial simulator run before the scenario sensitivity sweep (superseded):**

| Scenario | Policy | Minutes above latency SLO | Mean error rate | Modeled dropped requests | Mean replicas | Replica changes |
|---|---|---:|---:|---:|---:|---:|
| Normal load | Reactive | 0 | 0.0024 | 30.00 | 5.96 | 3 |
| Normal load | Forecast-only | 0 | 0.0024 | 30.00 | 5.96 | 3 |
| Normal load | Full system | 0 | 0.0024 | 30.00 | 5.96 | 3 |
| Demand burst | Reactive | 0 | 0.0024 | 30.00 | 8.92 | 21 |
| Demand burst | Forecast-only | 0 | 0.0024 | 30.00 | 9.44 | 27 |
| Demand burst | Full system | 0 | 0.0024 | 30.00 | 9.44 | 27 |
| Zone B fault | Reactive | 2 | 0.0077 | 137.75 | 10.68 | 9 |
| Zone B fault | Forecast-only | 2 | 0.0077 | 137.75 | 10.68 | 9 |
| Zone B fault | Full system | 1 | 0.0058 | 105.00 | 8.92 | 10 |

These numbers only demonstrate that the current policy wiring changes simulated behavior. The full-system advantage in the fault case depends on the synthetic warning being available five minutes early. It is not evidence of real-world predictive accuracy.

### Stage 2 — Make the simulation a sound evaluation harness — In progress

- [x] Review and label the latency, error, capacity, and dropped-request calculations as simplified approximations.
- [x] Make latency and error SLO thresholds configurable.
- [x] Move simulation settings and scenarios into `experiment_config.json`.
- [x] Add burst-size, fault-severity, and 0/5/10-minute warning variants; run every policy on identical inputs.
- [x] Calculate dropped request counts from RPS over the configured measurement window and report request-weighted overall error rate.
- [x] Report latency and error SLO breach minutes, mean and p95 across minute-level modeled worst-zone latency, replica-minutes, mean replicas, and scaling changes.
- [x] Start each policy with the same two-replica-per-zone warm state to remove an artificial cold-start breach from steady-load comparisons.
- [x] Add a dependency-free SVG comparison chart for service impact and resource use.
- [ ] Calibrate the simulator's simplified latency/capacity relationship using multiple sample-service load levels.
- [x] Record limitations and avoid presenting synthetic scenarios as production evidence.

**Latest sensitivity sweep:** With a five-minute synthetic warning, full-system control had zero modeled SLO-breach minutes and zero dropped requests in the severe Zone B fault, compared with one breach minute and 1,965 dropped requests for reactive and forecast-only. With no early warning, all three policies had the same fault-period service outcome; the full-system policy still used fewer average replicas in that scenario. The moderate fault caused no SLO breach for any policy, so incident-aware routing did not improve the measured service outcome there. More warning than five minutes did not improve these particular metrics further. During both demand bursts, all policies met the configured SLOs; forecast-only used more average replicas and made more replica changes than reactive.

| Case | Policy | Minutes over either SLO | Dropped requests | Mean replicas | Replica changes |
|---|---|---:|---:|---:|---:|
| Severe fault, no warning | Reactive | 1 | 1,965 | 10.72 | 6 |
| Severe fault, no warning | Full system | 1 | 1,965 | 8.96 | 7 |
| Severe fault, 5-minute warning | Reactive | 1 | 1,965 | 10.72 | 6 |
| Severe fault, 5-minute warning | Full system | 0 | 0 | 8.96 | 7 |
| Severe burst | Reactive | 0 | 0 | 10.24 | 24 |
| Severe burst | Forecast-only | 0 | 0 | 11.20 | 42 |

These results show sensitivity to the assumed warning timing and fault severity. The injected risk score is a synthetic signal, so the result only demonstrates the benefit available when a warning is correct and early enough. It does not measure detector accuracy or establish an operational advantage.

### Stage 3 — Sample-service telemetry and forecasting — In progress

- [x] Implement a small local HTTP service with `/health`, `/work`, and Prometheus-format `/metrics` endpoints.
- [x] Expose request totals, 60-second rolling request rate, error fraction, request-level p95 latency, process CPU time/one-core percentage, and process maximum-RSS high-water mark.
- [x] Add an open-loop load generator with configurable RPS, duration, concurrency, CPU work, delay, and deterministic periodic HTTP failures.
- [x] Save request-level client measurements and periodic service-metric samples as separate CSVs.
- [x] Add phase-based profiles that vary offered load and start a controlled fault after a healthy lead-in.
- [x] Add controlled latency, CPU-pressure, and error-rate precursor profiles before the same sustained breach.
- [x] Resample request data into one-minute windows, derive lag/trend features only from prior windows, and document missing-data handling.
- [x] Label incidents using a sustained two-window SLO breach; positive labels require the current window to be healthy and the measured incident onset to be within two minutes.
- [x] Run baseline, load-ramp, and controlled-degradation profiles locally; inspect client and service measurements.
- [x] Choose provisional demonstration thresholds (p95 latency 300 ms; 5xx error rate 1%) that separate these initial baseline/degradation runs.
- [x] Run an independent repeat of the load-ramp and abrupt-fault profiles with a fresh service process per run.
- [x] Add a latency-precursor fault profile and collect one initial run.
- [x] Collect two additional fresh-process repeats for every defined fault profile; keep final SLO and label freezing open pending broader validation.
- [x] Give each run a dataset ID containing its path under `telemetry/`, so repeats from different timestamped batches cannot be merged accidentally.
- [x] For older runs without profile metadata, use the run folder name as the profile value rather than grouping unrelated runs as `unknown`.
- [x] Implement last-value, trailing-mean, and short linear-trend request-rate baselines with a causal one-step walk-forward diagnostic.
- [ ] Add a seasonal baseline and a statistical forecast such as Holt-Winters or SARIMA.
- [ ] Train only on historical windows; choose model settings on a validation period and reserve a chronological or run-level holdout for final evaluation.
- [ ] Report MAE, RMSE, sMAPE, and forecast-interval coverage, with forecast-versus-actual plots.
- [ ] Export predictions in a documented format so the simulator can consume them.

### Stage 4 — Incident-detection model — Prototype evaluated; not ready for automatic action

- [x] Define the prototype incident as two consecutive one-minute windows above p95 latency 300 ms or error rate 1%.
- [x] Collect initial healthy and fault-affected local telemetry, including an explicit sub-SLO latency-precursor profile.
- [x] Create current-window and prior-window features without using future observations.
- [x] Define a two-minute warning label that is positive only when the current window is healthy and a sustained incident starts within the next two windows.
- [x] Collect enough independent fault and precursor runs to perform an initial run-level holdout; more runs are still needed for a stable estimate.
- [x] Implement an interpretable one-feature threshold detector trained on the training runs and compare it with an always-no-warning baseline.
- [x] Add a deterministic grouped holdout that keeps runs intact and holds out one run per repeated profile.
- [x] Restrict detector candidates to latency, error-rate, and CPU telemetry; exclude request-rate shortcuts.
- [x] Add a leave-one-profile-out mode that excludes every run of a selected profile from training.
- [x] Select the decision threshold on run-grouped validation rows, then evaluate on a held-out run/profile.
- [x] Report precision/recall and inspect held-out false alarms, including a healthy high-CPU negative control.
- [ ] Keep cloud scheduler events as supplementary trace evidence unless they are demonstrably valid labels for the service incident being predicted.

### Stage 5 — Connect models to the controller and evaluate ablations — Offline prototype complete

- [x] Feed held-out detector outputs into a deterministic controller replay interface.
- [x] Preserve reactive, forecast-only, and forecast-plus-incident-awareness comparisons.
- [x] Run each policy against matching traces, assumed fault event timing, and initial state.
- [ ] Add multiple runs/scenarios and report service impact, resource use, recovery, and scaling churn together.
- [ ] Test sensitivity to forecast error, risk threshold, and warning lead time.

### Stage 6 — Zone-agent coordination and messaging — Planned

- [ ] Define zone-agent responsibilities and typed messages.
- [ ] Implement a deterministic Contract-Net flow: capacity request, eligible-zone bids, award, timeout, and rejection reasons.
- [ ] Add capacity, health, minimum-replica, and anti-thrashing constraints.
- [ ] Log requests, bids, awards, rejections, and actions for reproducibility.
- [ ] Add local messaging (for example, NATS) only after direct-call controller behavior is stable.

### Stage 7 — Local Kubernetes testbed — Manifests and guarded adapter prepared; runtime blocked

- [x] Package a small sample web service and define a local kind testbed.
- [x] Represent three logical zones with node labels and zone-specific deployments/services; these are labels in a local testbed, not real cloud zones.
- [ ] Collect request rate, p95 latency, errors, CPU, memory, restarts, and deployment events with local monitoring.
- [x] Add a narrow Kubernetes action adapter; it defaults to printing a plan and requires explicit `--apply` to mutate the demo namespace.
- [x] Validate proposals through the deterministic safety gate before exposing applied values.
- [ ] Confirm the same experiments can be reproduced from documented commands/configuration.

### Stage 8 — Optional local LLM diagnosis — Planned / optional

- [ ] Add only after the deterministic detector, controller, and safety gate work.
- [ ] Use a locally served model; do not call paid hosted APIs.
- [ ] Restrict the LLM to diagnosis and proposals from a fixed action vocabulary.
- [ ] Validate structured output and reject stale, unsafe, or infeasible proposals deterministically.
- [ ] Keep direct infrastructure execution outside the LLM.
- [ ] Check the selected model's license separately from the runtime license.

### Stage 9 — Final evaluation and project handoff — Planned

- [ ] Run the frozen experiment suite for all three policies.
- [ ] Produce forecasting, incident-detection, and policy-comparison figures/tables.
- [ ] Include safety outcomes and an audit trail of decisions.
- [ ] Document setup, software licenses, dataset terms, assumptions, limitations, and reproduction commands.
- [ ] Prepare the final report and demonstration using measured results, with synthetic simulator results clearly labeled.

## 2026-10-27 completion record

- Added `cpu_pressure_without_incident`, a matched healthy negative-control profile. Three repetitions generated 3,600 requests each with zero errors; measured sustained incident onset was absent. The combined dataset is now 158 minute windows across 26 runs with 38 positive warning labels.
- The grouped detector evaluator keeps runs intact across fit, validation, and test; its threshold is selected on validation data. Evaluation demonstrated a critical failure: when the healthy high-CPU profile was held out, the selected detector warned in 9 of 21 healthy windows (3 runs). In the error-only fault holdout it missed all 6 positive windows. On the CPU-fault holdout it found all six positives but also produced seven false alarms in 21 windows. The detector is therefore unsuitable for automatic infrastructure action.
- Added `replay_detector_control.py`, which joins held-out predictions to telemetry and replays the same rows through reactive, forecast-only, and full-system simulation. Current outputs are in `data/processed/detector_control_replays/`. The bridge maps measured request rate to virtual RPS with an explicit default multiplier of 24 and maps a binary warning to risk 0.9; these are assumptions, not calibrated values. A healthy CPU negative-control replay generated nine warning minutes and no modeled SLO breaches under these particular assumptions. This does not validate the detector or justify actuation.
- Added reusable safety checks in `safety.py`, the deterministic controller interface in `controller.py`, and the weighted local traffic router. The K8s adapter accepts operator-provided signals, prints its safety-checked plan by default, and only calls `kubectl` when `--apply` is explicitly supplied. No detector-to-cluster automatic loop is configured.
- Added local K8s manifests and a container image definition. Ruby's YAML parser successfully parsed all 10 documents in `k8s/demo.yaml`. A live `kind` cluster was not created: Colima/Lima VM startup failed with `operation not permitted` while reading the VM boot session ID in this host environment. `kubectl --dry-run=client` could not validate against an API schema without a reachable cluster. Thus manifests have syntax validation only; scheduling, probes, image loading, router behavior in-cluster, and guarded mutations remain unverified.
- Re-ran the deterministic simulator: all scenarios completed. Re-ran the local unit suite: 15 tests passed. Full three-policy simulator outputs were refreshed in `data/processed/safety-evaluation/`.
- Before Kubernetes execution, run the local testbed in an environment that permits virtualization, validate zone scheduling and service health, test the adapter first without `--apply`, then run controlled fault drills with explicit operator approval. Keep the detector disconnected from automatic mutations until it passes larger independent negative-control and unseen-fault evaluations.

## Current project files

- `run.py` — runs all scenarios/policies and writes the CSV outputs.
- `simulator.py` — scenarios, simulation loop, service approximations, and summary metrics.
- `policies.py` — deterministic reactive, forecast-only, and full-system allocation policies.
- `experiment_config.json` — simulation settings and workload/fault scenario matrix.
- `report.py` — standard-library SVG summary chart generator.
- `demo_service.py` — local HTTP sample application and Prometheus-format metrics endpoint.
- `load_generator.py` — open-loop workload driver, request log, and metrics scraper.
- `demo_workloads.json` — repeatable load-ramp, abrupt-fault, latency/CPU/error precursor, error-only fault, and severe latency-only fault phases.
- `experiment_runner.py` — isolated repeated-profile runner that restarts the service and rebuilds the dataset.
- `prepare_dataset.py` — minute-level feature extraction and sustained-incident label generation.
- `forecast_baselines.py` — causal one-minute persistence, moving-average, and trend baseline comparison.
- `evaluate_incident_detector.py` — deterministic run-grouped holdout for a trained one-feature incident-warning rule.
- `telemetry/healthy-baseline/` — initial local baseline request log and service-metric samples.
- `telemetry/synthetic-degradation/` — initial controlled delay/error request log and service-metric samples.
- `telemetry/load-ramp-recovery/` — 5-to-20 RPS ramp and recovery run.
- `telemetry/rising-load-fault/` — healthy lead-in followed by a controlled latency/error fault.
- `telemetry/repeated/` — independent ramp and fault profile repeats, each with a fresh service process.
- `telemetry/precursor-fault-2026-10-26/` — rising but sub-SLO latency before the injected fault.
- `telemetry/repeated/precursor-variants/` — isolated CPU-pressure and error-rate precursor runs.
- `telemetry/repeated/shape-variants/` — isolated error-only and severe latency-only fault runs.
- `data/processed/telemetry_windows.csv` — combined minute-level feature/label sample.
- `data/processed/forecast_baseline_summary.csv` — per-run and combined exploratory forecast scores.
- `results.csv` — per-minute output from the most recent run.
- `summary.csv` — per-scenario comparison from the most recent run.
- `summary_chart.svg` — visual comparison of SLO impact and average replica use.
- `IMPLEMENTATION_NOTES.md` — staged roadmap and progress log.
- `README.md` — quick-start instructions and key prototype assumptions.

## Progress log

### 2026-10-26 — Initial simulator prototype

- Created a standard-library Python simulator and the three initial policy variants.
- Replaced the original single scenario with normal-load, burst, and zone-fault scenarios.
- Added a one-minute control delay so the policies act on their observations in the next simulated minute.
- Added a five-minute trend forecast and a synthetic early-warning risk signal for the full-system policy.
- Added `summary.csv` alongside the minute-level `results.csv`.
- Found and corrected a forecast baseline issue: a steep downward trend forecast below-current demand caused premature scale-in during burst recovery. The current baseline does not forecast below current observed demand.
- That first run showed the synthetic incident warning reducing modeled fault SLO-violation duration from two minutes to one; forecast-only used more average replicas and incurred more replica changes during the burst without reducing SLO violations.
- Limitation: scenario and detector signals are hand-authored, and the service equations are illustrative. Next work should validate/calibrate the evaluation harness before drawing research conclusions.

### 2026-10-26 — Evaluation harness and sensitivity sweep

- Moved simulation settings and scenario definitions into `experiment_config.json`, so workload and fault parameters can be adjusted without editing Python code.
- Added moderate/severe burst cases; Zone B faults with no, five, and ten minutes of synthetic warning; and a moderate-severity fault.
- Added configurable error SLO, request-volume-aware dropped-request counts, request-weighted overall error rate, worst-zone latency summaries, replica-minutes, and separate latency/error breach counts.
- Changed the initial state to two replicas per zone for every policy. The prior one-replica cold start caused an artificial SLO violation even in normal load; the shared warm state removes that startup artifact from steady-load comparisons.
- Re-ran all policy/scenario pairs. A five-minute synthetic warning eliminated the modeled severe-fault breach in this setup; without early warning, all policies had the same service breach. More lead time than five minutes did not further change the outcome, while the moderate fault did not cause an SLO breach for any policy.
- Burst scenarios met both configured SLOs, while forecast-only used more replicas and changed replica counts more often than reactive. This is a resource-efficiency trade-off, not an availability gain.
- Remaining Stage 2 work: calibrate the service model and SLOs using telemetry from the sample application before treating results as research evidence.

### 2026-10-26 — Sensitivity chart and run interface

- Added `summary_chart.svg`, generated without third-party packages, to compare minutes over either SLO and mean active replicas across scenarios.
- Added an optional `--config` and `--output-dir` interface to `run.py`; default output files remain in the project folder.
- Improved metric definitions: dropped requests now multiply the modeled dropped RPS by the 60-second window, overall error rate is weighted by request volume, and the summary separates latency and error SLO breaches.
- Made the common initial state two replicas per zone. This removed the cold-start drops that had appeared in every scenario and made the scenario results easier to interpret.
- The latest run has seven scenario variants and 21 policy/scenario rows. It is generated by `python3 run.py`; no third-party packages are required.
- Stage 2 remains open until the simplified service equations are calibrated across multiple load levels. The first sample run supports only provisional SLO thresholds.

### 2026-10-26 — Local sample service and telemetry collection

- Added `demo_service.py`, a standard-library HTTP service bound to loopback by default. It serves `/health`, `/work`, and Prometheus-format `/metrics`.
- Added rolling request rate, request-level p95 latency, 5xx error fraction and counters, process CPU time, an approximate one-core CPU percentage, and maximum-RSS memory high-water mark.
- Added `load_generator.py` for paced local traffic, client-side request logs, and periodic scraping of service metrics. Configurable CPU work, latency, and every-Nth-request errors support controlled local experiments.
- Added VS Code terminal instructions to `README.md`. No paid service, cloud account, or third-party Python package is required.
- Ran the service locally on loopback for a 60-second baseline (10 target RPS, 2 ms CPU work/request): 600 requests, 0 errors, 10.01 completed RPS, client p95 5.10 ms. The final service scrape reported rolling p95 2.14 ms, CPU 3.50% of one core, and 17,055,744-byte maximum-RSS high-water mark.
- Ran a 60-second controlled degradation (10 target RPS, 350 ms delay/request, 2 ms CPU work/request, HTTP 500 every 20th request): 600 requests, 30 errors (5%), 9.95 completed RPS, client p95 360.53 ms. The final service scrape reported rolling p95 357.23 ms, 4.86% rolling errors, CPU 3.74% of one core, and 17,317,888-byte maximum-RSS high-water mark.
- Set provisional demo thresholds at p95 latency 300 ms and 5xx rate 1%. They distinguish these two initial controlled runs, but need repeated healthy trials and other fault types before final use.
- Raw request-level and service-scrape files are saved under `telemetry/healthy-baseline/` and `telemetry/synthetic-degradation/`. Samples were collected every ten seconds; a longer set of runs is still needed for reliable model training and run-level train/test splits.
- Stopped the local service after collection. The service binds to `127.0.0.1` by default and uses no external service or third-party package.

### 2026-10-26 — Phase-based telemetry and first labeled windows

- Added `demo_workloads.json` with a five-minute 5→10→20→10→5 RPS load ramp and a five-minute profile with healthy lead-in, increased load, then a sustained controlled fault.
- Extended `load_generator.py` to run phase profiles, save each run's phase/fault timing metadata, record request-level response data, and scrape service metrics every ten seconds.
- Added `prepare_dataset.py` to aggregate client request logs into one-minute windows, attach CPU/RSS samples, compute past-window lags/slopes, and produce `incident_within_2m` labels. The label uses measured SLO breaches sustained across two consecutive windows and requires the current window to be healthy.
- Collected the ramp profile: 3,000 requests over five minutes, no errors, and 7.33 ms client p95. Collected the rising-load/fault profile: 2,400 requests over five minutes, 60 injected errors in the 10 RPS fault phase, and 360.31 ms client p95.
- Prepared `data/processed/telemetry_windows.csv`: 12 one-minute windows across four runs, with two positive early-warning labels immediately before the sustained fault onset at minute 3 of the incident profile.
- Added `experiment_runner.py` to restart the service between profiles, avoiding rolling-metric carryover, and rebuild the combined dataset. Repeated one ramp trial and one fault trial in separate fresh service processes.
- The repeated ramp trial recorded 3,000 requests, zero errors, and 7.10 ms client p95. The repeated fault trial recorded 2,400 requests, 60 injected errors, and 360.28 ms client p95.
- The updated dataset contains 22 one-minute windows across six runs and four positive early-warning labels (two per fault-profile run). The extra rows remain highly correlated within runs; four positives across two fault runs cannot support a valid training/holdout evaluation.
- This remains a pipeline/data-collection demonstration. Collect many more independent runs and additional fault variations before model training.
- The service was stopped after collection. The workload controls are synthetic; the request/latency/CPU readings are local measurements from this demo app, not general cloud-service evidence.

### 2026-10-26 — Precursor profile for incident-warning features

- Added `latency_precursor_then_fault`: healthy baseline, rising load, a minute at 80 ms added latency, a minute at 200 ms added latency, then a sustained 350 ms delay and 5% HTTP-error phase. The precursor windows remain below the provisional 300 ms latency SLO.
- Collected the seven-minute profile locally: 3,600 requests, 60 errors in the two-minute fault phase, and 360.16 ms client p95 across the full run.
- The measured incident onset was minute 5 after two consecutive SLO-breaching windows. The two healthy precursor windows at minutes 3 and 4 received positive `incident_within_2m` labels; their measured p95 values were 91.29 ms and 213.50 ms.
- Rebuilt the dataset: 29 one-minute windows across seven runs, with six positive labels across three incident runs. The prior abrupt-fault runs have no leading latency signal; this new profile intentionally provides one for feature-pipeline exploration.
- These are hand-designed precursors and only one precursor run. They demonstrate that the causal features and labels line up; they do not establish general incident predictability. More independent runs, varied precursor shapes, and fault types are required before training or making performance claims.

### 2026-10-26 — First walk-forward forecast baselines

- Added `forecast_baselines.py` to compare one-minute last-value, trailing-mean, and three-window linear-trend forecasts using only prior request-rate windows within each run.
- Evaluated 22 one-step predictions from the current scripted traces: last-value MAE 3.4091 RPS / RMSE 5.1124 RPS / sMAPE 33.33%; trailing mean MAE 3.8636 / RMSE 5.3241 / sMAPE 41.01%; short trend MAE 4.3182 / RMSE 6.3066 / sMAPE 38.35%.
- Last-value performed best on these short stepwise profiles, which hold a few fixed rates for one minute at a time. This is a descriptive walk-forward diagnostic on scenario-designed traces, not a held-out evaluation and not evidence about future real traffic.
- Output is `data/processed/forecast_baseline_summary.csv`. The dataset remains too small for model training or generalization claims; the next data work is collecting more independent workload and precursor variants before adding a trained detector or a richer forecaster.

### 2026-10-26 — CPU and error-rate precursor variants

- Added and collected a CPU-pressure profile and an error-rate-rise profile, each with a separate fresh service process and a final sustained fault.
- In the CPU profile, process CPU rose to about 22% then 71% of one core while p95 latency was about 27 ms then 81 ms, both below the 300 ms SLO. The next two windows were labeled positive before the sustained fault.
- In the error profile, the healthy lead-in measured 0.67% then exactly 1.00% errors (the rule breaches only above 1%); the next two windows were at 5% and started the sustained incident. The preceding windows received the two positive labels.
- The combined dataset now has 43 one-minute rows across nine runs, with ten positive labels across five fault runs. It includes abrupt faults plus latency, CPU, and error-rate precursor patterns.
- Re-ran the walk-forward request-rate baselines on 34 one-step predictions: last-value MAE 2.50 RPS / RMSE 4.2875 / sMAPE 25.49%; trailing mean MAE 3.0882 / RMSE 4.5419 / sMAPE 33.88%; short trend MAE 3.3824 / RMSE 5.2859 / sMAPE 31.35%.
- These figures remain diagnostic on scripted profiles. Forty-three windows and ten positives from five fault runs are not enough for a meaningful run-level train/test split or for claims that a detector generalizes.

### 2026-10-26 — Additional fault-shape coverage

- Added and collected two more seven-minute workload profiles: an error-rate precursor followed by an error-only fault, and a latency precursor followed by a severe latency-only fault. Each profile ran with a fresh local service process.
- The error-only run produced 40 errors and 5.20 ms overall client p95; the sustained incident was detected by the configured error-rate SLO at minute 5. The severe latency-only run produced no errors and 510.01 ms overall client p95; its latency SLO incident began at minute 5. In each run, the two healthy windows immediately before onset (minutes 3 and 4) received positive two-minute warning labels.
- The combined dataset then contained 57 one-minute windows across 11 runs, with 14 positive labels across seven fault runs. It included latency-, CPU-, and error-rate precursors, abrupt faults, an error-only fault, and a severe latency-only fault.
- Re-ran the walk-forward request-rate diagnostics on 46 one-step predictions: last-value MAE 2.0652 RPS / RMSE 3.8307 / sMAPE 21.74%; trailing mean MAE 2.7174 / RMSE 4.1156 / sMAPE 30.47%; short trend MAE 2.9348 / RMSE 4.7204 / sMAPE 28.01%. These are comparisons on the same scripted profiles used to construct the data, not held-out forecasts.
- The new fault modes improved coverage of the label and telemetry pipeline but did not establish detector accuracy. The sample was still small, highly structured, and collected from one local demo service.

### 2026-10-26 — Run-level pilot collection and evaluation setup

- Corrected dataset run identity to use the full path relative to `telemetry/`, and added the workload profile name to every minute row. This prevents same-named repeats in different timestamped batches from being merged during forecasting or model evaluation.
- Added `evaluate_incident_detector.py`. It deterministically holds out the lexicographically last run for each profile with at least two runs, fits a one-feature threshold using training rows only, and compares held-out results with an always-no-warning baseline. The output includes the run split, selected threshold, test metrics, and per-window predictions.
- Collected two fresh-process repeats for each of the six fault profiles (12 runs total) on loopback port 8011 under `telemetry/repeated/run-level-pilot-20261026/`. The fault signatures repeated as intended: error-only trials had 40 errors and 5.17–5.23 ms client p95; latency-only trials had no errors and 509.89–510.09 ms client p95; the mixed latency/error faults had 60 or 70 errors and about 360 ms client p95.
- Rebuilt the combined dataset: 137 one-minute windows across 23 runs, including 38 positive two-minute warning labels. Full relative run paths and profile names are included in the dataset so repeats stay grouped correctly.
- Added an exploratory grouped holdout: 16 training runs and 7 held-out runs, with 26 and 12 positive windows respectively. It held out one full run for each profile with repeats; no windows from a test run were used to fit the detector. Legacy runs without profile metadata are kept as distinct profiles.
- A one-feature threshold selected on training runs (`request_rate_mean_prev_3 < 9.1667 RPS`) caught all 12 held-out positive windows but also raised 14 false warnings (precision 46.15%, F1 0.6316). Two false warnings occurred during the held-out healthy load ramp. The always-no-warning baseline had 73.33% accuracy versus 68.89% for the detector, illustrating why accuracy and recall alone can be misleading.
- Re-ran the descriptive request-rate forecast diagnostic on 114 one-step predictions: last-value MAE 1.3596 RPS / RMSE 2.9245 / sMAPE 15.79%; trailing mean MAE 2.1491 / RMSE 3.3058 / sMAPE 25.44%; short trend MAE 2.2368 / RMSE 3.5970 / sMAPE 23.00%. This remains a diagnostic on scripted traces, not a held-out forecast test.
- This holdout measures repeatability on the same scripted profile shapes. The selected feature appears tied to the low-rate lead-in in these scripts; it is not evidence of a general incident signal. Next, improve the detector features and false-alarm behavior, then evaluate with additional independent runs and fault shapes absent from training.

### 2026-10-26 — Incident signals and unseen-profile evaluation

- Removed request-rate predictors from incident detection after the first run-level evaluation selected a low historical request rate as a shortcut. Candidate warning signals now use only latency, latency trend, error rate, and CPU telemetry; the selected signal must increase with risk.
- Changed threshold selection to maximize training F0.5, which weights precision more heavily than recall to reduce false warnings. The fitted detector remains an interpretable single-feature threshold and uses training rows only.
- Added `--holdout-profile` to exclude every run from a selected workload profile. Ran `python3 evaluate_incident_detector.py --holdout-profile cpu_pressure_then_fault`; all three CPU-pressure runs were withheld from training (20 training runs, 3 test runs, 32 training positives, 6 test positives).
- On the unseen CPU-pressure profile, the fitted rule was `process_cpu_percent_1_core_mean > 4.2767%` of one core. It caught all 6 positive windows, with 3 false warnings across 21 test windows (precision 66.67%, recall 100%, F1 0.80, accuracy 85.71%). The always-no-warning baseline had 71.43% accuracy and zero recall.
- Re-ran the run-level holdout with the refined signal set: it caught 6 of 12 positives and raised 3 false warnings (precision 66.67%, recall 50%, F1 0.5714, accuracy 80%). The earlier demand-rate shortcut caught more positives but produced 14 false warnings; the refined rule is a better false-alarm trade-off on this small sample.
- Tested two more leave-one-profile-out cases. The error-only profile selected CPU >4.2767% and made no warnings, missing all 6 positives. The severe-latency-only profile selected CPU >4.3797%, caught 5 of 6 positives, and made no false warnings. Reports and predictions are under `data/processed/incident_evaluation_profile_error_precursor_then_error_only_fault/` and `data/processed/incident_evaluation_profile_latency_precursor_then_severe_latency_fault/`.
- CPU utilization was selected in all three profile-holdout models, including the error-only and severe-latency-only tests. Treat it as a possible correlated proxy in these scripted traces, not as a validated causal precursor. Results differ by profile, so detector performance does not transfer uniformly.
- The profile holdout shows transfer to this scripted CPU precursor pattern, while the fault endpoint remains the same controlled service incident. Three held-out runs are not enough to establish reliable performance; add independent precursor patterns and hold out complete fault mechanisms in future evaluation.


### 2026-10-27 — Architecture implementation and verification

- Added a seasonal-naive/Holt-Winters/SARIMA forecast model comparison and a FastAPI inference service. The small scripted holdout is not representative; SARIMA's near-zero test error on near-constant traces is a warning about data suitability rather than proof of forecasting skill.
- Added run-grouped LightGBM/logistic incident models and a CUSUM comparator. On the held-out runs, LightGBM selected a conservative threshold (precision 1.0, recall 0.25); logistic regression found more positives (precision 0.625, recall 0.833) but raised false alarms (FPR 0.214). The data has only 26 scripted runs, so neither result supports automatic mitigation.
- Implemented typed NATS request/bid/award/confirm messages, three zone agents, deterministic scoring and a live award recheck. A local NATS test excluded an unhealthy high-risk provider, selected a feasible provider and received its confirmation.
- Implemented a local Ollama diagnosis agent that only runs after a deterministic incident flag, emits a constrained proposal and passes it through the deterministic safety gate. Downloaded Qwen3 0.6B locally, but inference failed with Metal buffer/command-queue allocation errors on this host. The service and cluster manifests are present; LLM inference is not verified.
- Implemented sensor runtimes, NATS-to-plan proposal bridge, a Kopf operator, CRD/RBAC, monitoring dashboards, and Chaos Mesh examples. The bridge emits unapproved plans; the operator requires explicit approval and rechecks current state. Kubernetes documents and dashboard JSON parse successfully, but no kind cluster could be started because host VM startup was denied.
- Added a streaming Google Cluster Data task-event converter with attribution metadata and tests. No public dataset was downloaded or replayed. Scheduler task events are kept separate from application incident labels.
- CloudSim Plus and AIOpsLab are not yet integrated. They remain methodology gaps alongside public-trace replay and live Kubernetes acceptance checks.
- Final verification on this host: 28 unit tests pass; Python sources compile; every YAML file under `k8s/` parses and embedded Grafana JSON parses; simulator scenarios rerun successfully. The test command used the temporary Python environment at `/private/tmp/rebalancer-venv`, not a committed virtual environment.

### 2026-10-27 — AIOpsLab integration added

- Implemented `integrations/aiopslab/agent.py`, an adapter for AIOpsLab's asynchronous `get_action(state)` agent interface. It uses the local Ollama chat API and keeps only task telemetry-read APIs plus `submit` in its allowlist. It parses a single API call as Python AST and accepts literal arguments only; shell commands and mutation actions are rejected.
- Implemented `integrations/aiopslab/run_detection.py` to execute the local model on AIOpsLab's Astronomy Shop high-CPU detection case and no-op negative control, then save task results and framework overhead.
- Added setup, provenance/limits, and run instructions in `integrations/aiopslab/README.md`. Unit tests cover API allowlisting, AST/literal validation, and rejection of shell/mutation calls; all four passed.
- This is an AIOpsLab benchmark integration, not a claim that its telemetry validates the project's LightGBM detector: the available task metrics and training features have not been calibrated to match. The harness execution remains blocked on this host because Python 3.11, Helm, Docker/kind, and working Ollama inference are unavailable. No AIOpsLab cluster or benchmark run is claimed.

### 2026-10-27 — Remaining evaluation support added

- Added descriptive SLO calibration that separates known no-fault runs, injected-fault windows, and legacy runs with unknown fault metadata. For the six known clean runs, maximum run-level p95 latency had median 7.6 ms and max 80.7 ms; errors stayed at 0. The old `synthetic-degradation` run has no onset metadata and is marked unknown rather than mislabeled as a clean control. These values are from a small synthetic sample and do not freeze a production SLO.
- Added a CPU-only LightGBM detector, trained on the same run-grouped split and reported separately. On its small test set it had precision 0.80, recall 0.33, and FPR 0.036. Added `/incident-risk-cpu` to the model service and packaged the artifact. This provides a controlled feature mapping for AIOpsLab's CPU-only container export; it still cannot detect error-only/latency-only issues and has not been evaluated on AIOpsLab itself.
- Extended the AIOpsLab runner with `--agent cpu-detector`. Its mapper filters the target service CPU series, aggregates minute windows, converts Prometheus CPU-core rates into percent-of-one-core, and sends the series to the CPU-only model. Tests verify conversion, target filtering, absent-series rejection, and path discovery. The AIOpsLab positive/no-op runs are still blocked by local Python/Helm/Docker/kind/Ollama prerequisites.
- Added `cloudsim_trace_export.py` and a pinned CloudSim Plus 8.5.7 Maven project that replays coarsened Google task-event rows as Cloudlets with explicit assumptions. Added conversion tests and build/run instructions. Maven is absent and shell DNS is unavailable, so the Java source is not compiled and no public trace has been processed. This is a replay baseline, not a three-policy CloudSim controller comparison.
- Added a Kubernetes acceptance script and Kustomize entry point. Corrected the rollout deployment names to match the manifests. Kubernetes still cannot be launched on this host, so syntax and script structure are not substitutes for a live run.
- Added a generator for an interim final evaluation report from existing artifacts. It labels live cluster, AIOpsLab, public-trace, and CloudSim acceptance as incomplete rather than filling gaps with simulated claims.

### 2026-10-27 — Runtime setup and public-trace replay

- Installed Docker Desktop 4.97.0 under `/Applications/Docker.app` after verifying the official DMG checksum and app signature. Started the Docker engine and created the four-node `rebalancer-local` kind cluster (Kubernetes 1.37.0). The core rebalancer deployments are Ready.
- Fixed the Ollama Kubernetes init container: `ollama pull` now runs while a temporary Ollama server is started. A generation request succeeded from both the Mac Ollama server and the Kubernetes Ollama service; in-cluster CPU inference was slow under image-pull load, so the AIOpsLab runner uses the Mac server.
- Installed AIOpsLab's OpenEBS and Prometheus dependencies and deployed the Astronomy Shop chart. Its first rollout exceeded the upstream five-minute readiness timeout while downloading images. The adapter now allows 30 minutes and manages the Prometheus host port-forward automatically. No benchmark result was produced yet.
- Paused the AIOpsLab rollout at the user's request by scaling its Astronomy Shop deployments and StatefulSet to zero replicas. The chart, namespace, images already cached on kind nodes, and the rebalancer cluster remain available to resume. No AIOpsLab high-CPU or no-fault outcome is claimed.
- Downloaded one official Google ClusterData 2011-2 task-events shard under CC-BY 4.0, recorded its source and SHA-256, processed 450,146 events into 109,434 machine-minute rows, and exported 64,868 workload rows. CloudSim Plus 8.5.7 replayed a deterministic 1,000-row sample spanning minutes 0–93; all 1,000 Cloudlets completed successfully. This is a bounded workload replay, not a three-policy comparison.
- Updated the CloudSim model to suppress per-event simulator logs and to retain memory request data without claiming to simulate RAM/bandwidth. The exact trace subset and CloudSim output are under `data/processed/google_trace/`.
- Remaining: resume the AIOpsLab stack, run LLM and CPU-only no-fault/high-CPU tasks, complete Kubernetes approval/recovery and controlled-fault acceptance, calibrate against repeated live service measurements, and refresh the final report with those results. The task is currently paused.

### 2026-10-27 — AIOpsLab transfer and live Kubernetes acceptance

- Diagnosed the earlier AIOpsLab `ActionRejected` status as a stale result from a different runner version; the current AIOpsLab action parser accepts the read-only `get_metrics` and `submit` calls. The current runner now persists session traces under the project, summarizes CPU locally instead of echoing the complete CSV, serializes framework enums, and avoids forcing `read_metrics` to print the entire counter CSV into the session.
- Corrected adapter checks to require the actual AIOpsLab detection APIs and to test cumulative CPU-counter conversion. All 8 AIOpsLab adapter checks pass.
- Ran the LLM on AIOpsLab's Astronomy Shop high-CPU case and no-fault control. AIOpsLab scored both submissions Correct (Yes / No; TTD 12.58 s / 9.14 s). CPU telemetry peaked at 6.89% of one core in the LLM high-CPU run and was 0% in the control. This was one run per case, not a reliability estimate. High-CPU run JSON: `data/processed/aiopslab/high_cpu_llm_results.json`; control: `data/processed/aiopslab/no_fault_llm_results.json`.
- Ran the CPU-only LightGBM transfer agent on both AIOpsLab cases. It missed the injected high-CPU label: maximum CPU was 10.60% of one core and maximum risk was 0.593 against a 0.690 threshold. It correctly returned No for the control (maximum CPU 2.41%, no warnings). This identifies a transfer/signal-calibration gap; it does not validate detector recall. Results are in `data/processed/aiopslab/high_cpu_cpu_detector_results.json` and `no_fault_cpu_detector_results.json`.
- Fixed Kubernetes operator RBAC after a live plan remained inert but Kopf could not patch status or discover cluster resources. Added a narrowly scoped discovery ClusterRole for namespaces, CRDs, and events; added patch/update on namespaced RebalancePlans. The operator then recorded `AwaitingApproval`, applied a reviewed one-replica scale-out with bounded routing weights, restored the original `[1,1,1]` replica count and balanced weights, and rejected a malformed-share plan without changing live state.
- Completed live Kubernetes checks: all four kind nodes and core deployments Ready; model health, forecast, full detector risk, and CPU-only risk endpoints returned valid responses; in-cluster `qwen3:0.6b` generated `OK`; Prometheus reported 9/9 active targets up; Grafana 12.1.0 health passed and its provisioned dashboard was found. Summary evidence: `data/processed/k8s_acceptance_results.json`.
- A clean Docker image build was attempted. Buildx permissions were resolved, but remote Debian package metadata took about eight minutes and the Python package download later timed out. The Dockerfile now uses a longer pip timeout. Kubernetes acceptance completed using the existing `incident-aware-rebalancer:local` image; a clean image rebuild remains unverified.
- A full 64,868-row CloudSim replay attempt did not produce output within the available run window and was stopped. The verified 1,000-row sample remains the only CloudSim success; no three-policy CloudSim comparison is claimed.
- Refreshed `data/processed/final_evaluation_report.md`, `ARCHITECTURE_STATUS.md`, and `README.md`. Remaining research work: repeated independent AIOpsLab trials and better fault/CPU signal alignment, repeated live-service SLO calibration, a three-policy CloudSim comparison, clean Docker rebuild verification, and optional Chaos Mesh controlled-fault execution. Automatic actuation remains inappropriate for the current detector evidence.

### 2026-10-27 — Core project finalization pass

- Completed a no-cache ARM64 Docker build of `incident-aware-rebalancer:final` after granting Buildx access to its activity metadata. Started the image and verified `/health` returned `status=ok` and `incident_model_loaded=true`. This confirms a fresh container build and startup; it is separate from the earlier live cluster acceptance.
- Clean-compiled the CloudSim Plus project with Maven and ran the same deterministic 1,000-row Google trace sample under three placement modes. Reactive completed 1,000/1,000 Cloudlets (mean execution 53.68 s; p95 287.58 s); forecast-only and full-system each completed 1,000/1,000 (mean 53.33 s; p95 278.90 s). The full-system high-load penalty did not activate, so those two runs matched. The comparison is deliberately scoped as a coarse placement experiment; it is not an incident-detection or production-savings result.
- Refreshed descriptive SLO calibration from the complete available local dataset: six known control runs, 19 fault-injected runs, and one run without reliable labels. The 300 ms p95 and 1% error thresholds remain provisional and are not externally validated.
- Reattempted CPU-only AIOpsLab transfer. Cluster selection was corrected to `rebalancer-local`, and the benchmark progressed through Prometheus and Astronomy Shop deployment. It did not reach a detector score: several dependent application init containers looped on Kafka readiness while the Kafka pod was Ready and Service port 9092 was exposed. The repeat was stopped and recorded in `data/processed/aiopslab/repeat_cpu_detector_attempt.json`; earlier scored results were preserved. Namespace deletion first timed out while Docker/kind stopped responding; test pods were force deleted, the namespace and temporary Prometheus release were removed, and Docker recovered. A final check confirmed all four kind nodes Ready and all project deployments 1/1 Ready.
- Ran the project Python suite: 30 tests passed. The CloudSim policy variants were compiled and exercised against all 1,000 rows. The final report now includes these results, fresh image evidence, updated SLO counts, and the AIOpsLab infrastructure limit.
- **Delivery status:** core prototype implementation and acceptance are finalized. Remaining items are scope/validity limits rather than missing core code: more independent service runs, a reliable AIOpsLab workload/fault mapping, externally approved SLOs, and a full 64,868-row CloudSim replay. Keep incident-driven actuation behind human approval; no production-readiness claim is made. Chaos Mesh remains an optional extension.

### 2026-10-27 — Evaluation expansion and final evidence reconciliation

- Added five repeated healthy-service calibration runs at 10 RPS. All five completed 600 requests with zero errors; client p95 latency ranged from about 4.45 to 4.89 ms. The expanded calibration dataset now has 11 known controls, 19 injected-fault runs, and one legacy run with unknown labels. The 300 ms p95 and 1% error thresholds remain provisional because these are scripted local measurements.
- Refit the CPU-only LightGBM model using the expanded 163-window, 31-run-group dataset. On its grouped test split, precision was 0.462, recall 1.000, and false-positive rate 0.304 (6 TP, 7 FP, 16 TN, 0 FN); this is not suitable for automatic control.
- Extended the AIOpsLab CPU mapper to record both per-minute mean CPU and peak counter interval while preserving the trained one-minute-mean feature contract. Offline rescoring of the saved high-CPU/control exports produced warnings in 2/4 and 0/5 windows respectively on the mean feature. Peak substitution raised warnings in 3/4 and 3/5 windows and remains diagnostic only. The repeat cluster attempt did not score: after cleaning a stale Helm release, Astronomy Shop init containers looped on Kafka readiness and the Kubernetes API timed out intermittently.
- Generated a deterministic, evenly spaced 5,000-row Google trace sample spanning minutes 0–93 and completed reactive, forecast-only, and full-system CloudSim Plus runs. Each completed 5,000/5,000 Cloudlets. Forecast-only and full-system matched because the risk penalty did not activate. The 64,868-row full replay and application-fault inference remain out of scope for the current evidence.
- Refreshed the final report and README to include the expanded data and trial outcomes. Activity Monitor showed 8.06 GB for the Docker VM and 4.46 GB swap, and Docker/kind calls stalled. I used Docker Desktop Restart; the engine recovered, all four kind nodes and all 17 project deployments returned Ready, and qwen3:0.6b inference responded again. Removed the failed astronomy-shop and temporary observe namespaces. This confirms current cluster recovery; the separate AIOpsLab retry still did not reach scoring.
- **Final status:** all planned core architecture components have implementation and prior local acceptance evidence. The project is a reproducible research prototype, not production-ready. Key remaining research limitations are AIOpsLab detector transfer/reliability, independent fault runs, external SLO approval, and a full-shard replay. Keep incident-driven actuation human-approved. Chaos Mesh experiments are optional.
