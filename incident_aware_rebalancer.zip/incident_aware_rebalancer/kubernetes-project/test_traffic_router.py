"""Checks deterministic weighted traffic selection and invalid-weight handling."""

import json
import tempfile
import unittest
from pathlib import Path

from traffic_router import WeightedRouter


class WeightedRouterTests(unittest.TestCase):
    def test_zero_weight_zone_never_receives_requests(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "weights.json"
            path.write_text(json.dumps({"zone-a": 1, "zone-b": 0, "zone-c": 0}))
            router = WeightedRouter(path)
            self.assertEqual({router.choose_zone() for _ in range(30)}, {"zone-a"})

    def test_smooth_weighted_round_robin_matches_configured_proportions(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "weights.json"
            path.write_text(json.dumps({"zone-a": 1, "zone-b": 2, "zone-c": 0}))
            router = WeightedRouter(path)
            counts = {zone: 0 for zone in ("zone-a", "zone-b", "zone-c")}
            for _ in range(90):
                counts[router.choose_zone()] += 1
            self.assertEqual(counts, {"zone-a": 30, "zone-b": 60, "zone-c": 0})

    def test_all_zero_weights_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "weights.json"
            path.write_text(json.dumps({"zone-a": 0, "zone-b": 0, "zone-c": 0}))
            router = WeightedRouter(path)
            with self.assertRaises(ValueError):
                router.choose_zone()


if __name__ == "__main__":
    unittest.main()
