"""Focused checks for the deterministic action safety gate."""

import math
import unittest

from policies import ZonePlan
from safety import guard_plan


class SafetyGateTests(unittest.TestCase):
    def setUp(self) -> None:
        self.current = ZonePlan((2, 2, 2), (1 / 3, 1 / 3, 1 / 3))
        self.capacity = (1.0, 1.0, 1.0)

    def test_valid_small_change_is_accepted(self) -> None:
        proposal = ZonePlan((3, 2, 1), (0.30, 0.40, 0.30))
        result = guard_plan(self.current, proposal, self.capacity, 1, 10)
        self.assertEqual(result.status, "accepted")
        self.assertEqual(result.plan.replicas, proposal.replicas)
        for actual, expected in zip(result.plan.traffic_shares, proposal.traffic_shares):
            self.assertAlmostEqual(actual, expected)

    def test_large_changes_are_rate_limited_and_shares_stay_normalized(self) -> None:
        proposal = ZonePlan((9, 1, 10), (0.98, 0.01, 0.01))
        result = guard_plan(self.current, proposal, self.capacity, 1, 10)
        self.assertEqual(result.status, "adjusted")
        self.assertEqual(result.plan.replicas, (4, 1, 4))
        self.assertAlmostEqual(sum(result.plan.traffic_shares), 1.0)
        for old, new in zip(self.current.traffic_shares, result.plan.traffic_shares):
            self.assertLessEqual(abs(new - old), 0.200001)
            self.assertGreaterEqual(new, 0.02)

    def test_unavailable_zone_is_drained(self) -> None:
        proposal = ZonePlan((3, 2, 3), (0.45, 0.10, 0.45))
        result = guard_plan(self.current, proposal, (1.0, 0.0, 1.0), 1, 10)
        self.assertEqual(result.status, "adjusted")
        self.assertEqual(result.plan.traffic_shares[1], 0.0)
        self.assertAlmostEqual(sum(result.plan.traffic_shares), 1.0)
        self.assertTrue(any("no capacity" in reason for reason in result.reasons))

    def test_high_risk_zone_can_be_drained_without_breaking_share_floor(self) -> None:
        proposal = ZonePlan((3, 2, 3), (0.475, 0.05, 0.475))
        result = guard_plan(self.current, proposal, self.capacity, 1, 10,
                            incident_risk=(0.0, 0.9, 0.0))
        self.assertEqual(result.status, "adjusted")
        self.assertLess(result.plan.traffic_shares[1], 0.1)
        self.assertGreaterEqual(result.plan.traffic_shares[1], 0.02)
        self.assertAlmostEqual(sum(result.plan.traffic_shares), 1.0)
        self.assertTrue(any("emergency traffic drain" in reason for reason in result.reasons))

    def test_invalid_shares_fail_closed(self) -> None:
        proposal = ZonePlan((3, 2, 3), (0.4, 0.4, 0.4))
        result = guard_plan(self.current, proposal, self.capacity, 1, 10)
        self.assertEqual(result.status, "rejected")
        self.assertEqual(result.plan, self.current)

    def test_non_finite_share_fails_closed(self) -> None:
        proposal = ZonePlan((3, 2, 3), (math.nan, 0.5, 0.5))
        result = guard_plan(self.current, proposal, self.capacity, 1, 10)
        self.assertEqual(result.status, "rejected")
        self.assertEqual(result.plan, self.current)

    def test_out_of_range_replica_count_fails_closed(self) -> None:
        proposal = ZonePlan((3, 0, 3), (0.3, 0.4, 0.3))
        result = guard_plan(self.current, proposal, self.capacity, 1, 10)
        self.assertEqual(result.status, "rejected")
        self.assertEqual(result.plan, self.current)


if __name__ == "__main__":
    unittest.main()
