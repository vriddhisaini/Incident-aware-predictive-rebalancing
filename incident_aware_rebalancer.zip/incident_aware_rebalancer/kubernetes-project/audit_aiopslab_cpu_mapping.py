"""Audit mean-versus-peak AIOpsLab CPU aggregation without refitting the model.

The deployed transfer model was trained on one-minute mean CPU. Peak-interval
scores here are diagnostic only: they deliberately expose the risk of feeding
the model a differently aggregated feature and are never used for decisions.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np

from integrations.aiopslab.metrics_adapter import cpu_minute_series


def audit(root: Path) -> dict[str, object]:
    model_path = root / "data/processed/incident_models/models/cpu_only_lightgbm.joblib"
    artifact = joblib.load(model_path)
    model = artifact["model"]
    threshold = float(artifact["threshold"])
    results = {}
    for case, result_name in (
        ("high_cpu", "high_cpu_cpu_detector_results.json"),
        ("no_fault", "no_fault_cpu_detector_results.json"),
    ):
        result = json.loads((root / "data/processed/aiopslab" / result_name).read_text(encoding="utf-8"))
        export = Path(result["results"][0]["agent_diagnostics"]["export_dir"])
        windows = cpu_minute_series(export, "ad")
        means = np.asarray([[row["process_cpu_percent_1_core_mean"]] for row in windows])
        peaks = np.asarray([[row["process_cpu_percent_1_core_max"]] for row in windows])
        mean_scores = model.predict_proba(means)[:, 1]
        peak_scores = model.predict_proba(peaks)[:, 1]
        results[case] = {
            "source_result": result_name,
            "windows": len(windows),
            "max_window_mean_cpu_percent_one_core": max(row["process_cpu_percent_1_core_mean"] for row in windows),
            "max_interval_cpu_percent_one_core": max(row["process_cpu_percent_1_core_max"] for row in windows),
            "counter_intervals_by_minute": [row["cpu_counter_intervals"] for row in windows],
            "mean_feature_warnings": int(np.sum(mean_scores >= threshold)),
            "peak_feature_counterfactual_warnings": int(np.sum(peak_scores >= threshold)),
        }
    return {
        "model_feature_contract": "one-minute mean container CPU percent of one core",
        "threshold": threshold,
        "results": results,
        "interpretation": "Peak substitution is out of contract and diagnostic only. In these saved cases it creates warnings in the no-fault control, so the model continues to receive minute means. More same-runtime labeled training data is required before using peak features.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, default=Path("data/processed/aiopslab/cpu_mapping_audit.json"))
    args = parser.parse_args()
    output = args.output if args.output.is_absolute() else args.root / args.output
    result = audit(args.root)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
