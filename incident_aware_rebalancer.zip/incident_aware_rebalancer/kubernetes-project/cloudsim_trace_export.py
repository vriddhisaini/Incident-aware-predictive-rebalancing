"""Export minute/machine aggregates as explicitly coarse CloudSim Plus workload rows."""
from __future__ import annotations
import argparse,csv,json
from pathlib import Path

def zone_for(machine_id:str)->str:
    return ("zone-a","zone-b","zone-c")[sum(machine_id.encode("utf-8"))%3]

def export_windows(input_path:Path,output_path:Path,mips_per_core:float=1000.0)->dict:
    if mips_per_core<=0: raise ValueError("mips_per_core must be positive")
    output_path.parent.mkdir(parents=True,exist_ok=True)
    count=0
    with input_path.open(newline="",encoding="utf-8") as src, output_path.open("w",newline="",encoding="utf-8") as dst:
        reader=csv.DictReader(src)
        required={"minute","machine_id","schedule_events","scheduled_cpu_cores_sum","scheduled_memory_sum"}
        if not required.issubset(reader.fieldnames or []): raise ValueError("missing Google trace aggregate columns")
        fields=["cloudlet_id","minute","machine_id","zone","schedule_events","cpu_cores_sum","memory_request_sum","cloudlet_length_mi","mips_per_core","seconds_per_row"]
        writer=csv.DictWriter(dst,fieldnames=fields);writer.writeheader()
        for row in reader:
            events=int(float(row.get("schedule_events") or 0)); cores=float(row.get("scheduled_cpu_cores_sum") or 0)
            if events<=0 or cores<=0: continue
            if not (cores<1e8): raise ValueError("implausible CPU request sum; inspect trace units before exporting")
            writer.writerow({"cloudlet_id":count,"minute":int(float(row["minute"])),"machine_id":row["machine_id"],
                             "zone":zone_for(row["machine_id"]),"schedule_events":events,"cpu_cores_sum":cores,
                             "memory_request_sum":float(row.get("scheduled_memory_sum") or 0),
                             "cloudlet_length_mi":max(1,round(cores*60*mips_per_core)),"mips_per_core":mips_per_core,"seconds_per_row":60})
            count+=1
    metadata={"source":str(input_path),"output":str(output_path),"cloudlet_rows":count,"zone_assignment":"stable machine-id byte-sum modulo three",
              "work_mapping":"one Cloudlet per machine-minute; length MI = summed normalized CPU request * 60 seconds * configured MIPS/core",
              "caveats":["this is a coarse replay adapter, not a validated cloud model", "Google CPU/memory request fields are normalized source units", "memory_request_sum is retained for analysis but not converted to RAM MiB", "scheduler event counts are not application RPS or incident labels", "MIPS-per-core and three logical zones are user-selected simulation assumptions"]}
    meta=output_path.with_suffix(output_path.suffix+".metadata.json");meta.write_text(json.dumps(metadata,indent=2),encoding="utf-8")
    return metadata

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("input",type=Path);p.add_argument("--output",type=Path,required=True);p.add_argument("--mips-per-core",type=float,default=1000);a=p.parse_args();print(json.dumps(export_windows(a.input,a.output,a.mips_per_core),indent=2))
if __name__=="__main__":main()
