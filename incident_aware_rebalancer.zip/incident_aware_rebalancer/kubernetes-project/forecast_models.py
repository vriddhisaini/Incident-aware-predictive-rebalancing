"""Train/evaluate transparent 5-minute request-rate forecasts per run.

Each run is split chronologically; only the earlier portion is fitted. This
within-run study tests short horizons on the current scripted telemetry and is
not a cross-provider or long-seasonality claim.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import warnings
from pathlib import Path

import numpy as np
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.statespace.sarimax import SARIMAX


def _read(path: Path) -> dict[str, list[dict[str, str]]]:
    groups: dict[str, list[dict[str, str]]] = {}
    with path.open(newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            groups.setdefault(row["run_id"], []).append(row)
    for rows in groups.values():
        rows.sort(key=lambda r: int(r["minute"]))
    return groups


def _score(actual: list[float], pred: list[float], lower: list[float], upper: list[float]) -> dict:
    err = [p - y for y, p in zip(actual, pred)]
    return {"n": len(actual), "mae_rps": sum(abs(e) for e in err) / len(err),
            "rmse_rps": math.sqrt(sum(e * e for e in err) / len(err)),
            "smape_pct": sum(0 if abs(y) + abs(p) == 0 else 200 * abs(p-y)/(abs(y)+abs(p)) for y, p in zip(actual, pred))/len(actual),
            "interval_95_coverage": sum(lo <= y <= hi for y, lo, hi in zip(actual, lower, upper))/len(actual)}


def evaluate(path: Path, output_dir: Path, horizon: int = 5) -> dict:
    if horizon < 1:
        raise ValueError("horizon must be positive")
    predictions: list[dict] = []
    skipped: dict[str, str] = {}
    groups = _read(path)
    for run_id, rows in groups.items():
        values = [float(row["request_rate_rps"]) for row in rows]
        split = int(len(values) * .70)
        if split < 4 or len(values) - split < 1:
            skipped[run_id] = "fewer than four training windows or no future window"
            continue
        train, actual = values[:split], values[split:split+horizon]
        if not actual:
            continue
        models: dict[str, tuple[list[float], list[float], list[float]]] = {}
        last = train[-1]
        resid_sd = float(np.std(np.diff(train), ddof=1)) if len(train) > 2 else 0.0
        seasonal_period = 3
        seasonal = [train[-seasonal_period + (i % seasonal_period)] for i in range(len(actual))] if len(train) >= seasonal_period else [last] * len(actual)
        models["seasonal_naive_p3"] = (seasonal, [p-1.96*resid_sd for p in seasonal], [p+1.96*resid_sd for p in seasonal])
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                hw = ExponentialSmoothing(train, trend="add", damped_trend=True, initialization_method="estimated").fit(optimized=True)
            p = np.maximum(0, hw.forecast(len(actual))).tolist()
            sd = max(float(np.std(hw.resid, ddof=1)) if len(hw.resid) > 2 else 0.0, .01)
            models["holt_winters"] = (p, [max(0, x-1.96*sd*math.sqrt(i+1)) for i,x in enumerate(p)], [x+1.96*sd*math.sqrt(i+1) for i,x in enumerate(p)])
        except Exception as exc:
            skipped[f"{run_id}:holt_winters"] = str(exc)
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                sar = SARIMAX(train, order=(1, 0, 0), trend="c", enforce_stationarity=False, enforce_invertibility=False).fit(disp=False, maxiter=100)
            forecast = sar.get_forecast(steps=len(actual))
            p = np.maximum(0, np.asarray(forecast.predicted_mean)).tolist()
            ci = np.maximum(0, np.asarray(forecast.conf_int()))
            models["sarima_1_0_0"] = (p, ci[:, 0].tolist(), ci[:, 1].tolist())
        except Exception as exc:
            skipped[f"{run_id}:sarima"] = str(exc)
        for model, (pred, lower, upper) in models.items():
            for offset, (y, p, lo, hi) in enumerate(zip(actual, pred, lower, upper)):
                predictions.append({"run_id": run_id, "profile_name": rows[0]["profile_name"], "model": model,
                                    "train_end_minute": int(rows[split-1]["minute"]),
                                    "target_minute": int(rows[split+offset]["minute"]), "horizon_step": offset+1,
                                    "actual_rps": y, "predicted_rps": p, "lower_95_rps": lo, "upper_95_rps": hi})
    if not predictions:
        raise ValueError("no runs were long enough to evaluate")
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "predictions.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(predictions[0])); writer.writeheader(); writer.writerows(predictions)
    summary = []
    for model in sorted({p["model"] for p in predictions}):
        rows = [p for p in predictions if p["model"] == model]
        m = _score([r["actual_rps"] for r in rows], [r["predicted_rps"] for r in rows], [r["lower_95_rps"] for r in rows], [r["upper_95_rps"] for r in rows])
        summary.append({"model": model, "runs": len({r["run_id"] for r in rows}), **m})
    report = {"method": "per-run chronological 70/30 split; fixed-origin forecast; maximum horizon is configurable",
              "horizon_minutes": horizon, "input_runs": len(groups), "evaluated_runs": len({p["run_id"] for p in predictions}),
              "skipped": skipped, "metrics": summary,
              "limitations": ["small, short, locally scripted runs", "no daily/weekly seasonality is identifiable", "not a public Google/Azure trace evaluation", "intervals use model intervals for SARIMA and residual-based approximations for other models"]}
    (output_dir / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def main() -> None:
    root = Path(__file__).resolve().parent
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input", type=Path, default=root / "data/processed/telemetry_windows.csv")
    p.add_argument("--output-dir", type=Path, default=root / "data/processed/forecast_models")
    p.add_argument("--horizon", type=int, default=5)
    args = p.parse_args()
    print(json.dumps(evaluate(args.input, args.output_dir, args.horizon), indent=2))


if __name__ == "__main__":
    main()
