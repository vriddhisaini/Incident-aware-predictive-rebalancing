"""Resample local run logs into causal 1-minute modeling rows."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from statistics import mean


LATENCY_SLO_MS = 300.0
ERROR_SLO = 0.01
WINDOW_SECONDS = 60.0
INCIDENT_HORIZON_MINUTES = 2


def _read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def _p95(values: list[float]) -> float | None:
    if not values:
        return None
    values.sort()
    return values[max(0, math.ceil(len(values) * 0.95) - 1)]


def prepare_run(run_dir: Path, run_id: str | None = None) -> tuple[list[dict[str, object]], int | None]:
    request_path = run_dir / "request_log.csv"
    if not request_path.exists():
        return [], None
    requests = _read_csv(request_path)
    samples = _read_csv(run_dir / "service_metrics.csv")
    metadata_path = run_dir / "run_metadata.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8")) if metadata_path.exists() else {}

    if not requests:
        return [], None
    start_epoch = float(metadata.get("start_epoch", min(float(r["scheduled_epoch"]) for r in requests)))
    inferred_duration = max(float(r["scheduled_offset_s"]) for r in requests) + 1e-6
    duration = float(metadata.get("planned_duration_seconds", inferred_duration))
    window_count = max(1, math.ceil(duration / WINDOW_SECONDS))
    grouped_requests: list[list[dict[str, str]]] = [[] for _ in range(window_count)]
    grouped_samples: list[list[dict[str, str]]] = [[] for _ in range(window_count)]

    for row in requests:
        minute = int(max(0.0, float(row["scheduled_epoch"]) - start_epoch) // WINDOW_SECONDS)
        if minute < window_count:
            grouped_requests[minute].append(row)
    for row in samples:
        if not row.get("sample_epoch"):
            continue
        minute = int(max(0.0, float(row["sample_epoch"]) - start_epoch) // WINDOW_SECONDS)
        if minute < window_count:
            grouped_samples[minute].append(row)

    raw_rows: list[dict[str, object]] = []
    for minute, group in enumerate(grouped_requests):
        window_seconds = min(WINDOW_SECONDS, max(0.0, duration - minute * WINDOW_SECONDS))
        latencies = [float(row["latency_ms"]) for row in group]
        errors = sum(int(row["status_code"]) >= 500 or int(row["status_code"]) == 0 for row in group)
        request_count = len(group)
        metric_group = grouped_samples[minute]
        cpu_values = [float(row["process_cpu_percent_1_core"]) for row in metric_group
                      if row.get("process_cpu_percent_1_core")]
        rss_values = [float(row["process_max_rss_bytes"]) for row in metric_group
                      if row.get("process_max_rss_bytes")]
        raw_rows.append({
            "run_id": run_id or run_dir.name,
            "profile_name": metadata.get("profile_name") or run_dir.name,
            "minute": minute,
            "window_start_epoch": start_epoch + minute * WINDOW_SECONDS,
            "window_seconds": window_seconds,
            "request_count": request_count,
            "request_rate_rps": request_count / window_seconds if window_seconds else 0.0,
            "p95_latency_ms": _p95(latencies),
            "error_rate": errors / request_count if request_count else None,
            "process_cpu_percent_1_core_mean": mean(cpu_values) if cpu_values else None,
            "process_max_rss_bytes": max(rss_values) if rss_values else None,
        })

    breached = [
        row["p95_latency_ms"] is not None
        and row["error_rate"] is not None
        and (float(row["p95_latency_ms"]) > LATENCY_SLO_MS or float(row["error_rate"]) > ERROR_SLO)
        for row in raw_rows
    ]
    incident_start = next(
        (i for i in range(len(breached) - 1) if breached[i] and breached[i + 1]),
        None,
    )
    injected_start = metadata.get("fault_start_offset_seconds")
    injected_minute = int(float(injected_start) // WINDOW_SECONDS) if injected_start is not None else None

    output: list[dict[str, object]] = []
    rates = [float(row["request_rate_rps"]) for row in raw_rows]
    latencies = [row["p95_latency_ms"] for row in raw_rows]
    error_rates = [row["error_rate"] for row in raw_rows]
    for i, row in enumerate(raw_rows):
        history_start = max(0, i - 3)
        past_rates = rates[history_start:i]
        past_latencies = [float(value) for value in latencies[history_start:i] if value is not None]
        past_errors = [float(value) for value in error_rates[history_start:i] if value is not None]
        current_has_data = int(row["request_count"]) > 0
        current_breach = breached[i]
        positive = bool(
            current_has_data
            and not current_breach
            and incident_start is not None
            and i < incident_start <= i + INCIDENT_HORIZON_MINUTES
        )
        output.append({
            **row,
            "request_rate_lag_1": rates[i - 1] if i >= 1 else None,
            "request_rate_mean_prev_3": mean(past_rates) if past_rates else None,
            "p95_latency_lag_1": latencies[i - 1] if i >= 1 else None,
            "p95_latency_slope_prev_3": (
                (past_latencies[-1] - past_latencies[0]) / max(1, len(past_latencies) - 1)
                if len(past_latencies) >= 2 else None
            ),
            "error_rate_lag_1": error_rates[i - 1] if i >= 1 else None,
            "error_rate_mean_prev_3": mean(past_errors) if past_errors else None,
            "current_window_over_slo": int(current_breach),
            "injected_fault_start_minute": injected_minute,
            "measured_incident_start_minute": incident_start,
            "incident_within_2m": int(positive),
            "label_requires_current_window_healthy": 1,
        })
    return output, incident_start


def main() -> None:
    parser = argparse.ArgumentParser(description="Prepare minute-level telemetry and incident labels")
    parser.add_argument("--input-dir", type=Path, default=Path("telemetry"))
    parser.add_argument("--output", type=Path, default=Path("data/processed/telemetry_windows.csv"))
    args = parser.parse_args()
    rows: list[dict[str, object]] = []
    runs: list[tuple[str, int, int | None]] = []
    input_root = args.input_dir.resolve()
    run_dirs = sorted(path.parent for path in input_root.rglob("request_log.csv"))
    for run_dir in run_dirs:
        run_id = run_dir.relative_to(input_root).as_posix()
        prepared, incident_start = prepare_run(run_dir, run_id)
        if prepared:
            rows.extend(prepared)
            runs.append((run_dir.name, len(prepared), incident_start))
    if not rows:
        parser.error(f"No request_log.csv runs found under {args.input_dir}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys())
    with args.output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    positives = sum(int(row["incident_within_2m"]) for row in rows)
    print(f"Prepared {len(rows)} one-minute rows from {len(runs)} runs; positive early-warning labels: {positives}")
    for name, count, onset in runs:
        print(f"{name}: {count} windows, measured sustained-incident onset={onset}")
    print(f"Dataset: {args.output}")
    print(f"Label: current minute is healthy and a two-consecutive-window SLO incident starts within the next {INCIDENT_HORIZON_MINUTES} minutes")


if __name__ == "__main__":
    main()
