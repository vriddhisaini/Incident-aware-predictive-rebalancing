# CloudSim Plus public-trace replay

This adapter converts Google ClusterData task-event records to a coarse, three-zone CloudSim Plus workload. It has been compiled with the project's Maven toolchain and run against a bounded sample from the official public trace.

## Source data and attribution

The source is Google ClusterData 2011-2, `task_events/part-00000-of-00500.csv.gz`, a 4,139,742-byte public shard downloaded from [Google's trace bucket](https://storage.googleapis.com/clusterdata-2011-2/task_events/part-00000-of-00500.csv.gz). Google's [dataset documentation](https://github.com/google/cluster-data/blob/master/ClusterData2011_2.md) describes the trace, its CC-BY 4.0 terms, and its 41 GB total compressed size. This project uses one shard, not the complete dataset. Its SHA-256, source URL, license, attribution, and row counts are recorded in `data/processed/google_trace/attribution.json`.

Reproduce the conversion and bounded replay from the project root:

```sh
source scripts/activate_local_toolchain.sh
python google_trace_ingest.py \
  data/raw/google_trace/clusterdata-2011-2-task-events-part-00000-of-00500.csv.gz \
  --output data/processed/google_trace/machine_minutes.csv \
  --metadata data/processed/google_trace/attribution.json
python cloudsim_trace_export.py \
  data/processed/google_trace/machine_minutes.csv \
  --output data/processed/google_trace/cloudsim_workload.csv \
  --mips-per-core 1000
```

The shard contained 450,146 task-event rows and produced 109,434 machine-minute rows, including 64,868 machine-minute rows with scheduled CPU work. The full exported workload remains in `data/processed/google_trace/cloudsim_workload.csv`. For a bounded simulation, a deterministic 1,000-row sample is evenly spaced across the source output and spans the shard's observed minute range (0–93); its sampling metadata is alongside the CSV.

Run the replay:

```sh
mvn -q -f cloudsim/pom.xml compile exec:java \
  -Dexec.mainClass=org.rebalancer.cloudsim.TraceReplay \
  -Dexec.args="$(pwd)/data/processed/google_trace/cloudsim_workload_sample_1000.csv $(pwd)/data/processed/google_trace/cloudsim_results.csv 1000 1000"
```

The completed baseline replay produced 1,000 `SUCCESS` Cloudlets in `data/processed/google_trace/cloudsim_results.csv`. The model maps each row's summed normalized CPU request to a Cloudlet length of `CPU request × 60 seconds × 1,000 MIPS/core`, assigns machines deterministically to three logical zones, and schedules work at the row's minute. RAM and bandwidth utilization are set to zero; memory requests are retained in the output but not simulated. These are simplifying assumptions, not calibrated cloud-resource measurements. Google scheduler events are not application requests or service-incident labels.

## Placement-policy comparison

The CloudSim Plus runner accepts an optional policy name after the row limit:

```sh
for policy in reactive forecast_only full_system; do
  .toolchain/bin/mvn -q -f cloudsim/pom.xml compile exec:java \
    -Dexec.mainClass=org.rebalancer.cloudsim.TraceReplay \
    -Dexec.args="$(pwd)/data/processed/google_trace/cloudsim_workload_sample_5000.csv $(pwd)/data/processed/google_trace/cloudsim_${policy}_results_5000.csv 1000 5000 ${policy}"
done
```

Create that deterministic sample from the full converted workload with:

```sh
python cloudsim_sample.py data/processed/google_trace/cloudsim_workload.csv \
  --output data/processed/google_trace/cloudsim_workload_sample_5000.csv --rows 5000
```

`reactive` retains each trace row's assigned zone. `forecast_only` routes each minute's rows to the least-loaded zone using the previous five minutes of zone CPU requests. `full_system` uses the same forecast and adds a penalty when predicted zone demand reaches the configured high-load proxy (6 requested cores). The Google trace has no incident labels, so this proxy is only a placement stress heuristic; it must not be described as incident detection. The recorded comparison uses deterministic 1,000-row and 5,000-row samples, each spanning the full minute range. All Cloudlets succeeded in both; the high-load penalty did not activate, so forecast-only and full-system outcomes matched.

CloudSim Plus is distributed under GPL-3.0-or-later. Review license compatibility before redistributing a combined binary.
