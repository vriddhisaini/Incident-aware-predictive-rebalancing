package org.rebalancer.cloudsim;

import ch.qos.logback.classic.Level;
import org.cloudsimplus.brokers.DatacenterBrokerSimple;
import org.cloudsimplus.cloudlets.Cloudlet;
import org.cloudsimplus.cloudlets.CloudletSimple;
import org.cloudsimplus.core.CloudSimPlus;
import org.cloudsimplus.datacenters.DatacenterSimple;
import org.cloudsimplus.hosts.HostSimple;
import org.cloudsimplus.resources.PeSimple;
import org.cloudsimplus.utilizationmodels.UtilizationModelDynamic;
import org.cloudsimplus.util.Log;
import org.cloudsimplus.vms.VmSimple;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Replays coarsened Google task-event workload rows as three logical-zone Cloudlets. */
public final class TraceReplay {
    private static final int ZONES = 3;
    private static final int CORES_PER_ZONE_VM = 8;
    private static final int MAX_CLOUDLETS_DEFAULT = 100_000;

    private TraceReplay() {}

    private record WorkRow(long id, long minute, String machine, String zone, double cpuCores,
                           double memoryMiB, long lengthMi) {}

    private static List<WorkRow> readRows(Path input, double mipsPerCore, int maxRows) throws IOException {
        List<WorkRow> rows = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(input)) {
            String headerLine = reader.readLine();
            if (headerLine == null) throw new IllegalArgumentException("empty workload CSV");
            String[] header = headerLine.split(",", -1);
            Map<String, Integer> index = new HashMap<>();
            for (int i=0;i<header.length;i++) index.put(header[i].trim(), i);
            for (String required : List.of("minute", "machine_id", "zone", "schedule_events", "cpu_cores_sum", "memory_request_sum", "cloudlet_length_mi")) {
                if (!index.containsKey(required)) throw new IllegalArgumentException("missing CSV column: " + required);
            }
            String line; long id=0;
            while ((line=reader.readLine())!=null) {
                String[] cells=line.split(",", -1);
                long eventCount=parseLong(cells,index.get("schedule_events"),0);
                double cores=parseDouble(cells,index.get("cpu_cores_sum"),0);
                if (eventCount<=0 || !Double.isFinite(cores) || cores<=0) continue;
                long minute=parseLong(cells,index.get("minute"),0);
                String machine=cells[index.get("machine_id")];
                double memory=parseDouble(cells,index.get("memory_request_sum"),0);
                String zone=cells[index.get("zone")];
                if (!List.of("zone-a","zone-b","zone-c").contains(zone)) throw new IllegalArgumentException("invalid zone in input CSV: "+zone);
                long length=parseLong(cells,index.get("cloudlet_length_mi"),0);
                if (length<=0) length=Math.max(1,Math.round(cores*60.0*mipsPerCore));
                rows.add(new WorkRow(id++,minute,machine,zone,cores,memory,length));
                if (rows.size()>maxRows) throw new IllegalArgumentException("trace exceeds --max-cloudlets="+maxRows+"; use the streaming converter to select a smaller date/range");
            }
        }
        if (rows.isEmpty()) throw new IllegalArgumentException("no scheduled CPU workload rows found");
        return rows;
    }

    private static long parseLong(String[] row, int i, long fallback) { try { return Long.parseLong(row[i]); } catch (Exception e) { return fallback; } }
    private static double parseDouble(String[] row, int i, double fallback) { try { return Double.parseDouble(row[i]); } catch (Exception e) { return fallback; } }

    private static int zoneIndex(String zone) { return zone.charAt(zone.length()-1)-'a'; }

    /**
     * Assign trace rows to the three CloudSim VMs. The source-zone policy is
     * the reactive baseline. The other policies use only prior-minute trace
     * demand; the full-system variant adds a transparent high-load risk proxy.
     */
    private static Map<Long, Integer> assignVms(List<WorkRow> rows, String policy) {
        if (!List.of("reactive", "forecast_only", "full_system").contains(policy)) {
            throw new IllegalArgumentException("policy must be reactive, forecast_only, or full_system");
        }
        Map<Long, double[]> minuteLoads = new HashMap<>();
        for (WorkRow row : rows) {
            minuteLoads.computeIfAbsent(row.minute(), ignored -> new double[ZONES])[zoneIndex(row.zone())] += row.cpuCores();
        }
        Map<Long, Integer> assignments = new HashMap<>();
        long activeMinute = Long.MIN_VALUE;
        double[] currentAssigned = new double[ZONES];
        List<WorkRow> ordered = new ArrayList<>(rows);
        ordered.sort(java.util.Comparator.comparingLong(WorkRow::minute).thenComparingLong(WorkRow::id));
        for (WorkRow row : ordered) {
            if (row.minute() != activeMinute) {
                activeMinute = row.minute();
                currentAssigned = new double[ZONES];
            }
            int source = zoneIndex(row.zone());
            int chosen = source;
            if (!policy.equals("reactive")) {
                double[] score = new double[ZONES];
                for (int z = 0; z < ZONES; z++) {
                    double forecast = 0;
                    int observed = 0;
                    for (long lookback = 1; lookback <= 5; lookback++) {
                        double[] prior = minuteLoads.get(row.minute() - lookback);
                        if (prior != null) { forecast += prior[z]; observed++; }
                    }
                    forecast = observed == 0 ? 0 : forecast / observed;
                    // A synthetic utilization risk proxy only: the public
                    // scheduler trace has no application incident labels.
                    double riskPenalty = policy.equals("full_system") && forecast >= 6.0 ? forecast * 0.5 : 0.0;
                    score[z] = forecast + currentAssigned[z] + riskPenalty;
                }
                chosen = 0;
                for (int z = 1; z < ZONES; z++) {
                    if (score[z] < score[chosen] || (score[z] == score[chosen] && z == source)) chosen = z;
                }
            }
            assignments.put(row.id(), chosen);
            currentAssigned[chosen] += row.cpuCores();
        }
        return assignments;
    }

    public static void main(String[] args) throws Exception {
        if (args.length<2) throw new IllegalArgumentException("usage: TraceReplay <cloudsim-workload.csv> <output.csv> [mips-per-core=1000] [max-cloudlets=100000] [policy=reactive]");
        Path input=Path.of(args[0]), output=Path.of(args[1]);
        double mipsPerCore=args.length>2?Double.parseDouble(args[2]):1000.0;
        int maxRows=args.length>3?Integer.parseInt(args[3]):MAX_CLOUDLETS_DEFAULT;
        String policy=args.length>4?args[4]:"reactive";
        if (mipsPerCore<=0 || maxRows<1) throw new IllegalArgumentException("MIPS and row limit must be positive");
        Log.setLevel(Level.OFF);
        List<WorkRow> rows=readRows(input,mipsPerCore,maxRows);
        Map<Long, Integer> vmAssignments=assignVms(rows, policy);

        CloudSimPlus simulation=new CloudSimPlus();
        List<org.cloudsimplus.hosts.Host> hosts=new ArrayList<>();
        List<org.cloudsimplus.resources.Pe> pes=new ArrayList<>();
        for(int i=0;i<ZONES*CORES_PER_ZONE_VM;i++) pes.add(new PeSimple(mipsPerCore));
        hosts.add(new HostSimple(131072,1_000_000,10_000_000,pes));
        new DatacenterSimple(simulation,hosts);
        DatacenterBrokerSimple broker=new DatacenterBrokerSimple(simulation);
        List<org.cloudsimplus.vms.Vm> vms=new ArrayList<>();
        for(int z=0;z<ZONES;z++) {
            VmSimple vm=new VmSimple(mipsPerCore,CORES_PER_ZONE_VM);
            vm.setId(z);
            vm.setRam(32768);
            vm.setBw(100_000);
            vm.setSize(1_000_000);
            vms.add(vm);
        }
        broker.submitVmList(vms);
        List<Cloudlet> cloudlets=new ArrayList<>();
        Map<Long,WorkRow> metadata=new HashMap<>();
        for(WorkRow row:rows) {
            CloudletSimple cloudlet=new CloudletSimple(row.lengthMi(),1,new UtilizationModelDynamic(1.0));
            cloudlet.setUtilizationModelRam(new UtilizationModelDynamic(0.0));
            cloudlet.setUtilizationModelBw(new UtilizationModelDynamic(0.0));
            cloudlet.setId(row.id());
            cloudlet.setSubmissionDelay(row.minute()*60.0);
            cloudlet.setVm(vms.get(vmAssignments.get(row.id())));
            cloudlets.add(cloudlet); metadata.put(row.id(),row);
        }
        broker.submitCloudletList(cloudlets);
        simulation.start();

        output.toAbsolutePath().getParent().toFile().mkdirs();
        try(BufferedWriter writer=Files.newBufferedWriter(output)) {
            writer.write("cloudlet_id,minute,machine_id,zone,requested_cpu_cores,requested_memory_sum,cloudlet_length_mi,vm_id,status,finish_time_s,execution_time_s,waiting_time_s\n");
            for(Cloudlet cloudlet:broker.getCloudletFinishedList()) {
                WorkRow row=metadata.get(cloudlet.getId());
                writer.write(String.format(java.util.Locale.ROOT,"%d,%d,%s,%s,%.6f,%.3f,%d,%d,%s,%.6f,%.6f,%.6f%n",
                    row.id(),row.minute(),row.machine(),row.zone(),row.cpuCores(),row.memoryMiB(),row.lengthMi(),
                    cloudlet.getVm().getId(),cloudlet.getStatus(),cloudlet.getFinishTime(),cloudlet.getFinishTime()-cloudlet.getStartTime(),cloudlet.getStartWaitTime()));
            }
        }
        System.out.printf("CloudSim Plus replayed %d machine-minute workload rows with policy=%s; output=%s%n",rows.size(),policy,output);
    }
}
