"""Build CPU-fault windows from the public AIOps Challenge 2020 release.

This deliberately creates an *active fault detection* dataset, not a future
incident or early-warning target. Only public telemetry and its fault ledger
are read; telemetry/ and telemetry_windows.csv are never used.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import re
import zipfile
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE_TZ = timezone(timedelta(hours=8))  # release timestamps/ledger use China local time
DEFAULT_SOURCE = ROOT / "data/raw/public_aiops2020/extracted"
DEFAULT_OUTPUT = ROOT / "data/processed/public_aiops2020/cpu_fault_windows.csv"
FAULT_FILE = "故障整理（预赛）.csv"


def parse_time(value: str) -> datetime:
    return datetime.strptime(value.strip(), "%Y/%m/%d %H:%M")


def build(source: Path, output: Path) -> dict:
    fault_path = source / FAULT_FILE
    if not fault_path.is_file():
        raise FileNotFoundError(f"missing public fault ledger: {fault_path}")
    with fault_path.open(encoding="utf-8-sig", newline="") as f:
        faults = list(csv.DictReader(f))

    cpu_events: dict[str, list[dict]] = defaultdict(list)
    for event in faults:
        if event.get("fault_desrcibtion", "").strip() != "CPU fault":
            continue
        when = event.get("start_time", "").strip() or event.get("log_time", "").strip()
        target = event.get("name", "").strip()
        if not when or not target.startswith("docker_"):
            continue
        start = parse_time(when)
        duration_match = re.search(r"(\d+)", event.get("duration", "5min"))
        duration = int(duration_match.group(1)) if duration_match else 5
        cpu_events[start.strftime("%Y_%m_%d")].append({"start": start, "end": start + timedelta(minutes=duration),
                                                        "target": target, "event_id": event.get("index", "")})

    rows: list[dict] = []
    missing_days = []
    day_dir = source / "AIOps挑战赛数据"
    for day, events in sorted(cpu_events.items()):
        archive = day_dir / f"{day}.zip"
        if not archive.is_file():
            missing_days.append(day)
            continue
        with zipfile.ZipFile(archive) as zf:
            member = next((n for n in zf.namelist() if n.endswith("/平台指标/dcos_docker.csv")), None)
            if member is None:
                raise ValueError(f"{archive} lacks dcos_docker.csv")
            raw = zf.read(member).decode("utf-8-sig")
        minute_values: dict[tuple[str, datetime], list[float]] = defaultdict(list)
        for item in csv.DictReader(io.StringIO(raw)):
            if item.get("name") != "container_cpu_used":
                continue
            try:
                epoch_ms = int(item["timestamp"])
                value = float(item["value"])
                timestamp = datetime.fromtimestamp(epoch_ms / 1000, tz=timezone.utc).astimezone(SOURCE_TZ).replace(tzinfo=None)
            except (KeyError, TypeError, ValueError, OSError):
                continue
            minute = timestamp.replace(second=0, microsecond=0)
            minute_values[(item.get("cmdb_id", ""), minute)].append(value)

        previous_by_resource: dict[str, list[float]] = defaultdict(list)
        for (resource, minute), values in sorted(minute_values.items(), key=lambda pair: (pair[0][0], pair[0][1])):
            if not resource.startswith("docker_"):
                continue
            cpu_mean = sum(values) / len(values)
            previous = previous_by_resource[resource][-3:]
            active_ids = [e["event_id"] for e in events if e["target"] == resource and e["start"] <= minute < e["end"]]
            rows.append({"date_group": day, "timestamp_utc": minute.isoformat(), "resource_id": resource,
                         "process_cpu_percent_1_core_mean": cpu_mean,
                         "cpu_lag_1": previous[-1] if previous else "",
                         "cpu_mean_prev_3": sum(previous) / len(previous) if previous else "",
                         "cpu_delta_from_prev_3": cpu_mean - (sum(previous) / len(previous)) if previous else "",
                         "cpu_samples_in_minute": len(values), "cpu_fault_active": int(bool(active_ids)),
                         "active_fault_ids": ";".join(active_ids)})
            previous_by_resource[resource].append(cpu_mean)

    if not rows:
        raise ValueError("no public CPU telemetry windows were produced")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    report = {"source": "AIOps Challenge 2020 public release", "source_url": "https://github.com/NetManAIOps/AIOps-Challenge-2020-Data",
              "target": "cpu_fault_active", "target_definition": "annotated CPU fault interval is active in this minute for the annotated docker resource",
              "feature_unit": "container_cpu_used is documented by the release as percent; mapped to project process_cpu_percent_1_core_mean",
              "rows": len(rows), "positive_rows": sum(r["cpu_fault_active"] for r in rows),
              "date_groups": sorted({r["date_group"] for r in rows}), "cpu_fault_events_in_ledger": sum(map(len, cpu_events.values())),
              "missing_day_archives": missing_days, "output": str(output),
              "limitations": ["active fault detection only; no early-warning claim", "only annotated CPU faults are positives", "unannotated fault types are outside this target", "public release permits non-commercial research/classroom use per its repository"]}
    output.with_suffix(".metadata.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    print(json.dumps(build(args.source, args.output), indent=2))


if __name__ == "__main__":
    main()
