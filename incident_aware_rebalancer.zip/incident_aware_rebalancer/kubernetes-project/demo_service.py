"""Tiny local HTTP service with request and process telemetry (stdlib only)."""

from __future__ import annotations

import argparse
import json
import math
import resource
import sys
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse


class Telemetry:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.started = time.monotonic()
        self.events: deque[tuple[float, float, int]] = deque(maxlen=50000)
        self.requests_total = 0
        self.started_total = 0
        self.errors_total = 0
        self.cpu_seconds_start = time.process_time()
        self.cpu_scrape_time = self.started
        self.cpu_scrape_value = self.cpu_seconds_start
        self.cpu_percent_1_core = 0.0

    def record(self, latency_ms: float, status: int) -> None:
        now = time.monotonic()
        with self.lock:
            self.requests_total += 1
            if status >= 500:
                self.errors_total += 1
            self.events.append((now, latency_ms, status))

    def snapshot(self) -> dict[str, float | int]:
        now = time.monotonic()
        cpu_now = time.process_time()
        with self.lock:
            cutoff = now - 60.0
            recent = [event for event in self.events if event[0] >= cutoff]
            elapsed = min(60.0, max(1.0, now - self.started))
            latencies = sorted(event[1] for event in recent)
            errors = sum(event[2] >= 500 for event in recent)
            if now > self.cpu_scrape_time:
                self.cpu_percent_1_core = max(
                    0.0,
                    (cpu_now - self.cpu_scrape_value) / (now - self.cpu_scrape_time) * 100.0,
                )
                self.cpu_scrape_time = now
                self.cpu_scrape_value = cpu_now
            p95_index = max(0, min(len(latencies) - 1, math.ceil(len(latencies) * 0.95) - 1)) if latencies else 0
            max_rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            # macOS reports ru_maxrss in bytes; Linux reports KiB.
            rss_bytes = int(max_rss if sys.platform == "darwin" else max_rss * 1024)
            return {
                "requests_total": self.requests_total,
                "errors_total": self.errors_total,
                "request_rate_rps": len(recent) / elapsed,
                "error_rate": errors / len(recent) if recent else 0.0,
                "p95_latency_ms": latencies[p95_index] if latencies else 0.0,
                "process_cpu_seconds_total": cpu_now - self.cpu_seconds_start,
                "process_cpu_percent_1_core": self.cpu_percent_1_core,
                "process_max_rss_bytes": rss_bytes,
            }


TELEMETRY = Telemetry()


def _cpu_work(milliseconds: float) -> None:
    """Spend approximately the requested time doing bounded CPU work."""
    deadline = time.monotonic() + max(0.0, min(milliseconds, 1000.0)) / 1000.0
    value = 1
    while time.monotonic() < deadline:
        value = (value * 33 + 17) % 1000003


class Handler(BaseHTTPRequestHandler):
    server_version = "LocalDemoService/1.0"

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def _respond(self, status: int, body: bytes, content_type: str = "application/json") -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        parsed = urlparse(self.path)
        if parsed.path == "/health":
            self._respond(200, b'{"status":"ok"}')
            return
        if parsed.path == "/metrics":
            self._serve_metrics()
            return
        if parsed.path not in {"/", "/work"}:
            self._respond(404, b'{"error":"not found"}')
            return

        started = time.monotonic()
        values = parse_qs(parsed.query)
        delay_ms = _query_float(values, "delay_ms", 0.0, 0.0, 5000.0)
        cpu_ms = _query_float(values, "cpu_ms", 0.0, 0.0, 1000.0)
        fail_every = int(_query_float(values, "fail_every", 0.0, 0.0, 1000000.0))
        with TELEMETRY.lock:
            TELEMETRY.started_total += 1
            request_number = TELEMETRY.started_total

        if delay_ms:
            time.sleep(delay_ms / 1000.0)
        if cpu_ms:
            _cpu_work(cpu_ms)
        failed = fail_every > 0 and request_number % fail_every == 0
        status = 500 if failed else 200
        body = (b'{"error":"synthetic failure"}' if failed else
                json.dumps({"status": "ok", "request_number": request_number}).encode("utf-8"))
        TELEMETRY.record((time.monotonic() - started) * 1000.0, status)
        self._respond(status, body)

    def _serve_metrics(self) -> None:
        snapshot = TELEMETRY.snapshot()
        lines = [
            "# HELP demo_requests_total Total application requests.",
            "# TYPE demo_requests_total counter",
            f"demo_requests_total {snapshot['requests_total']}",
            "# HELP demo_errors_total Total application responses with status 5xx.",
            "# TYPE demo_errors_total counter",
            f"demo_errors_total {snapshot['errors_total']}",
            "# HELP demo_request_rate_rps Rolling request rate over up to 60 seconds.",
            "# TYPE demo_request_rate_rps gauge",
            f"demo_request_rate_rps {snapshot['request_rate_rps']:.6f}",
            "# HELP demo_error_rate Rolling 5xx fraction over up to 60 seconds.",
            "# TYPE demo_error_rate gauge",
            f"demo_error_rate {snapshot['error_rate']:.6f}",
            "# HELP demo_p95_latency_ms Rolling request-level p95 latency in milliseconds.",
            "# TYPE demo_p95_latency_ms gauge",
            f"demo_p95_latency_ms {snapshot['p95_latency_ms']:.6f}",
            "# HELP process_cpu_seconds_total Process CPU seconds since start.",
            "# TYPE process_cpu_seconds_total counter",
            f"process_cpu_seconds_total {snapshot['process_cpu_seconds_total']:.6f}",
            "# HELP process_cpu_percent_1_core Process CPU use as percent of one core over the last scrape interval.",
            "# TYPE process_cpu_percent_1_core gauge",
            f"process_cpu_percent_1_core {snapshot['process_cpu_percent_1_core']:.6f}",
            "# HELP process_max_rss_bytes Process maximum resident set size high-water mark in bytes.",
            "# TYPE process_max_rss_bytes gauge",
            f"process_max_rss_bytes {snapshot['process_max_rss_bytes']}",
            "",
        ]
        self._respond(200, "\n".join(lines).encode("utf-8"), "text/plain; version=0.0.4")


def _query_float(values: dict[str, list[str]], key: str, default: float,
                 minimum: float, maximum: float) -> float:
    try:
        value = float(values.get(key, [str(default)])[0])
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(maximum, value))


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the local telemetry demo service")
    parser.add_argument("--host", default="127.0.0.1", help="Defaults to loopback for local-only use")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Demo service listening at http://{args.host}:{args.port}")
    print(f"Health:  http://{args.host}:{args.port}/health")
    print(f"Metrics: http://{args.host}:{args.port}/metrics")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping demo service")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
