"""Train a CPU-only warning model for an explicit cross-environment transfer check."""
from __future__ import annotations
import argparse, json
from pathlib import Path
import joblib
import numpy as np
from lightgbm import LGBMClassifier
from train_incident_models import read_dataset, split_groups, threshold_f05, metrics

FEATURE="process_cpu_percent_1_core_mean"

def train(input_path: Path, output_dir: Path, seed: int=27):
    rows, x, y, groups=read_dataset(input_path)
    col=["request_rate_rps","p95_latency_ms","error_rate","process_cpu_percent_1_core_mean","process_max_rss_bytes","request_rate_lag_1","request_rate_mean_prev_3","p95_latency_lag_1","p95_latency_slope_prev_3","error_rate_lag_1","error_rate_mean_prev_3"].index(FEATURE)
    values=x[:,[col]]
    fit_idx,val_idx,test_idx=split_groups(y,groups,seed)
    model=LGBMClassifier(n_estimators=70,learning_rate=.04,max_depth=2,num_leaves=3,min_child_samples=3,
                         class_weight="balanced",verbosity=-1,random_state=seed)
    model.fit(values[fit_idx],y[fit_idx])
    val=model.predict_proba(values[val_idx])[:,1]
    threshold=threshold_f05(y[val_idx],val)
    test=model.predict_proba(values[test_idx])[:,1]
    output_dir.mkdir(parents=True,exist_ok=True)
    joblib.dump({"model":model,"features":[FEATURE],"threshold":threshold,"model_name":"cpu_only_lightgbm"},output_dir/"cpu_only_lightgbm.joblib")
    report={"model":"cpu_only_lightgbm","feature":FEATURE,"split":"whole-run grouped; threshold selected on validation F0.5","seed":seed,
            "counts":{"rows":len(rows),"positive_rows":int(y.sum()),"fit_runs":len(set(groups[fit_idx])),"validation_runs":len(set(groups[val_idx])),"test_runs":len(set(groups[test_idx]))},
            "threshold":float(threshold),"validation":metrics(y[val_idx],val,threshold),"test":metrics(y[test_idx],test,threshold),
            "scope":"Exploratory CPU-only transfer model. It cannot detect error-only or latency-only faults without CPU signal and is not the full incident model.",
            "limitations":["scripted local application and faults", "small grouped test set", "CPU feature distributions differ by runtime", "AIOpsLab transfer must be evaluated separately"]}
    (output_dir/"cpu_only_report.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    return report

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--input",type=Path,default=Path("data/processed/telemetry_windows.csv"));p.add_argument("--output-dir",type=Path,default=Path("data/processed/incident_models/models"));p.add_argument("--seed",type=int,default=27);a=p.parse_args();print(json.dumps(train(a.input,a.output_dir,a.seed),indent=2))
if __name__=="__main__":main()
