"""Fail-closed guards for deterministic replica and traffic-share proposals."""

from __future__ import annotations

import math
from dataclasses import dataclass

from policies import ZonePlan


@dataclass(frozen=True)
class SafetyDecision:
    plan: ZonePlan
    status: str
    reasons: tuple[str, ...]


def _project_box_simplex(values: tuple[float, ...], lower: tuple[float, ...],
                         upper: tuple[float, ...]) -> tuple[float, ...]:
    """Project shares to a bounded simplex using a deterministic water-fill."""
    if sum(lower) > 1.0 + 1e-9 or sum(upper) < 1.0 - 1e-9:
        raise ValueError("traffic-share safety bounds are infeasible")
    left = min(values[i] - upper[i] for i in range(len(values))) - 1.0
    right = max(values[i] - lower[i] for i in range(len(values))) + 1.0
    for _ in range(80):
        shift = (left + right) / 2.0
        total = sum(min(upper[i], max(lower[i], values[i] - shift)) for i in range(len(values)))
        if total > 1.0:
            left = shift
        else:
            right = shift
    projected = [min(upper[i], max(lower[i], values[i] - (left + right) / 2.0))
                 for i in range(len(values))]
    difference = 1.0 - sum(projected)
    for i in range(len(projected)):
        adjustment = min(upper[i] - projected[i], difference) if difference > 0 else max(lower[i] - projected[i], difference)
        projected[i] += adjustment
        difference -= adjustment
    return tuple(projected)


def guard_plan(
    current: ZonePlan,
    proposed: ZonePlan,
    zone_capacity: tuple[float, float, float],
    min_replicas: int,
    max_replicas: int,
    max_replica_step: int = 2,
    max_share_step: float = 0.20,
    min_active_share: float = 0.02,
    incident_risk: tuple[float, float, float] = (0.0, 0.0, 0.0),
    emergency_risk_threshold: float = 0.9,
) -> SafetyDecision:
    """Validate a plan, bound each change, or retain the previous plan on error.

    Capacity zero drains that zone immediately. Other healthy zones retain a
    small traffic floor, while ordinary replica and share changes are rate limited.
    """
    reasons: list[str] = []
    if len(current.replicas) != 3 or len(current.traffic_shares) != 3:
        raise ValueError("current plan must contain exactly three zones")
    if len(proposed.replicas) != 3 or len(proposed.traffic_shares) != 3:
        return SafetyDecision(current, "rejected", ("proposal must contain exactly three zones",))
    if len(zone_capacity) != 3 or any(not math.isfinite(float(v)) or float(v) < 0 for v in zone_capacity):
        return SafetyDecision(current, "rejected", ("zone capacity must contain three finite non-negative values",))
    if len(incident_risk) != 3 or any(not math.isfinite(float(v)) or not 0 <= float(v) <= 1 for v in incident_risk):
        return SafetyDecision(current, "rejected", ("incident risk must contain three finite values between zero and one",))
    if min_replicas < 1 or max_replicas < min_replicas or max_replica_step < 0 or max_share_step < 0:
        return SafetyDecision(current, "rejected", ("safety limits are invalid",))
    if any(not isinstance(v, int) or isinstance(v, bool) for v in proposed.replicas):
        return SafetyDecision(current, "rejected", ("replica counts must be integers",))
    if any(v < min_replicas or v > max_replicas for v in proposed.replicas):
        return SafetyDecision(current, "rejected", ("replica proposal is outside configured bounds",))
    shares = proposed.traffic_shares
    if any(not math.isfinite(float(v)) or float(v) < 0 or float(v) > 1 for v in shares):
        return SafetyDecision(current, "rejected", ("traffic shares must be finite values between zero and one",))
    if not math.isclose(sum(shares), 1.0, rel_tol=0.0, abs_tol=1e-6):
        return SafetyDecision(current, "rejected", ("traffic shares must sum to one",))

    bounded_replicas = []
    for old, new in zip(current.replicas, proposed.replicas):
        bounded = max(old - max_replica_step, min(old + max_replica_step, new))
        bounded_replicas.append(bounded)
        if bounded != new:
            reasons.append("replica change rate limited")

    lower: list[float] = []
    upper: list[float] = []
    for i, capacity in enumerate(zone_capacity):
        if capacity <= 0:
            lower.append(0.0)
            upper.append(0.0)
            if shares[i] > 1e-9:
                reasons.append(f"zone {i} has no capacity; traffic drained")
        else:
            urgent = incident_risk[i] >= emergency_risk_threshold
            normal_lower = max(min_active_share, current.traffic_shares[i] - max_share_step)
            lower.append(min_active_share if urgent else normal_lower)
            # Never send more traffic toward a zone above the emergency risk threshold.
            upper.append(current.traffic_shares[i] if urgent else min(1.0, current.traffic_shares[i] + max_share_step))
            if urgent and shares[i] < normal_lower - 1e-9:
                reasons.append(f"zone {i} high incident risk; emergency traffic drain allowed")
    try:
        bounded_shares = _project_box_simplex(shares, tuple(lower), tuple(upper))
    except ValueError as exc:
        return SafetyDecision(current, "rejected", (str(exc),))
    if any(abs(a - b) > 1e-7 for a, b in zip(shares, bounded_shares)):
        reasons.append("traffic-share change rate limited or active-zone floor applied")

    safe_plan = ZonePlan(tuple(bounded_replicas), bounded_shares)
    status = "adjusted" if reasons else "accepted"
    return SafetyDecision(safe_plan, status, tuple(dict.fromkeys(reasons)))
