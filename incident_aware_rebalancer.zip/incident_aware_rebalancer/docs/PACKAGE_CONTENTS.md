# Package contents and omissions

This archive contains a copy of the project source/configuration/docs, processed reports and evaluation artifacts, telemetry, the processed public datasets, the standalone visual frontend, and project/flow guides. The project snapshot is under `project/`; the webpage is under `frontend/`.

The raw public AIops challenge archive and its extracted source are not included (multi-gigabyte; refer to the upstream source URL and terms in `project/data/processed/public_aiops2020/cpu_fault_windows.metadata.json`). Local Python/kind/Helm/Maven/Docker caches, `.toolchain` including the local kubeconfig, `.git`, the Docker installer disk image, `__pycache__`, and `.pyc` files are omitted. The 5,000-row converted Google trace sample and its provenance/attribution are included.

All included files are copies. The originals remain in `/Users/vriddhi/Desktop/incident-aware-rebalancer` and `/Users/vriddhi/Desktop/incident-aware-rebalancer-frontend`.
