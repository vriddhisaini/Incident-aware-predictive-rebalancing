# Start here

This ZIP is a portable snapshot; extracting it does not change the original project. The extracted folder contains `frontend/` and `project/` plus guides.

## Open the explanatory frontend

Open `frontend/index.html` in VS Code. To serve it at `http://localhost:8000`, open a terminal in the `frontend` folder and run:

```sh
python3 -m http.server 8000 --bind 127.0.0.1
```

The page is a browser-only visual explainer. Stage selection and walkthrough explain the pipeline; Normal/Rising load/Injected fault only change sample displays. It is not wired to the project services. See `FRONTEND_CODE_GUIDE.md`.

## Understand the full project

Read `PROJECT_CONTEXT_AND_FLOW.md` first, then `project/README.md`, `project/ARCHITECTURE_STATUS.md`, and `project/docs/UNIFIED_LIVE_DEMO.md`. The complete code and configuration snapshot is in `project/`. The latest recorded result is `project/data/processed/unified_demo/20261120_205258/run_summary.json`.

To run the full project, use the setup and prerequisites in `project/docs/LOCAL_SETUP.md` and `project/docs/UNIFIED_LIVE_DEMO.md`. That is a separate Kubernetes workflow and is not needed to open the frontend.
