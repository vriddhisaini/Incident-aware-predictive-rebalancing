# Frontend code guide

The demo is one dependency-free `frontend/index.html`. HTML defines the page, CSS defines layout and styling, and an inline JavaScript block handles interactions. There is no build step, server API, chart package, React/Vue bundle, or live telemetry connection.

## HTML structure

- Header: project title and “Local visual demo · no live control” label.
- System flow: five `<button class="node">` controls with `data-stage` IDs (`load`, `router`, `zones`, `telemetry`, `decision`).
- `#explain`: the detail area whose text changes when a stage is selected.
- Back/Next/Play controls plus `#progress` and `#counter` for the guided walkthrough.
- `#zones`: zone cards are generated at runtime.
- `[data-scene]` buttons: Normal, Rising load, and Injected fault.
- Latest recorded run: fixed text and figures from `run_summary.json`; it does not refresh from the project.
- Decision path: scenario-specific timeline generated with the zone cards.
- What is used: a static catalog of components and roles.

## CSS

The top-level custom properties set the light palette, spacing/colors, and card shadow. `.grid`, `.flow`, `.zones`, and `.stack` lay out the sections. At viewports under 760 px, media rules collapse the page to a single column and stack the flow/zones. `.node.selected` and `.controls button.active` mark current choices. The progress bar and zone bars animate their width/color transitions.

## JavaScript: stage teaching

`stages` is a five-item array. Each item has an ID, title, and explanation text. `showStage(i)` wraps the requested index, writes the chosen explanation into `#explain`, toggles the selected flow button, and updates the step label and progress width. Clicking a flow node chooses its stage; Back and Next change the index. Play starts a 2.6-second interval at the first stage, pauses if clicked again, and stops after the final stage.

## JavaScript: scenario cards

`scenes` is a lookup object with three keys. Each supplies three zone tuples (`status`, illustrative utilization percentage, illustrative latency) and three short event pairs. `draw(name)` turns these data into card/timeline HTML strings and toggles the active scenario button. The scenario buttons call `draw`; they do not make HTTP requests or update any model state.

## What is real and what is illustrative

The latest run panel is a fixed snapshot of a completed experiment: 3,600 requests, 1.67% errors, 360 ms p95, with the detector limitation written beside it. The bars and events are teaching examples intentionally labeled “Illustrative.” They are not pulled from Prometheus. The LLM, model API, safety gate, and operator are named/explained but not called by this static site.

## Editing it

Open `frontend/index.html` in VS Code. Save changes and refresh `http://localhost:8000/`. To run it again from the `frontend` directory:

```sh
python3 -m http.server 8000 --bind 127.0.0.1
```
